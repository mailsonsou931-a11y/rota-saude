@echo off
chcp 65001 > nul
echo.
echo =====================================================
echo   ROTA SAUDE - Iniciando servidor local...
echo =====================================================
echo.

:: Verifica se Python está instalado
python --version > nul 2>&1
if errorlevel 1 (
    echo  ERRO: Python nao encontrado!
    echo  Baixe em: https://www.python.org/downloads/
    echo  Marque "Add Python to PATH" durante a instalacao.
    pause
    exit
)

echo  Python encontrado. Iniciando...
echo  Acesse: http://localhost:8080
echo  Para fechar: pressione Ctrl+C ou feche esta janela.
echo.

python servidor.py
pause
