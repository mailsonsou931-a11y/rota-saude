#!/usr/bin/env python3
"""
Servidor local para o app Rota Saúde.
Faz proxy da API do Claude com sua chave de API.

Como usar:
  1. Coloque sua chave do Claude na variável ANTHROPIC_API_KEY abaixo
     OU defina a variável de ambiente: set ANTHROPIC_API_KEY=sua-chave (Windows)
  2. Execute: python servidor.py
  3. Abra no navegador: http://localhost:8080
"""

import http.server
import json
import os
import urllib.request
import urllib.error

# ─── COLOQUE SUA CHAVE AQUI (ou use variável de ambiente) ───────────────────
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "COLOQUE_SUA_CHAVE_AQUI")
PORT = 8080
# ─────────────────────────────────────────────────────────────────────────────


class Handler(http.server.SimpleHTTPRequestHandler):

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_POST(self):
        if self.path == "/api/claude":
            self._proxy_claude()
        else:
            self.send_error(404)

    def _proxy_claude(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)

        if ANTHROPIC_API_KEY == "COLOQUE_SUA_CHAVE_AQUI":
            self._json_error(500, "Configure sua ANTHROPIC_API_KEY no arquivo servidor.py")
            return

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                data = resp.read()
                self.send_response(resp.status)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._json_error(500, str(e))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _json_error(self, code, msg):
        payload = json.dumps({"error": {"message": msg}}).encode()
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, fmt, *args):
        # Log simplificado
        if "/api/claude" in args[0] if args else "":
            print(f"  [API] {args[0]}")
        else:
            super().log_message(fmt, *args)


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print("=" * 55)
    print("  ROTA SAÚDE — Servidor Local")
    print("=" * 55)

    if ANTHROPIC_API_KEY == "COLOQUE_SUA_CHAVE_AQUI":
        print("\n  ⚠️  ATENÇÃO: Configure sua chave da API!")
        print("  Abra servidor.py e coloque sua chave em ANTHROPIC_API_KEY")
        print("  Obtenha sua chave em: https://console.anthropic.com")
    else:
        print(f"\n  ✅ Chave configurada: {ANTHROPIC_API_KEY[:8]}...")

    print(f"\n  🌐 Acesse: http://localhost:{PORT}")
    print("  Pressione Ctrl+C para parar.\n")

    with http.server.ThreadingHTTPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  Servidor encerrado.")
