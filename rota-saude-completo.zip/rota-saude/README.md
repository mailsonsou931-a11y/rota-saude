# 🚐 Rota Saúde — Francisco Mailson de Sousa Moreira

Sistema de Gestão de Transporte de Pacientes com IA.

---

## ▶️ OPÇÃO 1 — Rodar no seu PC (mais rápido)

### Passo 1 — Instalar Python (se não tiver)
1. Acesse: https://www.python.org/downloads/
2. Clique em **"Download Python"**
3. Durante a instalação, marque ☑️ **"Add Python to PATH"**
4. Finalize a instalação

### Passo 2 — Configurar sua chave da API
1. Acesse: https://console.anthropic.com
2. Vá em **"API Keys"** → **"Create Key"**
3. Copie a chave (começa com `sk-ant-...`)
4. Abra o arquivo `servidor.py` com o Bloco de Notas
5. Localize a linha:
   ```
   ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "COLOQUE_SUA_CHAVE_AQUI")
   ```
6. Substitua `COLOQUE_SUA_CHAVE_AQUI` pela sua chave:
   ```
   ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "sk-ant-api03-...")
   ```
7. Salve o arquivo

### Passo 3 — Iniciar o sistema
- **Windows:** Dê duplo clique em `INICIAR.bat`
- **Ou:** Abra o terminal na pasta e execute `python servidor.py`

### Passo 4 — Usar o sistema
1. Abra o navegador (Chrome ou Edge)
2. Acesse: **http://localhost:8080**
3. Importe o PDF da rota e pronto!

> ⚠️ Mantenha a janela do servidor aberta enquanto usa o sistema.

---

## 🌐 OPÇÃO 2 — Publicar na web com Netlify (gratuito)

### Passo 1 — Criar conta no Netlify
1. Acesse: https://netlify.com
2. Clique em **"Sign up"** → entre com Gmail ou GitHub

### Passo 2 — Fazer o deploy
1. No painel do Netlify, clique em **"Add new site"**
2. Escolha **"Deploy manually"**
3. Arraste a pasta inteira `rota-saude` para a área indicada
4. Aguarde o deploy (menos de 1 minuto)

### Passo 3 — Configurar a chave da API
1. No painel do seu site no Netlify, vá em:
   **Site configuration → Environment variables → Add a variable**
2. Adicione:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-api03-...` (sua chave)
3. Clique em **Save**
4. Vá em **Deploys → Trigger deploy** para aplicar

### Passo 4 — Acessar
- O Netlify vai gerar um link como: `https://seu-app.netlify.app`
- Compartilhe esse link com quem precisar acessar!

---

## 📁 Estrutura dos arquivos

```
rota-saude/
├── index.html              ← O app principal
├── servidor.py             ← Servidor local (Python)
├── INICIAR.bat             ← Iniciar no Windows (duplo clique)
├── netlify.toml            ← Configuração do Netlify
├── netlify/
│   └── functions/
│       └── claude.js       ← Função serverless (proxy da API)
└── README.md               ← Este arquivo
```

---

## ❓ Problemas comuns

**"Python não encontrado"**
→ Reinstale o Python marcando "Add Python to PATH"

**"A IA não responde"**
→ Verifique se a chave está correta no servidor.py

**"Não abre o PDF"**
→ O PDF precisa ter texto selecionável (não pode ser imagem escaneada)

**"Erro 500 no Netlify"**
→ Verifique se a variável ANTHROPIC_API_KEY foi adicionada e fez o redeploy

---

*Sistema desenvolvido para a Secretaria Municipal de Saúde*
*Francisco Mailson de Sousa Moreira — Gerente de Apoio Social*
