'use strict';
/* ═══════════════════════════════════════════════════════════════
   SAS v3.0 — Itapajé Mais Saúde · script.js
   Módulos: IMS · Ofícios · Atend. Gerais · Status · WhatsApp
            Relatório · Timbrado · QR · Admin · Deploy Guide
   Admin: mailson / Maluka12
   IA: diferencia numerações IMS (AAAA.MM.DD.SEQ) vs Ofício (NNN/AAAA)
   ═══════════════════════════════════════════════════════════════ */

/* ═════════════════════════════════════════
   DB — LocalStorage
═════════════════════════════════════════ */
const DB = {
  K:{
    USERS:'sas3_users', PENDING:'sas3_pending',
    SESSION:'sas3_session',
    IMS:'sas3_ims',           // Casos Itapajé Mais Saúde
    PATIENTS:'sas3_patients', // Pacientes gerais
    GENERAL:'sas3_general',   // Atendimentos gerais
    OFICIOS:'sas3_oficios',   // Ofícios e autorizações
    REPORTS:'sas3_reports',   // Relatórios gerados
    HISTORY:'sas3_history',   // Histórico de status (por ID)
    RESPONSIBLE:'sas3_resp',
    LETTERHEAD:'sas3_lh',
    WA_HIST:'sas3_wa',
    GAB_PHONE:'sas3_gab',
  },
  g(k){try{const v=localStorage.getItem(k);return v?JSON.parse(v):null}catch{return null}},
  s(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch{return false}},
  getUsers(){return this.g(this.K.USERS)||[]},
  saveUsers(u){return this.s(this.K.USERS,u)},
  getPending(){return this.g(this.K.PENDING)||[]},
  savePending(p){return this.s(this.K.PENDING,p)},
  getSession(){return this.g(this.K.SESSION)},
  setSession(u){return this.s(this.K.SESSION,{user:u,at:Date.now()})},
  clearSession(){localStorage.removeItem(this.K.SESSION)},
  getIMS(){return this.g(this.K.IMS)||[]},
  saveIMS(a){return this.s(this.K.IMS,a)},
  getIMSCase(id){return this.getIMS().find(x=>x.id===id)||null},
  upsertIMS(item){const a=this.getIMS(),i=a.findIndex(x=>x.id===item.id);if(i>=0)a[i]=item;else a.push(item);return this.saveIMS(a)},
  deleteIMS(id){return this.saveIMS(this.getIMS().filter(x=>x.id!==id))},
  getPatients(){return this.g(this.K.PATIENTS)||[]},
  savePatients(a){return this.s(this.K.PATIENTS,a)},
  getPatient(id){return this.getPatients().find(x=>x.id===id)||null},
  upsertPatient(p){const a=this.getPatients(),i=a.findIndex(x=>x.id===p.id);if(i>=0)a[i]=p;else a.push(p);return this.savePatients(a)},
  deletePatient(id){return this.savePatients(this.getPatients().filter(x=>x.id!==id))},
  getGeneral(){return this.g(this.K.GENERAL)||[]},
  saveGeneral(a){return this.s(this.K.GENERAL,a)},
  getOficiosAll(){return this.g(this.K.OFICIOS)||[]},
  saveOficios(a){return this.s(this.K.OFICIOS,a)},
  getHistory(id){const a=this.g(this.K.HISTORY)||{};return a[id]||[]},
  addHistory(id,e){const a=this.g(this.K.HISTORY)||{};if(!a[id])a[id]=[];a[id].unshift(e);return this.s(this.K.HISTORY,a)},
  getReports(){return this.g(this.K.REPORTS)||[]},
  addReport(r){const a=this.getReports();a.unshift(r);if(a.length>100)a.pop();return this.s(this.K.REPORTS,a)},
  getResp(){return this.g(this.K.RESPONSIBLE)||{socialName:'',socialReg:'',managerName:'Francisco Maílson de Sousa Moreira',managerRole:'Gerente de Apoio Social',unit:'Secretaria Municipal de Saúde',unitAddress:'R. São Francisco, Nº 225 Centro',unitPhone:' 99126-4880',unitCity:'Itapajé — CE'}},
  saveResp(d){return this.s(this.K.RESPONSIBLE,d)},
  getLH(){return this.g(this.K.LETTERHEAD)||{line1:'PREFEITURA MUNICIPAL DE ITAPAJÉ',line2:'Secretaria Municipal de Saúde',line3:'Serviço de Apoio Social — Itapajé Mais Saúde',align:'center',footer1:'R. São Francisco, Nº 225 Centro, CEP: 62.600-000 — Itapajé/CE',footer2:' 99126-4880 · saude@itapaje.ce.gov.br · www.itapaje.ce.gov.br',footer3:'',legal:'Documento de uso interno e confidencial.',accentColor:'#2d7d32',image:null,imgPos:'left'}},
  saveLH(d){return this.s(this.K.LETTERHEAD,d)},
  getWAHist(){return this.g(this.K.WA_HIST)||[]},
  addWAHist(e){const a=this.getWAHist();a.unshift(e);if(a.length>60)a.pop();return this.s(this.K.WA_HIST,a)},
  getGabPhone(){return this.g(this.K.GAB_PHONE)||''},
  saveGabPhone(p){return this.s(this.K.GAB_PHONE,p)},
};

/* ═════════════════════════════════════════
   Utils
═════════════════════════════════════════ */
const Utils = {
  uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)},
  /* ─── NUMERAÇÕES DISTINTAS ─────────────────────────────────────────
     IMS:    AAAA.MM.DD.SEQUENCIAL  → ex: 2026.04.11.00
     Ofício: NNN/AAAA               → ex: 001/2026, 002/2026
     A IA do sistema reconhece pelo formato e roteia corretamente.
  ─────────────────────────────────────────────────────────────────── */
  genIMSNum(){
    const now=new Date();
    const y=now.getFullYear();
    const m=String(now.getMonth()+1).padStart(2,'0');
    const d=String(now.getDate()).padStart(2,'0');
    const existing=DB.getIMS().filter(x=>{
      const parts=x.solicitNum?.split('.');
      return parts&&parts[0]==y&&parts[1]==m&&parts[2]==d;
    });
    const seq=String(existing.length).padStart(2,'0');
    return`${y}.${m}.${d}.${seq}`;
  },
  genOficioNum(){
    const year=new Date().getFullYear();
    const all=DB.getOficiosAll().filter(x=>x.num&&x.num.endsWith('/'+year));
    const next=String(all.length+1).padStart(3,'0');
    return`${next}/${year}`;
  },
  isIMSNum(s){return/^\d{4}\.\d{2}\.\d{2}\.\d{2,}$/.test(s)},
  isOficioNum(s){return/^\d{3,}\/\d{4}$/.test(s)},

  fDate(s){if(!s)return '—';const[y,m,d]=s.split('-');return`${d}/${m}/${y}`},
  fDT(ts){if(!ts)return '—';const d=new Date(ts);return d.toLocaleDateString('pt-BR')+' '+d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})},
  age(b){if(!b)return '—';const t=new Date(),x=new Date(b);let a=t.getFullYear()-x.getFullYear();const m=t.getMonth()-x.getMonth();if(m<0||(m===0&&t.getDate()<x.getDate()))a--;return a+' anos'},
  initials(n){if(!n)return '--';const p=n.trim().split(' ');return p.length===1?p[0].slice(0,2).toUpperCase():(p[0][0]+p[p.length-1][0]).toUpperCase()},
  esc(s){return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'):''},
  cleanPhone(p){return p?p.replace(/\D/g,''):''},
  filterByPeriod(arr,period,s,e){
    const now=new Date();
    return arr.filter(x=>{
      const c=new Date(x.createdAt||0);
      if(period==='day')return c.toDateString()===now.toDateString();
      if(period==='week'){const w=new Date(now);w.setDate(now.getDate()-7);return c>=w;}
      if(period==='month')return c.getMonth()===now.getMonth()&&c.getFullYear()===now.getFullYear();
      if(period==='year')return c.getFullYear()===now.getFullYear();
      if(period==='custom'&&s&&e){const sd=new Date(s),ed=new Date(e);ed.setDate(ed.getDate()+1);return c>=sd&&c<ed;}
      return true;
    });
  },
};

const Masks = {
  cpf(i){let v=i.value.replace(/\D/g,'').slice(0,11);v=v.replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2');i.value=v},
  phone(i){let v=i.value.replace(/\D/g,'').slice(0,11);if(v.length>10)v=v.replace(/^(\d{2})(\d{5})(\d{4})$/,'($1) $2-$3');else v=v.replace(/^(\d{2})(\d{4})(\d{0,4})$/,'($1) $2-$3');i.value=v},
};

/* ═════════════════════════════════════════
   UI
═════════════════════════════════════════ */
const ADMIN='mailson';
const STATUS_STEPS=['Em análise','Aguardando aprovação','Aprovado','Agendado','Realizado','Finalizado'];

const UI = {
  switchTab(id,btn){
    document.querySelectorAll('.tab-section').forEach(s=>{s.classList.remove('active');s.classList.add('hidden')});
    document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
    const s=document.getElementById('tab-'+id);
    if(s){s.classList.remove('hidden');s.classList.add('active')}
    if(btn)btn.classList.add('active');
    const m={dashboard:()=>Dashboard.refresh(),ims:()=>IMS.renderTable(),patients:()=>Patients.renderTable(),general:()=>General.renderTable(),status:()=>StatusMod.init(),oficios:()=>Oficios.renderTable(),relatorio:()=>Relatorio.init(),whatsapp:()=>WhatsApp.init(),letterhead:()=>Letterhead.init(),responsible:()=>Responsible.load(),qrcode:()=>QRModule.generate(),admin:()=>Admin.render()};
    if(m[id])m[id]();
  },
  showModal(id){document.getElementById(id)?.classList.remove('hidden')},
  closeModal(id){document.getElementById(id)?.classList.add('hidden')},
  toast(msg,type='success'){
    const t=document.getElementById('toast');t.textContent=msg;t.className='toast toast-'+type;t.classList.remove('hidden');
    clearTimeout(UI._tt);UI._tt=setTimeout(()=>t.classList.add('hidden'),3500);
  },
  statusBadge(s){
    const m={'Em análise':'analise','Aguardando aprovação':'aguardando','Aprovado':'aprovado','Reprovado':'reprovado','Agendado':'agendado','Realizado':'realizado','Pendente de docs':'pendente','Finalizado':'finalizado'};
    return`<span class="badge badge-${m[s]||'analise'}">${Utils.esc(s)}</span>`;
  },
  progressBar(status,containerId){
    const idx=STATUS_STEPS.indexOf(status);
    const el=document.getElementById(containerId);
    if(!el)return;
    let html='';
    STATUS_STEPS.forEach((step,i)=>{
      const done=i<idx;const cur=i===idx;
      html+=`<div class="progress-step">`;
      html+=`<div class="progress-step-dot ${done?'done':cur?'current':''}">${done?'✓':i+1}</div>`;
      html+=`<div class="progress-step-label ${done?'done':cur?'current':''}">${step}</div>`;
      html+=`</div>`;
      if(i<STATUS_STEPS.length-1)html+=`<div class="progress-connector ${done||cur?'done':''}"></div>`;
    });
    el.innerHTML=html;
  },
  miniProgress(status){
    const idx=Math.max(0,STATUS_STEPS.indexOf(status));
    const pct=Math.round((idx/(STATUS_STEPS.length-1))*100);
    return`<div class="mini-progress"><div class="mini-track"><div class="mini-fill" style="width:${pct}%"></div></div><span class="mini-pct">${pct}%</span></div>`;
  },
};

/* ═════════════════════════════════════════
   App — Auth
═════════════════════════════════════════ */
const App = {
  init(){
    let users=DB.getUsers();
    if(!users.find(u=>u.username===ADMIN)){
      users.push({id:Utils.uid(),username:ADMIN,password:'Maluka12',fullname:'Francisco Maílson de Sousa Moreira',role:'admin',active:true});
      DB.saveUsers(users);
    }
    if(DB.getIMS().length===0)this._seed();
    const resp=DB.getResp();
    if(!resp.managerName||resp.managerName==='Francisco Maílson de Sousa Moreira')DB.saveResp({...resp,managerName:'Francisco Maílson de Sousa Moreira',managerRole:'Gerente de Apoio Social'});
    const session=DB.getSession();
    if(session&&(Date.now()-session.at<8*60*60*1000))this._start(session.user);
    document.getElementById('dashboard-date').textContent=new Date().toLocaleDateString('pt-BR',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  },
  login(){
    const user=document.getElementById('login-user').value.trim();
    const pass=document.getElementById('login-pass').value;
    const err=document.getElementById('login-error');
    if(!user||!pass){err.textContent='Preencha usuário e senha.';err.classList.remove('hidden');return}
    const u=DB.getUsers().find(x=>x.username===user&&x.password===pass);
    if(!u){err.textContent='Usuário ou senha incorretos.';err.classList.remove('hidden');return}
    if(!u.active){err.textContent='Cadastro aguardando aprovação do administrador Maílson.';err.classList.remove('hidden');return}
    err.classList.add('hidden');DB.setSession(user);this._start(user);
  },
  logout(){DB.clearSession();document.getElementById('app').classList.add('hidden');document.getElementById('login-screen').classList.remove('hidden');['login-user','login-pass'].forEach(id=>document.getElementById(id).value='')},
  registerUser(){
    const u=document.getElementById('reg-user').value.trim(),p=document.getElementById('reg-pass').value,p2=document.getElementById('reg-pass2').value,fn=document.getElementById('reg-fullname').value.trim();
    const err=document.getElementById('reg-error');
    const show=m=>{err.textContent=m;err.classList.remove('hidden')};
    if(!u||!p||!fn)return show('Preencha todos os campos.');
    if(p!==p2)return show('Senhas não coincidem.');
    if(p.length<6)return show('Mínimo 6 caracteres.');
    const pend=DB.getPending();const users=DB.getUsers();
    if(users.find(x=>x.username===u)||pend.find(x=>x.username===u))return show('Usuário já existe ou está pendente.');
    pend.push({id:Utils.uid(),username:u,password:p,fullname:fn,requestedAt:Date.now()});
    DB.savePending(pend);UI.closeModal('modal-register-user');UI.toast('Solicitação enviada! Aguarde aprovação.');err.classList.add('hidden');
    ['reg-user','reg-pass','reg-pass2','reg-fullname'].forEach(id=>document.getElementById(id).value='');
  },
  _start(username){
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('user-name-display').textContent=username;
    document.getElementById('user-avatar').textContent=Utils.initials(username);
    const u=DB.getUsers().find(x=>x.username===username);
    const isAdmin=username===ADMIN||(u&&u.role==='admin');
    document.getElementById('user-role-display').textContent=isAdmin?'Administrador':'Assistente Social';
    if(isAdmin){document.querySelector('.nav-admin').classList.remove('hidden');this._updBadge()}
    Dashboard.refresh();
  },
  _updBadge(){const n=DB.getPending().length;const el=document.getElementById('admin-badge');if(el){el.textContent=n;n>0?el.classList.remove('hidden'):el.classList.add('hidden')}},
  _seed(){
    const imsCase={
      id:Utils.uid(),solicitNum:'2026.04.11.00',date:'2026-04-11',
      procedure:'Cirurgia Geral — Hérnia Inguinal',
      name:'João Brito Gomes',birth:'1955-05-05',gender:'Masculino',
      cpf:'259.847.563-15',rg:'10.892.611',rgOrg:'CIHPB / CE',
      phone:'(85) 98155-3220',profession:'Agricultor',education:'Alfabetizado',
      address:'Baixa Grande',neighborhood:'Zona Rural',reference:'Próximo da Igreja Católica',
      income:'1.518,00',incomeRange:'Salário Mínimo',
      housing:'Casa Concedida',services:'Com fonte de energia e água',
      mother:'Margarida Maria de Mesquita Gomes',motherProf:'Agricultora',motherEdu:'Alfabetizada',
      regulation:'Paciente encontra-se em fila de espera no Sistema de Regulação do Estado do Ceará, sem previsão de agendamento, sendo encaminhado pelo médico cirurgião para realização de procedimento em Hospital Terciário.',
      hospital:'Hospital Batista Memorial',scheduledDate:'2026-04-11',scheduledTime:'14:00',
      hospitalAddress:'R. Prof. Dias da Rocha, 1530 - Aldeota, Fortaleza - CE, 60170-311',
      obs:'Paciente idoso, agricultor, residente na zona rural de Itapajé/CE, em situação de baixa renda e sem previsão de atendimento pelo SUS.',
      eligResident:true,eligIncome:true,eligFila:true,eligIndicacao:true,eligDocs:true,
      status:'Aprovado',createdAt:Date.now()-2*86400000,updatedAt:Date.now(),
    };
    DB.saveIMS([imsCase]);
    DB.addHistory(imsCase.id,{id:Utils.uid(),status:'Aprovado',obs:'Processo aprovado pelo Programa Itapajé Mais Saúde.',user:ADMIN,at:Date.now()-86400000});
    DB.addHistory(imsCase.id,{id:Utils.uid(),status:'Em análise',obs:'Ficha recebida e encaminhada ao Serviço Social.',user:ADMIN,at:Date.now()-2*86400000});
    // Oficio exemplo
    const ofNum='001/2026';
    DB.saveOficios([{id:Utils.uid(),num:ofNum,type:'autorizacao',dest:'João Brito Gomes',subject:'Autorização para Procedimento Cirúrgico — Programa Itapajé Mais Saúde',body:`O paciente JOÃO BRITO GOMES, portador do CPF de Nº 259.847.563-15, se encontra em fila de espera no Sistema de Regulação do Estado do Ceará, sem previsão de agendamento, sendo agendada para realização de procedimento cirúrgico no hospital municipal de Itapajé – CE, sendo encaminhado pelo médico cirurgião para realização de procedimento em Hospital Terciário.\n\nFICA AUTORIZADO a realização do procedimento cirúrgico pelo Programa Itapajé Mais Saúde para o paciente JOÃO BRITO GOMES.`,local:'Hospital Batista Memorial',procDate:'2026-04-11',procTime:'14:00',imsRef:imsCase.id,date:'2026-04-11',createdAt:Date.now()-2*86400000}]);
  },
};

/* ═════════════════════════════════════════
   Dashboard
═════════════════════════════════════════ */
const Dashboard = {
  refresh(){
    const ims=DB.getIMS(),pts=DB.getPatients(),oficios=DB.getOficiosAll();
    document.getElementById('stat-ims-total').textContent=ims.length;
    document.getElementById('stat-patients').textContent=pts.length;
    document.getElementById('stat-pending-aproval').textContent=ims.filter(x=>x.status==='Aguardando aprovação').length;
    document.getElementById('stat-ims-approved').textContent=ims.filter(x=>x.status==='Aprovado'||x.status==='Agendado'||x.status==='Realizado').length;
    document.getElementById('stat-oficios').textContent=oficios.length;
    // Badge nav IMS
    const pend=ims.filter(x=>x.status==='Aguardando aprovação').length;
    const nb=document.getElementById('ims-badge');if(nb){nb.textContent=pend;pend>0?nb.classList.remove('hidden'):nb.classList.add('hidden')}
    // IMS recentes
    const re=document.getElementById('dash-ims-recent');
    const recIMS=[...ims].sort((a,b)=>b.createdAt-a.createdAt).slice(0,5);
    re.innerHTML=recIMS.length===0?'<p style="color:var(--text-muted);font-size:12px;padding:.5rem 0">Nenhum caso cadastrado.</p>':recIMS.map(x=>`<div class="recent-item"><div><div class="recent-item-name">${Utils.esc(x.name)}</div><div class="recent-item-sub">${Utils.esc(x.solicitNum)} · ${Utils.esc(x.procedure?.split('—')[0]||'')}</div></div>${UI.statusBadge(x.status)}</div>`).join('');
    // Funnel IMS
    const fn=document.getElementById('dash-ims-funnel');
    const fSteps=[{l:'Em análise',s:'Em análise',c:'#f57c00'},{l:'Aguard. aprov.',s:'Aguardando aprovação',c:'#1976d2'},{l:'Aprovado',s:'Aprovado',c:'#2d7d32'},{l:'Agendado',s:'Agendado',c:'#00695c'},{l:'Realizado',s:'Realizado',c:'#6a1b9a'}];
    fn.innerHTML=fSteps.map(step=>{const cnt=ims.filter(x=>x.status===step.s).length;const pct=ims.length>0?Math.round((cnt/ims.length)*100):0;return`<div class="funnel-item"><span class="funnel-label">${step.l}</span><div class="funnel-track"><div class="funnel-fill" style="width:${pct}%;background:${step.c}"></div></div><span class="funnel-count">${cnt}</span></div>`}).join('');
    // Categorias gerais
    const gen=DB.getGeneral();const cats=['Transporte','Farmácia','Dieta','Fraldas','Prótese','Perícia'];
    const gcEl=document.getElementById('dash-general-cats');
    gcEl.innerHTML=cats.map(c=>{const cnt=gen.filter(x=>x.cat===c).length;const pct=gen.length>0?Math.round((cnt/gen.length)*100):0;return`<div class="funnel-item"><span class="funnel-label">${c}</span><div class="funnel-track"><div class="funnel-fill" style="width:${pct}%;background:#1976d2"></div></div><span class="funnel-count">${cnt}</span></div>`}).join('');
    // Ofícios recentes
    const or=document.getElementById('dash-oficios-recent');
    or.innerHTML=[...oficios].sort((a,b)=>b.createdAt-a.createdAt).slice(0,4).map(o=>`<div class="recent-item"><div><div class="recent-item-name">${Utils.esc(o.num)}</div><div class="recent-item-sub">${Utils.esc(o.subject?.slice(0,40)||o.type)}</div></div></div>`).join('')||'<p style="color:var(--text-muted);font-size:12px;padding:.5rem 0">Nenhum ofício emitido.</p>';
  },
};

/* ═════════════════════════════════════════
   IMS — Itapajé Mais Saúde
═════════════════════════════════════════ */
const IMS = {
  _filter:'', _statusFilter:'all', _procFilter:'all', _editId:null,
  openForm(id=null){
    this._editId=id;
    const f=document.getElementById('ims-form-section'),t=document.getElementById('ims-table-wrap'),d=document.getElementById('ims-detail');
    f.classList.remove('hidden');t.style.opacity='.35';t.style.pointerEvents='none';d.classList.add('hidden');
    document.getElementById('ims-form-title').textContent=id?'Editar Caso IMS':'Novo Caso — Itapajé Mais Saúde';
    if(id){this._fillForm(DB.getIMSCase(id))}
    else{this._clearForm();const num=Utils.genIMSNum();document.getElementById('ims-solicnum').value=num;document.getElementById('ims-num-preview').textContent='Nº: '+num;document.getElementById('ims-date').value=new Date().toISOString().split('T')[0]}
  },
  closeForm(){document.getElementById('ims-form-section').classList.add('hidden');const t=document.getElementById('ims-table-wrap');t.style.opacity='';t.style.pointerEvents='';this._editId=null},
  _clearForm(){['ims-id','ims-num','ims-solicnum','ims-name','ims-birth','ims-cpf','ims-rg','ims-rgorg','ims-phone','ims-profession','ims-address','ims-neighborhood','ims-reference','ims-income','ims-hospital','ims-hospital-address','ims-obs','ims-mother','ims-mother-prof','ims-mother-edu','ims-regulation'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});['ims-gender','ims-education','ims-income-range','ims-procedure'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});['elig-resident','elig-income','elig-fila','elig-indicacao','elig-docs'].forEach(id=>{const el=document.getElementById(id);if(el)el.checked=false});['ims-scheduled-date','ims-scheduled-time'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''})},
  _fillForm(c){
    if(!c)return;
    document.getElementById('ims-id').value=c.id;
    document.getElementById('ims-solicnum').value=c.solicitNum||'';
    document.getElementById('ims-num-preview').textContent='Nº: '+(c.solicitNum||'');
    const fields={date:'date',name:'name',birth:'birth',gender:'gender',cpf:'cpf',rg:'rg',rgOrg:'rgorg',phone:'phone',profession:'profession',education:'education',address:'address',neighborhood:'neighborhood',reference:'reference',income:'income',incomeRange:'income-range',housing:'housing',services:'services',mother:'mother',motherProf:'mother-prof',motherEdu:'mother-edu',regulation:'regulation',hospital:'hospital',scheduledDate:'scheduled-date',scheduledTime:'scheduled-time',hospitalAddress:'hospital-address',obs:'obs',procedure:'procedure'};
    Object.entries(fields).forEach(([k,fid])=>{const el=document.getElementById('ims-'+fid);if(el)el.value=c[k]||''});
    ['resident','income','fila','indicacao','docs'].forEach(k=>{const el=document.getElementById('elig-'+k);if(el)el.checked=c['elig'+k.charAt(0).toUpperCase()+k.slice(1)]||false});
  },
  save(){
    const name=document.getElementById('ims-name').value.trim();
    const proc=document.getElementById('ims-procedure').value;
    const phone=document.getElementById('ims-phone').value.trim();
    if(!name||!proc||!phone){UI.toast('Preencha nome, procedimento e telefone.','error');return}
    const id=document.getElementById('ims-id').value||Utils.uid();
    const ex=DB.getIMSCase(id);
    const solicitNum=document.getElementById('ims-solicnum').value||Utils.genIMSNum();
    const gv=fid=>(document.getElementById('ims-'+fid)||{}).value||'';
    const item={
      id,solicitNum,date:gv('date'),procedure:proc,
      name,birth:gv('birth'),gender:gv('gender'),cpf:gv('cpf'),rg:gv('rg'),rgOrg:gv('rgorg'),
      phone,profession:gv('profession'),education:gv('education'),
      address:gv('address'),neighborhood:gv('neighborhood'),reference:gv('reference'),
      income:gv('income'),incomeRange:gv('income-range'),housing:gv('housing'),services:gv('services'),
      mother:gv('mother'),motherProf:gv('mother-prof'),motherEdu:gv('mother-edu'),
      regulation:gv('regulation'),hospital:gv('hospital'),scheduledDate:gv('scheduled-date'),
      scheduledTime:gv('scheduled-time'),hospitalAddress:gv('hospital-address'),obs:gv('obs'),
      eligResident:document.getElementById('elig-resident')?.checked||false,
      eligIncome:document.getElementById('elig-income')?.checked||false,
      eligFila:document.getElementById('elig-fila')?.checked||false,
      eligIndicacao:document.getElementById('elig-indicacao')?.checked||false,
      eligDocs:document.getElementById('elig-docs')?.checked||false,
      status:ex?.status||'Em análise',createdAt:ex?.createdAt||Date.now(),updatedAt:Date.now(),
    };
    DB.upsertIMS(item);this.closeForm();this.renderTable();Dashboard.refresh();
    UI.toast(ex?'Caso IMS atualizado!':'Caso IMS cadastrado! Nº '+solicitNum);
  },
  search(q){this._filter=q.toLowerCase();this.renderTable()},
  renderTable(){
    let data=DB.getIMS();
    const sf=document.getElementById('ims-filter-status')?.value||'all';
    const pf=document.getElementById('ims-filter-proc')?.value||'all';
    if(sf!=='all')data=data.filter(x=>x.status===sf);
    if(pf!=='all')data=data.filter(x=>x.procedure?.toLowerCase().includes(pf.toLowerCase()));
    if(this._filter)data=data.filter(x=>x.name?.toLowerCase().includes(this._filter)||x.solicitNum?.includes(this._filter)||x.cpf?.includes(this._filter));
    const tb=document.getElementById('ims-tbody');
    if(!tb)return;
    if(data.length===0){tb.innerHTML='<tr class="empty-row"><td colspan="7">Nenhum caso encontrado.</td></tr>';return}
    tb.innerHTML=[...data].sort((a,b)=>b.createdAt-a.createdAt).map(x=>`
      <tr>
        <td><span class="table-num">${Utils.esc(x.solicitNum)}</span></td>
        <td class="table-name">${Utils.esc(x.name)}</td>
        <td>${Utils.esc(x.procedure?.split('—')[1]?.trim()||x.procedure||'—')}</td>
        <td>${Utils.fDate(x.date)}</td>
        <td>${UI.statusBadge(x.status)}</td>
        <td>${UI.miniProgress(x.status)}</td>
        <td><div class="table-actions">
          <button onclick="IMS.openDetail('${x.id}')">Detalhe</button>
          <button onclick="IMS.openForm('${x.id}')">Editar</button>
          <button onclick="Oficios.openFromIMS('${x.id}')">Ofício</button>
          <button class="btn-delete" onclick="IMS.del('${x.id}','${Utils.esc(x.name)}')">Excluir</button>
        </div></td>
      </tr>`).join('');
  },
  openDetail(id){
    const c=DB.getIMSCase(id);if(!c)return;
    document.getElementById('ims-form-section').classList.add('hidden');
    const d=document.getElementById('ims-detail');d.classList.remove('hidden');
    document.getElementById('ims-detail-title').textContent=c.name;
    document.getElementById('ims-detail-num').textContent='Nº '+c.solicitNum;
    const elig=[c.eligResident,c.eligIncome,c.eligFila,c.eligIndicacao,c.eligDocs];
    const eligLabels=['Residente em Itapajé','Renda ≤ 2 sal.','Fila SUS sem previsão','Indicação médica','Documentação OK'];
    const eligHtml=elig.map((v,i)=>`<span style="color:${v?'var(--green)':'var(--red)'};font-size:13px">${v?'✓':'✗'} ${eligLabels[i]}</span>`).join(' · ');
    const hist=DB.getHistory(id);
    document.getElementById('ims-detail-content').innerHTML=`
      <div class="ims-detail-grid">
        <div class="ims-detail-field"><div class="ims-detail-field-label">Nº Solicitação</div><div class="ims-detail-field-value">${Utils.esc(c.solicitNum)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Status</div><div class="ims-detail-field-value">${UI.statusBadge(c.status)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Procedimento</div><div class="ims-detail-field-value">${Utils.esc(c.procedure)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Data de Nasc.</div><div class="ims-detail-field-value">${Utils.fDate(c.birth)} (${Utils.age(c.birth)})</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">CPF</div><div class="ims-detail-field-value">${Utils.esc(c.cpf)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Telefone</div><div class="ims-detail-field-value">${Utils.esc(c.phone)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Endereço</div><div class="ims-detail-field-value">${Utils.esc(c.address+', '+c.neighborhood)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Renda Familiar</div><div class="ims-detail-field-value">R$ ${Utils.esc(c.income)} — ${Utils.esc(c.incomeRange)}</div></div>
        <div class="ims-detail-field"><div class="ims-detail-field-label">Hospital</div><div class="ims-detail-field-value">${Utils.esc(c.hospital)} · ${Utils.fDate(c.scheduledDate)} ${c.scheduledTime||''}</div></div>
      </div>
      <div style="margin:.75rem 0;padding:.75rem;background:var(--green-light);border-radius:var(--radius);border:1px solid var(--green-border)"><strong>Elegibilidade:</strong> ${eligHtml}</div>
      ${c.regulation?`<div style="margin:.5rem 0;font-size:13px;color:var(--text-secondary)"><strong>Regulação:</strong> ${Utils.esc(c.regulation)}</div>`:''}
      ${c.obs?`<div style="margin:.5rem 0;font-size:13px;color:var(--text-secondary)"><strong>Obs:</strong> ${Utils.esc(c.obs)}</div>`:''}
      <div style="border-top:1px solid var(--border);margin-top:1rem;padding-top:.75rem">
        <strong style="font-size:13px">Barra de Progresso:</strong>
        <div id="ims-detail-progress" class="progress-bar-wrap" style="margin-top:.5rem"><div class="progress-steps" id="ims-det-prog-steps"></div></div>
      </div>
      <div style="margin-top:.75rem"><strong style="font-size:13px">Histórico:</strong>
        <div class="history-list" style="margin-top:.5rem">
          ${hist.length===0?'<p style="color:var(--text-muted);font-size:12px">Sem atualizações.</p>':hist.map(h=>`<div class="history-item st-${(h.status||'').toLowerCase().replace(/ /g,'-').replace(/ç/g,'c').replace(/ã/g,'a')}"><div class="history-meta">${UI.statusBadge(h.status)}<span class="history-date">${Utils.fDT(h.at)}</span></div><div class="history-obs">${Utils.esc(h.obs)}</div></div>`).join('')}
        </div>
      </div>
      <div class="form-actions" style="margin-top:1rem">
        <button class="btn-outline" onclick="IMS.openForm('${id}')">Editar Caso</button>
        <button class="btn-whatsapp" onclick="WhatsApp.notifyFromIMS('${id}')">📱 Notificar WhatsApp</button>
        <button class="btn-green" onclick="Oficios.openFromIMS('${id}')">📄 Gerar Ofício</button>
        <button class="btn-green" onclick="Print.printIMS('${id}')">🖨 Imprimir</button>
      </div>`;
    setTimeout(()=>UI.progressBar(c.status,'ims-det-prog-steps'),50);
  },
  closeDetail(){document.getElementById('ims-detail').classList.add('hidden')},
  del(id,name){
    document.getElementById('delete-item-name').textContent=name;
    document.getElementById('modal-delete-confirm-btn').onclick=()=>{DB.deleteIMS(id);UI.closeModal('modal-confirm-delete');this.renderTable();Dashboard.refresh();UI.toast('Caso excluído.')};
    UI.showModal('modal-confirm-delete');
  },
};

/* ═════════════════════════════════════════
   Patients
═════════════════════════════════════════ */
const Patients = {
  _filter:'', _delId:null,
  openForm(id=null){
    const f=document.getElementById('patient-form-section');f.classList.remove('hidden');
    document.getElementById('patient-form-title').textContent=id?'Editar Paciente':'Novo Paciente';
    if(id){const p=DB.getPatient(id);if(!p)return;document.getElementById('patient-id').value=p.id;['name','birth','gender','cpf','phone','street','number','neighborhood','mother','father','financial','benefits','obs'].forEach(k=>{const el=document.getElementById('p-'+k);if(el)el.value=p[k]||''})}
    else{document.getElementById('patient-id').value='';['name','birth','cpf','phone','street','number','neighborhood','mother','father','benefits','obs'].forEach(id=>{const el=document.getElementById('p-'+id);if(el)el.value=''});['p-gender','p-financial'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''})}
  },
  closeForm(){document.getElementById('patient-form-section').classList.add('hidden')},
  save(){
    const gv=id=>document.getElementById('p-'+id)?.value.trim()||'';
    const name=gv('name'),phone=gv('phone'),street=gv('street'),neighborhood=gv('neighborhood');
    if(!name||!phone||!street||!neighborhood){UI.toast('Preencha os campos obrigatórios.','error');return}
    const id=document.getElementById('patient-id').value||Utils.uid();
    const ex=DB.getPatient(id);
    const p={id,name,birth:gv('birth'),gender:document.getElementById('p-gender')?.value||'',cpf:gv('cpf'),phone,street,number:gv('number'),neighborhood,city:'Itapajé',mother:gv('mother'),father:gv('father'),financial:document.getElementById('p-financial')?.value||'',benefits:gv('benefits'),obs:gv('obs'),status:ex?.status||'Em análise',createdAt:ex?.createdAt||Date.now(),updatedAt:Date.now()};
    DB.upsertPatient(p);this.closeForm();this.renderTable();Dashboard.refresh();UI.toast(ex?'Paciente atualizado!':'Paciente cadastrado!');
  },
  search(q){this._filter=q.toLowerCase();this.renderTable()},
  renderTable(){
    let pts=DB.getPatients();if(this._filter)pts=pts.filter(p=>p.name?.toLowerCase().includes(this._filter)||(p.cpf&&p.cpf.includes(this._filter))||(p.phone&&p.phone.includes(this._filter)));
    const tb=document.getElementById('patients-tbody');if(!tb)return;
    if(pts.length===0){tb.innerHTML='<tr class="empty-row"><td colspan="6">Nenhum paciente encontrado.</td></tr>';return}
    tb.innerHTML=[...pts].sort((a,b)=>b.createdAt-a.createdAt).map(p=>`<tr><td class="table-name">${Utils.esc(p.name)}</td><td>${Utils.fDate(p.birth)}</td><td>${Utils.esc(p.phone)}</td><td>${Utils.esc(p.neighborhood)}</td><td>${UI.statusBadge(p.status)}</td><td><div class="table-actions"><button onclick="Patients.openForm('${p.id}')">Editar</button><button class="btn-delete" onclick="Patients.del('${p.id}','${Utils.esc(p.name)}')">Excluir</button></div></td></tr>`).join('');
  },
  del(id,name){document.getElementById('delete-item-name').textContent=name;document.getElementById('modal-delete-confirm-btn').onclick=()=>{DB.deletePatient(id);UI.closeModal('modal-confirm-delete');this.renderTable();UI.toast('Paciente excluído.')};UI.showModal('modal-confirm-delete')},
};

/* ═════════════════════════════════════════
   General Atendimentos
═════════════════════════════════════════ */
const General = {
  _cat:'all',
  filterCat(cat,btn){this._cat=cat;document.querySelectorAll('.cat-tab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');this.renderTable()},
  openForm(){
    const f=document.getElementById('general-form');f.classList.remove('hidden');
    const sel=document.getElementById('gen-patient');
    const pts=DB.getPatients().sort((a,b)=>a.name.localeCompare(b.name));
    sel.innerHTML='<option value="">— Selecionar —</option>'+pts.map(p=>`<option value="${p.id}">${Utils.esc(p.name)}</option>`).join('');
    document.getElementById('gen-date').value=new Date().toISOString().split('T')[0];
  },
  closeForm(){document.getElementById('general-form').classList.add('hidden')},
  save(){
    const pid=document.getElementById('gen-patient').value,cat=document.getElementById('gen-cat').value,desc=document.getElementById('gen-desc').value.trim();
    if(!cat||!desc){UI.toast('Preencha categoria e descrição.','error');return}
    const all=DB.getGeneral();
    all.push({id:Utils.uid(),patientId:pid,patientName:pid?DB.getPatient(pid)?.name||'—':'—',cat,date:document.getElementById('gen-date').value,desc,obs:document.getElementById('gen-obs').value.trim(),status:'Em análise',createdAt:Date.now()});
    DB.saveGeneral(all);this.closeForm();this.renderTable();Dashboard.refresh();UI.toast('Atendimento registrado!');
  },
  renderTable(){
    let data=DB.getGeneral();if(this._cat!=='all')data=data.filter(x=>x.cat===this._cat);
    const tb=document.getElementById('general-tbody');if(!tb)return;
    if(data.length===0){tb.innerHTML='<tr class="empty-row"><td colspan="6">Nenhum atendimento encontrado.</td></tr>';return}
    tb.innerHTML=[...data].sort((a,b)=>b.createdAt-a.createdAt).map(x=>`<tr><td class="table-name">${Utils.esc(x.patientName)}</td><td>${Utils.esc(x.cat)}</td><td>${Utils.esc(x.desc?.slice(0,60))}${x.desc?.length>60?'...':''}</td><td>${Utils.fDate(x.date)}</td><td>${UI.statusBadge(x.status)}</td><td><div class="table-actions"><button class="btn-delete" onclick="General.del('${x.id}')">Excluir</button></div></td></tr>`).join('');
  },
  del(id){DB.saveGeneral(DB.getGeneral().filter(x=>x.id!==id));this.renderTable();Dashboard.refresh();UI.toast('Removido.')},
};

/* ═════════════════════════════════════════
   StatusMod
═════════════════════════════════════════ */
const StatusMod = {
  _id:null, _type:null,
  init(){
    const sel=document.getElementById('status-select');if(!sel)return;
    const ims=DB.getIMS().sort((a,b)=>a.name.localeCompare(b.name));
    const pts=DB.getPatients().sort((a,b)=>a.name.localeCompare(b.name));
    sel.innerHTML='<option value="">— Selecionar —</option><optgroup label="IMS — Itapajé Mais Saúde">'+ims.map(x=>`<option value="ims:${x.id}">[IMS] ${Utils.esc(x.name)} · ${Utils.esc(x.solicitNum)}</option>`).join('')+'</optgroup><optgroup label="Pacientes Gerais">'+pts.map(p=>`<option value="pat:${p.id}">${Utils.esc(p.name)}</option>`).join('')+'</optgroup>';
    if(this._id)sel.value=this._type+':'+this._id;
  },
  load(val){
    const panel=document.getElementById('status-panel'),pw=document.getElementById('status-progress-bar');
    if(!val){panel.classList.add('hidden');pw.classList.add('hidden');return}
    const[type,id]=val.split(':');this._type=type;this._id=id;
    const item=type==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    document.getElementById('status-value').value=item.status||'Em análise';document.getElementById('status-obs').value='';
    panel.classList.remove('hidden');pw.classList.remove('hidden');
    UI.progressBar(item.status,'progress-steps');
    this.renderHistory();
  },
  update(){
    if(!this._id||!this._type)return;
    const ns=document.getElementById('status-value').value,obs=document.getElementById('status-obs').value.trim();
    const session=DB.getSession();
    const item=this._type==='ims'?DB.getIMSCase(this._id):DB.getPatient(this._id);if(!item)return;
    DB.addHistory(this._id,{id:Utils.uid(),status:ns,obs:obs||'(sem observação)',user:session?.user||'Sistema',at:Date.now()});
    item.status=ns;item.updatedAt=Date.now();
    if(this._type==='ims')DB.upsertIMS(item);else DB.upsertPatient(item);
    document.getElementById('status-obs').value='';UI.progressBar(ns,'progress-steps');this.renderHistory();Dashboard.refresh();UI.toast('Status atualizado!');
  },
  renderHistory(){
    const h=DB.getHistory(this._id),el=document.getElementById('status-history');if(!el)return;
    el.innerHTML=h.length===0?'<p style="color:var(--text-muted);font-size:12px">Sem histórico.</p>':h.map(x=>{const cls=x.status?.toLowerCase().replace(/ /g,'-').replace(/ç/g,'c').replace(/ã/g,'a').replace(/ó/g,'o');return`<div class="history-item st-${cls}"><div class="history-meta">${UI.statusBadge(x.status)}<span class="history-date">${Utils.fDT(x.at)}</span><span style="font-size:11px;color:var(--text-muted)">por ${Utils.esc(x.user)}</span></div><div class="history-obs">${Utils.esc(x.obs)}</div></div>`}).join('');
  },
  currentItem(){return this._id?(this._type==='ims'?DB.getIMSCase(this._id):DB.getPatient(this._id)):null},
};

/* ═════════════════════════════════════════
   Oficios — Numeração NNN/AAAA
═════════════════════════════════════════ */
const Oficios = {
  _id:null,
  openForm(id=null){
    this._id=id;const f=document.getElementById('oficio-form');f.classList.remove('hidden');
    document.getElementById('oficio-form-title').textContent=id?'Editar Documento':'Novo Documento';
    // Popula referência IMS
    const ims=DB.getIMS().sort((a,b)=>a.name.localeCompare(b.name));
    const ref=document.getElementById('oficio-ims-ref');
    ref.innerHTML='<option value="">— Nenhum —</option>'+ims.map(x=>`<option value="${x.id}">[${Utils.esc(x.solicitNum)}] ${Utils.esc(x.name)}</option>`).join('');
    if(id){const o=DB.getOficiosAll().find(x=>x.id===id);if(o){document.getElementById('oficio-id').value=o.id;['num','dest','subject','body','local'].forEach(k=>{const el=document.getElementById('oficio-'+k);if(el)el.value=o[k]||''});['date','proc-date','proc-time'].forEach(k=>{const el=document.getElementById('oficio-'+k);if(el)el.value=o[k.replace('-','')]||o[k]||''});const tel=document.getElementById('oficio-type');if(tel)tel.value=o.type||'oficio';const rel=document.getElementById('oficio-ims-ref');if(rel)rel.value=o.imsRef||'';document.getElementById('oficio-num-preview').textContent='Nº: '+o.num}}
    else{document.getElementById('oficio-id').value='';const num=Utils.genOficioNum();document.getElementById('oficio-num').value=num;document.getElementById('oficio-num-preview').textContent='Nº: '+num;document.getElementById('oficio-date').value=new Date().toISOString().split('T')[0];['oficio-dest','oficio-subject','oficio-body','oficio-local'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});['oficio-proc-date','oficio-proc-time'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''})}
  },
  openFromIMS(imsId){
    const c=DB.getIMSCase(imsId);if(!c)return;
    this.openForm();
    document.getElementById('oficio-type').value='autorizacao';
    document.getElementById('oficio-dest').value=c.name;
    document.getElementById('oficio-subject').value=`Autorização para Procedimento — Programa Itapajé Mais Saúde — ${c.name}`;
    document.getElementById('oficio-ims-ref').value=imsId;
    document.getElementById('oficio-local').value=c.hospital||'';
    document.getElementById('oficio-proc-date').value=c.scheduledDate||'';
    document.getElementById('oficio-proc-time').value=c.scheduledTime||'';
    const resp=DB.getResp();
    const body=`O paciente ${c.name.toUpperCase()}, portador do CPF de Nº ${c.cpf||'—'}, se encontra em fila de espera no Sistema de Regulação do Estado do Ceará, sem previsão de agendamento, sendo agendada para realização de procedimento cirúrgico no hospital municipal de Itapajé – CE, sendo encaminhado pelo médico cirurgião para realização de procedimento em Hospital Terciário.\n\nFICA AUTORIZADO a realização do procedimento cirúrgico pelo Programa Itapajé Mais Saúde para o paciente ${c.name.toUpperCase()}.`;
    document.getElementById('oficio-body').value=body;
    UI.switchTab('oficios',document.querySelector('[data-tab=oficios]'));
  },
  updateTemplate(){},
  closeForm(){document.getElementById('oficio-form').classList.add('hidden');this._id=null},
  save(){
    const body=document.getElementById('oficio-body').value.trim();
    if(!body){UI.toast('Preencha o corpo do documento.','error');return}
    const id=document.getElementById('oficio-id').value||Utils.uid();
    const num=document.getElementById('oficio-num').value;
    const o={id,num,type:document.getElementById('oficio-type').value,dest:document.getElementById('oficio-dest').value.trim(),subject:document.getElementById('oficio-subject').value.trim(),body,local:document.getElementById('oficio-local').value.trim(),procDate:document.getElementById('oficio-proc-date').value,procTime:document.getElementById('oficio-proc-time').value,imsRef:document.getElementById('oficio-ims-ref').value,date:document.getElementById('oficio-date').value,createdAt:Date.now()};
    const all=DB.getOficiosAll();const idx=all.findIndex(x=>x.id===id);if(idx>=0)all[idx]=o;else all.push(o);
    DB.saveOficios(all);this.closeForm();this.renderTable();Dashboard.refresh();UI.toast('Documento salvo! Nº '+num);
  },
  renderTable(){
    const all=DB.getOficiosAll();const tb=document.getElementById('oficios-tbody');if(!tb)return;
    if(all.length===0){tb.innerHTML='<tr class="empty-row"><td colspan="5">Nenhum ofício emitido.</td></tr>';return}
    tb.innerHTML=[...all].sort((a,b)=>b.createdAt-a.createdAt).map(o=>`<tr><td><span class="table-num">${Utils.esc(o.num)}</span></td><td>${Utils.esc(o.type)}</td><td>${Utils.esc(o.dest?.slice(0,40))}</td><td>${Utils.fDate(o.date)}</td><td><div class="table-actions"><button onclick="Oficios.openForm('${o.id}')">Editar</button><button onclick="Oficios.printPreviewOf('${o.id}')">Imprimir</button><button class="btn-delete" onclick="Oficios.del('${o.id}')">Excluir</button></div></td></tr>`).join('');
  },
  printPreview(){const id=document.getElementById('oficio-id').value;if(id)this.printPreviewOf(id);else UI.toast('Salve o documento primeiro.','error')},
  printPreviewOf(id){const o=DB.getOficiosAll().find(x=>x.id===id);if(!o)return;const html=Print.buildOficioPage(o);document.getElementById('print-preview-content').innerHTML=html;UI.showModal('modal-print-preview')},
  del(id){DB.saveOficios(DB.getOficiosAll().filter(x=>x.id!==id));this.renderTable();Dashboard.refresh();UI.toast('Documento excluído.')},
};

/* ═════════════════════════════════════════
   Relatorio Social
═════════════════════════════════════════ */
const Relatorio = {
  _lastReport:'', _imsCase:null,
  init(){
    const sel=document.getElementById('rel-ims-select');if(!sel)return;
    sel.innerHTML='<option value="">— Caso IMS —</option>'+DB.getIMS().sort((a,b)=>a.name.localeCompare(b.name)).map(x=>`<option value="${x.id}">[${Utils.esc(x.solicitNum)}] ${Utils.esc(x.name)}</option>`).join('');
  },
  loadIMS(id){this._imsCase=id?DB.getIMSCase(id):null},
  generate(){
    const mode=document.querySelector('input[name="ai-mode"]:checked')?.value||'objetivo';
    const out=document.getElementById('rel-output'),typing=document.getElementById('rel-typing'),actions=document.getElementById('rel-report-actions');
    out.innerHTML='';out.style.display='none';typing.classList.remove('hidden');actions.classList.add('hidden');
    const data={q1:document.getElementById('q1').value.trim(),q2:document.getElementById('q2').value,q3:document.getElementById('q3').value,q4:document.getElementById('q4').value,q5:document.getElementById('q5').value,q6:document.getElementById('q6').value.trim(),q7:document.getElementById('q7').value.trim(),q8:document.getElementById('q8').value.trim(),q9:document.getElementById('q9').value};
    setTimeout(()=>{
      const report=mode==='formal'?this._formal(this._imsCase,data):this._objetivo(this._imsCase,data);
      this._lastReport=report;typing.classList.add('hidden');out.style.display='';out.innerHTML='';
      this._type(out,report,()=>{actions.classList.remove('hidden');DB.addReport({id:Utils.uid(),imsId:this._imsCase?.id,patientName:this._imsCase?.name||'Geral',text:report,mode,at:Date.now()})});
    },1300+Math.random()*500);
  },
  _type(el,text,cb){el.textContent='';let i=0;const sp=Math.max(4,Math.min(12,3000/text.length));const t=setInterval(()=>{el.textContent+=text[i++];el.scrollTop=el.scrollHeight;if(i>=text.length){clearInterval(t);if(cb)cb()}},sp)},
  _objetivo(c,d){
    const r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    const name=c?.name||'Paciente não identificado';
    return`RELATÓRIO SOCIAL — SERVIÇO DE APOIO SOCIAL\nItapajé/CE, ${today}\n${c?'Nº: '+c.solicitNum+' | Proc.: '+c.procedure:''}\n\n${'━'.repeat(45)}\nDADOS DO PACIENTE\n${'━'.repeat(45)}\nNome: ${name}${c?'\nNasc.: '+Utils.fDate(c.birth)+' ('+Utils.age(c.birth)+')\nCPF: '+(c.cpf||'—')+' | Telefone: '+c.phone+'\nEndereço: '+c.address+', '+c.neighborhood+', Itapajé/CE'+'\nRenda: R$ '+c.income+' — '+c.incomeRange:''}

${'━'.repeat(45)}\nAVALIAÇÃO SOCIAL\n${'━'.repeat(45)}\n${d.q1?'Situação: '+d.q1:''}${d.q2?'\nRenda: '+d.q2:''}${d.q3?'\nApoio familiar: '+d.q3:''}${d.q4?'\nTransporte: '+d.q4:''}${d.q5?'\nTratamento: '+d.q5:''}${d.q6?'\nVulnerabilidade: '+d.q6:''}${d.q7?'\nDemandas: '+d.q7:''}${d.q8?'\nEncaminhamentos: '+d.q8:''}${d.q9?'\nForma de Resolução: '+d.q9:''}

${'━'.repeat(45)}\nCONCLUSÃO\n${'━'.repeat(45)}\nO(A) paciente ${name} apresenta situação de vulnerabilidade social${c?' e foi incluído(a) no Programa Itapajé Mais Saúde (Lei Municipal nº 2.399/2025) para realização de '+c.procedure:''}, sendo recomendado acompanhamento continuado pelo Serviço de Apoio Social.

${r.socialName||'_______________________'}\n${r.socialReg||'CRESS nº _____________'}\n\n${r.managerName||'Francisco Maílson de Sousa Moreira'}\n${r.managerRole||'Gerente de Apoio Social'}\n${r.unit||'Secretaria Municipal de Saúde'} — Itapajé/CE\n${today}`;
  },
  _formal(c,d){
    const r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    const name=c?.name||'paciente';
    return`SECRETARIA MUNICIPAL DE SAÚDE — ITAPAJÉ/CE\n${r.unit?r.unit.toUpperCase():'SERVIÇO DE APOIO SOCIAL'}\nRELATÓRIO DE AVALIAÇÃO SOCIOECONÔMICA\n${c?'PROGRAMA ITAPAJÉ MAIS SAÚDE — Lei Municipal nº 2.399/2025':''}\n\nItapajé/CE, ${today}\n${'═'.repeat(55)}\n\nI. IDENTIFICAÇÃO\n\nO presente relatório refere-se ao(à) paciente ${name.toUpperCase()}${c?', nascido(a) em '+Utils.fDate(c.birth)+' ('+Utils.age(c.birth)+'), portador(a) do CPF nº '+c.cpf+', residente em '+c.address+', '+c.neighborhood+', Itapajé/CE, telefone '+c.phone+'. Profissão: '+(c.profession||'não informada')+'. Escolaridade: '+(c.education||'não informada')+'.'  :'.'}\n\n${c?.mother?'Mãe: '+c.mother+(c.motherProf?', '+c.motherProf:'')+'.\n\n':''}\nII. SITUAÇÃO SOCIOECONÔMICA\n\n${c?'O(A) paciente possui renda familiar de R$ '+c.income+' ('+c.incomeRange+'). Situação habitacional: '+c.housing+', '+c.services+'.':''}\n${d.q2?'Condição de renda: '+d.q2+'.':''} ${d.q3?'Apoio familiar: '+d.q3+'.':''}\n\nIII. AVALIAÇÃO SOCIAL\n\n${d.q1?'Situação atual: '+d.q1+'\n\n':''}${d.q4?'Necessidade de transporte: '+d.q4+'.\n':''}${d.q5?'Tratamento de saúde: '+d.q5+'.\n':''}\n\nIV. VULNERABILIDADE E DEMANDAS\n\n${d.q6||'Situação de vulnerabilidade social identificada.'}${d.q7?'\n\nDemandas identificadas: '+d.q7:''}\n\nV. ENCAMINHAMENTOS E RESOLUÇÃO\n\n${d.q8?'Encaminhamentos: '+d.q8+'\n\n':''}${d.q9?'Forma de resolução: '+d.q9+'\n\n':''}${c?'O(A) paciente '+name+' foi incluído(a) no Programa Itapajé Mais Saúde (Lei Municipal nº 2.399/2025, Decreto nº 49/2025) para realização de '+c.procedure+', conforme autorização nº '+c.solicitNum+', atendendo aos critérios de elegibilidade do programa.':''}\n\n${c?.regulation?'Regulação: '+c.regulation+'\n\n':''}\nVI. CONCLUSÃO\n\nDiante do exposto, recomenda-se o acompanhamento sistemático do caso pelo Serviço de Apoio Social da ${r.unit||'Secretaria Municipal de Saúde'} — Itapajé/CE, bem como a articulação intersetorial com a rede socioassistencial para garantia da integralidade das ações no âmbito do SUAS e do SUS.\n\n${'═'.repeat(55)}\n\n${r.socialName||'___________________________'}\n${r.socialReg||'CRESS nº _____________'}\n\n${r.managerName||'Francisco Maílson de Sousa Moreira'}\n${r.managerRole||'Gerente de Apoio Social'}\n\n${r.unit||'Secretaria Municipal de Saúde'}\n${r.unitAddress||'R. São Francisco, Nº 225 Centro'}\n${r.unitPhone||' 99126-4880'} — Itapajé/CE\n${today}`;
  },
  copy(){navigator.clipboard.writeText(this._lastReport).then(()=>UI.toast('Copiado!')).catch(()=>UI.toast('Erro.','error'))},
  save(){if(this._lastReport)UI.toast('Relatório salvo no sistema!')},
  print(){if(!this._lastReport){UI.toast('Gere um relatório primeiro.','error');return}const html=Print.buildRelatorioPage(this._lastReport);document.getElementById('print-preview-content').innerHTML=html;UI.showModal('modal-print-preview')},
};

/* ═════════════════════════════════════════
   WhatsApp — Mensagens ultra-objetivas
═════════════════════════════════════════ */
const WhatsApp = {
  _pid:null, _ptype:null,
  init(){
    this._popSelects();this.renderHistory();
    const gp=DB.getGabPhone();if(gp)document.getElementById('gabinete-phone').value=gp;
  },
  _popSelects(){
    const ims=DB.getIMS().sort((a,b)=>a.name.localeCompare(b.name));
    const pts=DB.getPatients().sort((a,b)=>a.name.localeCompare(b.name));
    const opts='<option value="">— Selecionar —</option><optgroup label="IMS">'+ims.map(x=>`<option value="ims:${x.id}">[IMS] ${Utils.esc(x.name)}</option>`).join('')+'</optgroup><optgroup label="Pacientes Gerais">'+pts.map(p=>`<option value="pat:${p.id}">${Utils.esc(p.name)}</option>`).join('')+'</optgroup>';
    ['wa-patient-select','wa-gab-patient'].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML=opts});
  },
  loadPatientWA(val){
    const info=document.getElementById('wa-patient-info');
    if(!val){info.classList.add('hidden');return}
    const[type,id]=val.split(':');this._pid=id;this._ptype=type;
    const item=type==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    document.getElementById('wa-p-name').textContent=item.name;
    document.getElementById('wa-p-phone').textContent=item.phone;
    document.getElementById('wa-p-status').innerHTML=UI.statusBadge(item.status);
    info.classList.remove('hidden');this.previewMsg();
  },
  previewMsg(){
    const val=document.getElementById('wa-patient-select').value;
    const type=document.getElementById('wa-msg-type').value;
    document.getElementById('wa-custom-group').style.display=type==='custom'?'flex':'none';
    if(!val){document.getElementById('wa-bubble-text').textContent='Selecione um paciente.';return}
    const[ptype,id]=val.split(':');const item=ptype==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    document.getElementById('wa-bubble-text').textContent=this._buildPatientMsg(item,type);
  },
  _buildPatientMsg(item,type){
    const r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR'),unit=r.unit||'Secretaria de Saúde — Itapajé/CE';
    const msgs={
      status:`Olá, *${item.name}*! 👋\n\nInformamos que seu processo junto ao *${unit}* foi atualizado.\n\n📋 *Status:* ${item.status}${item.solicitNum?'\n🔢 *Nº:* '+item.solicitNum:''}\n\nDúvidas: ${r.unitPhone||' 99126-4880'}\n\n_Equipe de Apoio Social — ${today}_`,
      aprovado:`✅ *${item.name}*, seu processo foi *APROVADO* pelo Programa Itapajé Mais Saúde!\n\n${item.procedure?'📋 Procedimento: '+item.procedure:''}${item.scheduledDate?'\n📅 Data: '+Utils.fDate(item.scheduledDate):''} ${item.scheduledTime?'às '+item.scheduledTime:''}\n${item.hospital?'🏥 Local: '+item.hospital:''}${item.hospitalAddress?'\n📍 '+item.hospitalAddress:''}\n\nComapareça munido de documentos de identidade.\n\nDúvidas: ${r.unitPhone||' 99126-4880'}\n_Sec. Saúde Itapajé — ${today}_`,
      pendente:`⚠️ *${item.name}*, seu processo está *PENDENTE DE DOCUMENTAÇÃO*.\n\nPor favor, dirija-se à *${unit}* para regularizar sua situação.\n\n📍 ${r.unitAddress||'R. São Francisco, Nº 225 Centro'}\n📞 ${r.unitPhone||' 99126-4880'}\n\n_${today}_`,
      agendamento:`📅 *${item.name}*, seu procedimento foi *AGENDADO*!\n\n${item.procedure?'📋 '+item.procedure:''}${item.scheduledDate?'\n🗓 Data: '+Utils.fDate(item.scheduledDate)+' às '+(item.scheduledTime||'—'):''}\n${item.hospital?'🏥 '+item.hospital:''}${item.hospitalAddress?'\n📍 '+item.hospitalAddress:''}\n\nLeve documento de identidade e comprovante de residência.\n📞 ${r.unitPhone||' 99126-4880'}\n_Sec. Saúde Itapajé — ${today}_`,
      reprovado:`❌ *${item.name}*, infelizmente seu processo *não foi aprovado* neste momento.\n\nProcure a *${unit}* para mais informações sobre o processo e possíveis alternativas.\n\n📞 ${r.unitPhone||' 99126-4880'}\n📍 ${r.unitAddress||'R. São Francisco, Nº 225 Centro'}\n\n_${today}_`,
      custom:document.getElementById('wa-custom-msg')?.value||'',
    };
    return msgs[type]||msgs.status;
  },
  _buildGabineteMsg(item,type,parecer,visitDate){
    const r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    const base=`*SECRETARIA MUNICIPAL DE SAÚDE — ITAPAJÉ/CE*\n*${r.unit||'Serviço de Apoio Social'}*\n_${today}_\n\n`;
    if(type==='solicitacao_total'){
      return base+`*━━ SOLICITAÇÃO TOTAL ━━*\n\n📋 *Paciente:* ${item.name}\n🔢 *Nº Solicitação:* ${item.solicitNum||'—'}\n📅 *Data do Pedido:* ${Utils.fDate(item.date)}\n📅 *Data da Visita Social:* ${Utils.fDate(visitDate)}\n\n🏥 *Procedimento:* ${item.procedure||'—'}\n👨‍⚕️ *Hospital:* ${item.hospital||'—'}\n\n📊 *Parecer Técnico:*\n${parecer||'Paciente apresenta critérios de elegibilidade para o Programa Itapajé Mais Saúde.'}\n\n*CPF:* ${item.cpf||'—'} | *Renda:* R$ ${item.income||'—'} (${item.incomeRange||'—'})\n*Endereço:* ${item.address||'—'}, ${item.neighborhood||'—'}, Itapajé/CE\n\n✅ [APROVAR] ❌ [REPROVAR]\n\n_${r.managerName||'Gerente de Apoio Social'}_\n_${r.unit}_`;
    }
    const msgs={
      parecer:`${base}📋 *PARECER SOCIAL*\n\nPaciente: *${item.name}*\nNº: ${item.solicitNum||'—'} | Status: ${item.status}\n\n${parecer||'Parecer elaborado e disponível para revisão.'}\n\n_${r.socialName||r.managerName}_`,
      urgente:`${base}🚨 *CASO URGENTE*\n\nPaciente: *${item.name}*\nTelefone: ${item.phone}\nProcedimento: ${item.procedure||'—'}\n\n${parecer||'Solicita-se atenção prioritária.'}\n\n📞 ${r.unitPhone||' 99126-4880'}`,
      relatorio:`${base}📊 *RELATÓRIO COMPLETO*\n\n*${item.name}* | CPF: ${item.cpf||'—'}\nNasc.: ${Utils.fDate(item.birth)} | ${item.gender}\nEndereço: ${item.address}, ${item.neighborhood}, Itapajé/CE\nRenda: R$ ${item.income} (${item.incomeRange})\nProcedimento: ${item.procedure}\nStatus: ${item.status}\n\n${parecer||''}\n\n_${r.managerName}_`,
    };
    return msgs[type]||msgs.parecer;
  },
  previewGabinete(){
    const val=document.getElementById('wa-gab-patient').value;
    const type=document.getElementById('wa-gab-type').value;
    const parecer=document.getElementById('wa-parecer').value.trim();
    const visitDate=document.getElementById('wa-visit-date').value;
    const prev=document.getElementById('wa-gab-preview');
    if(!val){prev.textContent='Selecione um caso.';return}
    const[ptype,id]=val.split(':');const item=ptype==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    prev.textContent=this._buildGabineteMsg(item,type,parecer,visitDate);
  },
  sendDecision(decision){
    const val=document.getElementById('wa-gab-patient').value;
    const gPhone=document.getElementById('gabinete-phone').value;
    if(!val){UI.toast('Selecione um caso.','error');return}
    const[ptype,id]=val.split(':');const item=ptype==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    const r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR');
    const msg=`*DECISÃO — ${decision.toUpperCase()}*\n\nPaciente: *${item.name}*\nNº: ${item.solicitNum||'—'}\n\n${decision==='Aprovado'?'✅ PROCESSO APROVADO pelo Programa Itapajé Mais Saúde':'❌ PROCESSO NÃO APROVADO'}\n\n_${r.managerName||'Gerente'} — ${today}_`;
    if(gPhone){window.open(`https://wa.me/55${Utils.cleanPhone(gPhone)}?text=${encodeURIComponent(msg)}`,'_blank')}
    if(ptype==='ims'&&item){item.status=decision;DB.upsertIMS(item);DB.addHistory(id,{id:Utils.uid(),status:decision,obs:'Decisão via WhatsApp: '+decision,user:DB.getSession()?.user||'Sistema',at:Date.now()})}
    DB.addWAHist({id:Utils.uid(),to:'gabinete_decisao',name:item.name,phone:gPhone,type:decision,at:Date.now()});
    this.renderHistory();Dashboard.refresh();UI.toast('Decisão registrada: '+decision+'!');
  },
  sendToPatient(){
    const val=document.getElementById('wa-patient-select').value;if(!val){UI.toast('Selecione um paciente.','error');return}
    const[ptype,id]=val.split(':');const item=ptype==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    const type=document.getElementById('wa-msg-type').value;
    const msg=type==='custom'?document.getElementById('wa-custom-msg').value:this._buildPatientMsg(item,type);
    const phone=Utils.cleanPhone(item.phone);if(!phone){UI.toast('Sem telefone cadastrado.','error');return}
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'paciente',name:item.name,phone:item.phone,type,at:Date.now()});
    this.renderHistory();UI.toast('WhatsApp aberto para '+item.name+'!');
  },
  sendToGabinete(){
    const val=document.getElementById('wa-gab-patient').value;const gPhone=document.getElementById('gabinete-phone').value;
    if(!val){UI.toast('Selecione um caso.','error');return}
    if(!gPhone){UI.toast('Informe o número do gabinete.','error');return}
    const[ptype,id]=val.split(':');const item=ptype==='ims'?DB.getIMSCase(id):DB.getPatient(id);if(!item)return;
    const type=document.getElementById('wa-gab-type').value;
    const parecer=document.getElementById('wa-parecer').value.trim();
    const visitDate=document.getElementById('wa-visit-date').value;
    const msg=this._buildGabineteMsg(item,type,parecer,visitDate);
    DB.saveGabPhone(gPhone);
    window.open(`https://wa.me/55${Utils.cleanPhone(gPhone)}?text=${encodeURIComponent(msg)}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'gabinete',name:item.name,phone:gPhone,type,at:Date.now()});
    this.renderHistory();UI.toast('Mensagem enviada ao gabinete!');
  },
  notifyPatientStatus(){
    const item=StatusMod.currentItem();if(!item){UI.toast('Selecione um paciente na aba Status.','error');return}
    const phone=Utils.cleanPhone(item.phone);if(!phone){UI.toast('Sem telefone.','error');return}
    const msg=this._buildPatientMsg(item,'status');
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'paciente',name:item.name,phone:item.phone,type:'status',at:Date.now()});
    this.renderHistory();UI.toast('WhatsApp aberto!');
  },
  notifyFromIMS(id){
    const c=DB.getIMSCase(id);if(!c)return;
    const phone=Utils.cleanPhone(c.phone);if(!phone){UI.toast('Sem telefone.','error');return}
    const status=c.status;
    const type=status==='Aprovado'?'aprovado':status==='Agendado'?'agendamento':status==='Reprovado'?'reprovado':'status';
    const msg=this._buildPatientMsg(c,type);
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'paciente',name:c.name,phone:c.phone,type,at:Date.now()});
  },
  sendReportGabinete(){
    const report=Relatorio._lastReport;const gPhone=DB.getGabPhone();
    if(!report){UI.toast('Gere um relatório primeiro.','error');return}
    if(!gPhone){UI.switchTab('whatsapp',document.querySelector('[data-tab=whatsapp]'));UI.toast('Configure o número do gabinete.','error');return}
    const msg=`*RELATÓRIO SOCIAL — ${new Date().toLocaleDateString('pt-BR')}*\n\n${report.slice(0,1500)}${report.length>1500?'\n\n[...relatório completo no sistema]':''}`;
    window.open(`https://wa.me/55${Utils.cleanPhone(gPhone)}?text=${encodeURIComponent(msg)}`,'_blank');
    UI.toast('Relatório enviado ao gabinete!');
  },
  renderHistory(){
    const h=DB.getWAHist(),el=document.getElementById('wa-history');if(!el)return;
    el.innerHTML=h.length===0?'<p style="color:var(--text-muted);font-size:12px;padding:.5rem 0">Nenhum envio.</p>':h.slice(0,20).map(x=>`<div class="history-item"><div class="history-meta"><span class="badge ${x.to.includes('gabinete')?'badge-aprovado':'badge-analise'}">${x.to}</span><span class="history-date">${Utils.fDT(x.at)}</span></div><div class="history-obs">${Utils.esc(x.name)} · ${Utils.esc(x.type)}</div></div>`).join('');
  },
  clearHistory(){DB.s(DB.K.WA_HIST,[]);this.renderHistory();UI.toast('Histórico limpo.')},
};

/* ═════════════════════════════════════════
   Responsible / Letterhead / Print
═════════════════════════════════════════ */
const Responsible = {
  load(){const d=DB.getResp();['social-name','social-reg','manager-name','manager-role','unit','unit-address','unit-phone','unit-city'].forEach(k=>{const kc=k.replace(/-([a-z])/g,(m,l)=>l.toUpperCase());const el=document.getElementById('r-'+k);if(el)el.value=d[kc]||''})},
  save(){const v=id=>document.getElementById('r-'+id)?.value.trim()||'';DB.saveResp({socialName:v('social-name'),socialReg:v('social-reg'),managerName:v('manager-name'),managerRole:v('manager-role'),unit:v('unit'),unitAddress:v('unit-address'),unitPhone:v('unit-phone'),unitCity:v('unit-city')||'Itapajé — CE'});UI.toast('Responsáveis salvos!')},
};

const Letterhead = {
  init(){const d=DB.getLH();['line1','line2','line3','align','footer1','footer2','footer3','legal','accent-color','img-pos'].forEach(k=>{const el=document.getElementById('lh-'+k);if(el)el.value=d[k.replace(/-([a-z])/g,(m,l)=>l.toUpperCase())]||''});if(d.image){const p=document.getElementById('lh-img-preview');p.innerHTML=`<img src="${d.image}" alt="Logo">`}this.preview()},
  uploadImage(input){const file=input.files[0];if(!file)return;if(file.size>500*1024){UI.toast('Imagem muito grande.','error');return}const r=new FileReader();r.onload=e=>{document.getElementById('lh-img-preview').innerHTML=`<img src="${e.target.result}" alt="Logo">`;this.preview()};r.readAsDataURL(file)},
  removeImage(){document.getElementById('lh-img-preview').innerHTML='<span>Clique para carregar logomarca<br><small>PNG/JPG · máx 500KB</small></span>';document.getElementById('lh-img-input').value='';this.preview()},
  _getData(){const imgEl=document.getElementById('lh-img-preview').querySelector('img');return{line1:document.getElementById('lh-line1').value,line2:document.getElementById('lh-line2').value,line3:document.getElementById('lh-line3').value,align:document.getElementById('lh-align').value,footer1:document.getElementById('lh-footer1').value,footer2:document.getElementById('lh-footer2').value,footer3:document.getElementById('lh-footer3').value,legal:document.getElementById('lh-legal').value,accentColor:document.getElementById('lh-accent-color').value,image:imgEl?imgEl.src:null,imgPos:document.getElementById('lh-img-pos').value}},
  preview(){
    const d=this._getData(),align=d.align||'center';
    const hEl=document.getElementById('lh-preview-header'),fEl=document.getElementById('lh-preview-footer');
    let h='';
    if(d.image){const pm={left:'left',center:'center',right:'right'};h+=`<div style="text-align:${pm[d.imgPos]||'left'};margin-bottom:5px"><img src="${d.image}" style="max-height:44px;object-fit:contain"></div>`}
    if(d.line1)h+=`<div style="text-align:${align};font-weight:bold;font-size:10px;text-transform:uppercase;color:#1b5e20">${Utils.esc(d.line1)}</div>`;
    if(d.line2)h+=`<div style="text-align:${align};font-size:9px;color:#2d7d32">${Utils.esc(d.line2)}</div>`;
    if(d.line3)h+=`<div style="text-align:${align};font-size:8px;color:#5a8a5a">${Utils.esc(d.line3)}</div>`;
    h+=`<div style="height:2px;background:${d.accentColor||'#2d7d32'};margin:5px 0 4px;border-radius:1px"></div>`;
    hEl.innerHTML=h;
    let f=`<div style="border-top:1px solid #ccc;margin-top:10px;padding-top:6px">`;
    if(d.footer1)f+=`<div style="text-align:center;font-size:7px;color:#555">${Utils.esc(d.footer1)}</div>`;
    if(d.footer2)f+=`<div style="text-align:center;font-size:7px;color:#555">${Utils.esc(d.footer2)}</div>`;
    if(d.footer3)f+=`<div style="text-align:center;font-size:7px;color:#888">${Utils.esc(d.footer3)}</div>`;
    if(d.legal)f+=`<div style="text-align:center;font-size:6px;color:#aaa;margin-top:3px;font-style:italic">${Utils.esc(d.legal)}</div>`;
    f+='</div>';fEl.innerHTML=f;
  },
  save(){DB.saveLH(this._getData());UI.toast('Timbrado salvo!')},
  reset(){DB.saveLH(null);this.init();UI.toast('Timbrado restaurado.')},
  buildHeaderHTML(d){
    const align=d.align||'center';let html=`<div class="rp-header">`;
    if(d.image){const pm={left:'left',center:'center',right:'right'};html+=`<div class="rp-header-img-wrap" style="text-align:${pm[d.imgPos]||'left'}"><img class="rp-header-img" src="${d.image}" alt="Logo"></div>`}
    if(d.line1)html+=`<div class="rp-header-text" style="text-align:${align};font-size:13pt;font-weight:bold;text-transform:uppercase">${Utils.esc(d.line1)}</div>`;
    if(d.line2)html+=`<div class="rp-header-text" style="text-align:${align};font-size:11pt">${Utils.esc(d.line2)}</div>`;
    if(d.line3)html+=`<div class="rp-header-text" style="text-align:${align};font-size:10pt;color:#3a6a3a">${Utils.esc(d.line3)}</div>`;
    html+=`</div><div class="rp-accent-line" style="background:${d.accentColor||'#2d7d32'}"></div>`;return html;
  },
  buildFooterHTML(d){
    let f=`<div class="rp-footer-bar">`;
    if(d.footer1)f+=`<div>${Utils.esc(d.footer1)}</div>`;
    if(d.footer2)f+=`<div>${Utils.esc(d.footer2)}</div>`;
    if(d.footer3)f+=`<div>${Utils.esc(d.footer3)}</div>`;
    if(d.legal)f+=`<div style="margin-top:3px;font-style:italic;font-size:8pt;color:#aaa">${Utils.esc(d.legal)}</div>`;
    f+='</div>';return f;
  },
};

const Print = {
  buildIMSPage(c){
    const r=DB.getResp(),lh=DB.getLH(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    const f=(l,v)=>v?`<div class="doc-field"><span class="doc-field-label">${l}:</span><span>${Utils.esc(v)}</span></div>`:'';
    const hist=DB.getHistory(c.id).slice(0,5);
    return`<div class="report-page">${Letterhead.buildHeaderHTML(lh)}<div class="rp-body">
      <div class="doc-title">Processo Administrativo — Programa Itapajé Mais Saúde</div>
      <div class="doc-subtitle">Nº ${c.solicitNum} | ${Utils.esc(c.procedure)} | ${Utils.fDate(c.date)}</div>
      <div class="doc-section">I. Cadastro de Atendimento</div>
      ${f('Nº da Solicitação',c.solicitNum)}${f('Data',Utils.fDate(c.date))}${f('Procedimento',c.procedure)}
      <div class="doc-section">II. Cadastro do Beneficiário</div>
      ${f('Nome',c.name)}${f('Endereço',c.address)}${f('Bairro/Zona',c.neighborhood)}${f('Ponto de Referência',c.reference)}${f('Nascimento',Utils.fDate(c.birth)+' ('+Utils.age(c.birth)+')')}${f('Sexo',c.gender)}${f('Renda Familiar','R$ '+c.income+' — '+c.incomeRange)}${f('Telefone',c.phone)}${f('Escolaridade',c.education)}${f('Profissão',c.profession)}${f('RG/CIN',c.rg+' | '+c.rgOrg)}${f('CPF',c.cpf)}
      <div class="doc-section">III. Situação Habitacional</div>${f('Moradia',c.housing+' · '+c.services)}
      <div class="doc-section">IV. Dados da Mãe</div>${f('Nome',c.mother)}${f('Profissão',c.motherProf)}${f('Escolaridade',c.motherEdu)}
      ${c.regulation?`<div class="doc-section">V. Regulação Municipal</div><div class="doc-body">${Utils.esc(c.regulation)}</div>`:''}
      ${c.obs?`<div class="doc-section">VI. Observações</div><div class="doc-body">${Utils.esc(c.obs)}</div>`:''}
      ${hist.length>0?`<div class="doc-section">VII. Histórico</div>${hist.map(h=>`<div class="doc-field"><span class="doc-field-label">${Utils.fDT(h.at)}</span><span>[${h.status}] ${h.obs}</span></div>`).join('')}`:''}
      <div class="doc-sign-grid">
        <div class="doc-sign-block"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:5px"></div><div class="doc-sign-line"><strong>${Utils.esc(r.socialName||'Assistente Social')}</strong><br><small>${Utils.esc(r.socialReg||'CRESS')}</small></div></div>
        <div class="doc-sign-block"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:5px"></div><div class="doc-sign-line"><strong>${Utils.esc(r.managerName||'Francisco Maílson de Sousa Moreira')}</strong><br><small>${Utils.esc(r.managerRole||'Gerente de Apoio Social')}</small></div></div>
      </div>
      <div style="text-align:right;margin-top:20px;font-size:10pt">Itapajé – CE, ${today}</div>
    </div>${Letterhead.buildFooterHTML(lh)}</div>`;
  },
  buildOficioPage(o){
    const r=DB.getResp(),lh=DB.getLH(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    const imsRef=o.imsRef?DB.getIMSCase(o.imsRef):null;
    return`<div class="report-page">${Letterhead.buildHeaderHTML(lh)}<div class="rp-body">
      <div style="text-align:right;font-size:10pt;margin-bottom:10px">Itapajé – CE, ${o.date?Utils.fDate(o.date):today}</div>
      ${o.num?`<div style="text-align:center;font-size:11pt;font-weight:bold;margin-bottom:8px">${Utils.esc(o.type.toUpperCase())} Nº ${Utils.esc(o.num)}</div>`:''}
      ${o.subject?`<div class="doc-title">${Utils.esc(o.subject)}</div>`:''}
      ${o.dest?`<div style="font-size:10.5pt;margin-bottom:12px"><strong>À:</strong> ${Utils.esc(o.dest)}</div>`:''}
      <div class="doc-section">SITUAÇÃO DO PACIENTE</div>
      ${imsRef?`<div style="font-size:10.5pt;font-weight:bold;margin-bottom:8px">NOME DO PACIENTE: ${Utils.esc(imsRef.name)}<br>Nº DA SOLICITAÇÃO: ${Utils.esc(imsRef.solicitNum)}<br>DATA: ${Utils.fDate(imsRef.date)}<br>PROCEDIMENTO: ${Utils.esc(imsRef.procedure)}</div>`:''}
      <div class="doc-body">${Utils.esc(o.body)}</div>
      ${o.local||o.procDate?`<div style="margin-top:14px;font-size:10.5pt">${o.procDate?'<strong>Data:</strong> '+Utils.fDate(o.procDate)+'<br>':''}${o.procTime?'<strong>Horário:</strong> '+o.procTime+'<br>':''}${o.local?'<strong>Local:</strong> '+Utils.esc(o.local):''}${imsRef?.hospitalAddress?'<br>'+Utils.esc(imsRef.hospitalAddress):''}</div>`:''}
      <div style="text-align:center;margin-top:40px">
        <div style="display:inline-block;text-align:center"><div style="height:40px;border-bottom:1px solid #000;min-width:220px;margin-bottom:5px"></div><div style="font-size:10.5pt"><strong>${Utils.esc(r.managerName||'Francisco Maílson de Sousa Moreira')}</strong></div><div style="font-size:9.5pt">${Utils.esc(r.managerRole||'Gerente de Apoio Social')}</div><div style="font-size:9.5pt">${Utils.esc(r.unit||'Secretaria Municipal de Saúde')}</div></div>
      </div>
    </div>${Letterhead.buildFooterHTML(lh)}</div>`;
  },
  buildRelatorioPage(text){
    const lh=DB.getLH(),r=DB.getResp(),today=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
    return`<div class="report-page">${Letterhead.buildHeaderHTML(lh)}<div class="rp-body">
      <div class="doc-title">Relatório Social</div>
      <div class="doc-body">${Utils.esc(text).replace(/\n/g,'<br>')}</div>
      <div class="doc-sign-grid">
        <div class="doc-sign-block"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:5px"></div><div class="doc-sign-line"><strong>${Utils.esc(r.socialName||'Assistente Social')}</strong><br><small>${Utils.esc(r.socialReg||'CRESS')}</small></div></div>
        <div class="doc-sign-block"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:5px"></div><div class="doc-sign-line"><strong>${Utils.esc(r.managerName||'Francisco Maílson de Sousa Moreira')}</strong><br><small>${Utils.esc(r.managerRole||'Gerente de Apoio Social')}</small></div></div>
      </div>
      <div style="text-align:right;margin-top:16px;font-size:9.5pt">Itapajé – CE, ${today}</div>
    </div>${Letterhead.buildFooterHTML(lh)}</div>`;
  },
  printIMS(id){const c=DB.getIMSCase(id);if(!c)return;const html=this.buildIMSPage(c);const win=window.open('','_blank');win.document.write(this._printWin(html));win.document.close();win.focus();setTimeout(()=>win.print(),600)},
  _printWin(html){return`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><title>SAS — Itapajé Mais Saúde</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Times New Roman',serif;background:#fff}.report-page{width:210mm;min-height:297mm;padding:0;page-break-after:always;margin:0 auto;display:grid;grid-template-rows:auto 1fr auto}.report-page:last-child{page-break-after:avoid}.rp-header{padding:8mm 15mm 5mm}.rp-header-img{max-height:60px;object-fit:contain}.rp-header-img-wrap{margin-bottom:5px}.rp-accent-line{height:3px;margin:0 15mm}.rp-body{padding:7mm 15mm}.rp-footer-bar{padding:5mm 15mm 8mm;border-top:1px solid #bbb;font-size:8.5pt;color:#555;text-align:center;line-height:1.5}.doc-title{text-align:center;font-size:12pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin:6px 0 10px}.doc-subtitle{text-align:center;font-size:10pt;margin-bottom:10px}.doc-section{font-weight:bold;font-size:10pt;background:#e8f5e9;padding:3px 8px;margin:8px 0 4px;text-transform:uppercase;border-left:3px solid #2d7d32}.doc-field{display:grid;grid-template-columns:160px 1fr;gap:4px;padding:2px 0;border-bottom:.5px solid #e0e0e0;font-size:10.5pt}.doc-field-label{font-weight:bold}.doc-body{font-size:10.5pt;line-height:1.8;text-align:justify;white-space:pre-wrap;margin:8px 0}.doc-sign-grid{display:grid;grid-template-columns:1fr 1fr;gap:32px;margin-top:28px}.doc-sign-block{text-align:center;font-size:10pt}.doc-sign-line{padding-top:4px}@media print{@page{size:A4;margin:0}}</style></head><body>${html}</body></html>`},
};

/* ═════════════════════════════════════════
   QR Module
═════════════════════════════════════════ */
const QRModule = {
  generate(){
    const container=document.getElementById('qr-container'),urlDisplay=document.getElementById('qr-url-display');
    const customUrl=document.getElementById('custom-qr-url')?.value.trim();
    const url=customUrl||window.location.href.split('?')[0].split('#')[0];
    urlDisplay.textContent=url;container.innerHTML='';
    try{new QRCode(container,{text:url,width:200,height:200,colorDark:'#1b2e1b',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.M})}
    catch{container.innerHTML=`<div style="padding:1rem;color:var(--text-muted);font-size:12px;text-align:center;word-break:break-all">QR gerado para:<br><strong>${url}</strong></div>`}
  },
  printQR(){
    const container=document.getElementById('qr-container');const url=document.getElementById('qr-url-display').textContent;
    const win=window.open('','_blank');
    win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>QR — SAS Itapajé</title><style>body{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;font-family:sans-serif;text-align:center;gap:16px}h2{font-size:18px}p{font-size:13px;color:#555;max-width:300px}code{font-size:12px;background:#f1f5f9;padding:6px 12px;border-radius:6px;display:inline-block;word-break:break-all}button{margin-top:12px;padding:8px 20px;background:#2d7d32;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px}@media print{button{display:none}}</style></head><body><h2>SAS — Sistema de Apoio Social</h2><h3 style="font-size:14px;color:#4a5a4a">Secretaria Municipal de Saúde · Itapajé Mais Saúde</h3>${container.innerHTML}<p>Aponte a câmera para o QR Code ou acesse:</p><code>${url}</code><br><button onclick="window.print()">Imprimir</button></body></html>`);
    win.document.close();
  },
};

/* ═════════════════════════════════════════
   Admin
═════════════════════════════════════════ */
const Admin = {
  render(){
    this._pending();this._active();App._updBadge();
  },
  _pending(){
    const p=DB.getPending(),el=document.getElementById('pending-users-list');
    document.getElementById('pending-count').textContent=p.length;
    el.innerHTML=p.length===0?'<p style="color:var(--text-muted);font-size:12px;padding:.5rem 0">Nenhuma solicitação.</p>':p.map(u=>`<div class="user-item"><div><div class="user-item-name">${Utils.esc(u.fullname||u.username)}</div><div class="user-item-sub">@${Utils.esc(u.username)} · ${Utils.fDT(u.requestedAt)}</div></div><div class="user-item-actions"><button class="btn-approve" onclick="Admin.approve('${u.id}')">✓ Aprovar</button><button class="btn-reject-u" onclick="Admin.reject('${u.id}')">✕ Recusar</button></div></div>`).join('');
  },
  _active(){
    const u=DB.getUsers(),el=document.getElementById('active-users-list');
    el.innerHTML=u.map(x=>`<div class="user-item"><div><div class="user-item-name">${Utils.esc(x.fullname||x.username)} ${x.role==='admin'?'<span class="user-admin-badge">Admin</span>':''}</div><div class="user-item-sub">@${Utils.esc(x.username)}</div></div>${x.username!==ADMIN?`<div class="user-item-actions"><button class="btn-reject-u" onclick="Admin.remove('${x.id}')">Remover</button></div>`:''}</div>`).join('');
  },
  approve(id){const p=DB.getPending(),idx=p.findIndex(x=>x.id===id);if(idx<0)return;const u=p[idx];const users=DB.getUsers();users.push({id:u.id,username:u.username,password:u.password,fullname:u.fullname,role:'user',active:true});DB.saveUsers(users);p.splice(idx,1);DB.savePending(p);this.render();UI.toast('Usuário aprovado: @'+u.username)},
  reject(id){DB.savePending(DB.getPending().filter(x=>x.id!==id));this.render();UI.toast('Solicitação recusada.')},
  remove(id){DB.saveUsers(DB.getUsers().filter(x=>x.id!==id));this.render();UI.toast('Usuário removido.')},
};

/* ═════════════════════════════════════════
   INIT
═════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded',()=>{
  App.init();
  document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.add('hidden')}));
  document.getElementById('login-pass')?.addEventListener('keydown',e=>{if(e.key==='Enter')App.login()});
  document.getElementById('login-user')?.addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('login-pass').focus()});
  // WhatsApp preview on gab type change
  document.getElementById('wa-gab-type')?.addEventListener('change',()=>WhatsApp.previewGabinete());
  document.getElementById('wa-gab-patient')?.addEventListener('change',()=>WhatsApp.previewGabinete());
});
/* ═══════════════════════════════════════════════════════════════
   SAS v4.0 — MÓDULOS ADICIONAIS
   IA Ofícios · Impressão Completa · Lote · Protocolos · Mobile
   ═══════════════════════════════════════════════════════════════ */

/* ══ CONSTANTES GLOBAIS ══ */
const PHONE_OFICIAL = '(85) 99126-4880';
const MUNICIPIO = 'Itapajé';
const UF = 'CE';
const CEP_SECRETARIA = '62.600-000';
const ENDERECO_SECRETARIA = 'R. São Francisco, Nº 225, Centro';

/* ════════════════════════════════════════════════════════════
   IA OFÍCIOS — Geração automática de textos jurídicos/técnicos
════════════════════════════════════════════════════════════ */
const IAOficios = {

  /* Detecta tipo pelo contexto e gera corpo completo */
  gerarCorpo(tipo, imsCase, dadosExtra) {
    const r = DB.getResp();
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const c = imsCase;
    const manager = r.managerName || 'Francisco Maílson de Sousa Moreira';
    const unit = r.unit || 'Secretaria Municipal de Saúde';
    const name = c ? c.name.toUpperCase() : (dadosExtra?.dest || '').toUpperCase();
    const cpf = c ? (c.cpf || '—') : '—';
    const proc = c ? c.procedure : '';
    const num = c ? c.solicitNum : '';

    const corpos = {

      oficio: `Senhor(a) ${dadosExtra?.dest || '_______________'},\n\nCumprimentando-o(a) cordialmente, encaminhamos o presente ofício para solicitar providências referentes ao processo de atendimento do(a) paciente ${name}, CPF nº ${cpf}, residente no Município de ${MUNICIPIO}/${UF}, beneficiário(a) do Programa Itapajé Mais Saúde, instituído pela Lei Municipal nº 2.399, de 15 de abril de 2025.\n\n${dadosExtra?.obs || 'Solicitamos a análise e as providências cabíveis no menor prazo possível, tendo em vista a situação de saúde do(a) paciente acima identificado(a).'}\n\nCertos de contarmos com a colaboração de Vossa Senhoria, agradecemos antecipadamente.\n\nAtenciosamente,\n\n${manager}\n${r.managerRole || 'Gerente de Apoio Social'}\n${unit} — ${MUNICIPIO}/${UF}\nTel.: ${PHONE_OFICIAL}`,

      autorizacao: `Em atendimento à Lei Municipal nº 2.399, de 15 de abril de 2025, que fundamenta o Programa "Itapajé Mais Saúde", e ao Art. 2º do Capítulo 1 do Decreto nº 49, de 30 de maio de 2025, que dispõe:\n\n"Art. 2º. O Programa 'Itapajé Mais Saúde' destina-se à promoção do acesso gratuito às cirurgias eletivas e emergenciais, bem como a exames de média e alta complexidade, para pacientes de baixa renda residentes no Município de Itapajé, conforme os critérios de elegibilidade e seleção estabelecidos na Lei Municipal nº 2.399/2025 e na Resolução nº 01/2025 do Conselho Municipal de Saúde."\n\nO(A) paciente ${name}, portador(a) do CPF nº ${cpf}, encontra-se devidamente cadastrado(a) nesta Secretaria Municipal de Saúde sob o Nº de Solicitação ${num}, havendo sido avaliado(a) pelo Serviço de Apoio Social e preenchido os critérios de elegibilidade do referido Programa.\n\nFICA AUTORIZADA a realização do procedimento: ${proc.toUpperCase()}, pelo Programa Itapajé Mais Saúde, para o(a) paciente ${name}.`,

      regulacao: `O(A) paciente ${name}, portador(a) do CPF nº ${cpf}, encontra-se em fila de espera no Sistema de Regulação do Estado do Ceará — SISREG, sem previsão de agendamento pelo SUS, conforme verificação realizada em ${today}.\n\nDiante da demanda reprimida identificada e da indicação clínica apresentada pelo médico assistente, o Setor de Regulação Municipal de ${MUNICIPIO}/${UF} encaminha o presente relatório recomendando o atendimento do(a) referido(a) paciente pelo Programa Itapajé Mais Saúde, em conformidade com os critérios estabelecidos na Lei Municipal nº 2.399/2025.\n\nO procedimento indicado é: ${proc.toUpperCase()}${c && c.hospital ? ', a ser realizado no ' + c.hospital : ''}.`,

      parecer_social: `O presente parecer social tem por objetivo subsidiar tecnicamente a análise do processo de solicitação de procedimento cirúrgico/exame pelo Programa Itapajé Mais Saúde, referente ao(à) paciente ${name}, CPF nº ${cpf}.\n\nApós visita domiciliar e entrevista social realizada em ${dadosExtra?.visitDate || today}, foi possível identificar que o(a) paciente reside no Município de ${MUNICIPIO}/${UF}${c && c.address ? ', mais especificamente em ' + c.address + ', ' + c.neighborhood : ''}, apresentando situação de vulnerabilidade socioeconômica caracterizada por renda familiar de ${c && c.income ? 'R$ ' + c.income + ' (' + c.incomeRange + ')' : 'baixa renda'}${c && c.housing ? ', com situação habitacional: ' + c.housing + ', ' + c.services : ''}.\n\n${dadosExtra?.situacao || 'A avaliação social constatou que o(a) paciente preenche os requisitos de elegibilidade previstos na Lei Municipal nº 2.399/2025, sendo portanto recomendada a inclusão no Programa Itapajé Mais Saúde para realização do procedimento indicado.'}\n\nCom base na avaliação realizada, o Serviço Social desta Secretaria é FAVORÁVEL à inclusão do(a) referido(a) paciente no Programa Itapajé Mais Saúde, para realização de ${proc || 'procedimento indicado pelo médico assistente'}.`,

      encaminhamento: `Encaminhamos para conhecimento e providências o(a) paciente ${name}, portador(a) do CPF nº ${cpf}, residente neste Município de ${MUNICIPIO}/${UF}.\n\n${dadosExtra?.obs || 'O(A) referido(a) paciente necessita de atendimento especializado, não disponível na rede básica de saúde municipal, estando devidamente cadastrado(a) nesta Secretaria Municipal de Saúde.'}\n\nSolicitamos que seja prestado o atendimento necessário e que, ao término, seja comunicado a esta Secretaria o resultado do atendimento, para fins de registro e acompanhamento pelo Serviço de Apoio Social.\n\n${dadosExtra?.urgente ? 'CASO DE CARÁTER URGENTE — Solicitamos prioridade no atendimento.' : 'Contamos com a atenção de Vossa Senhoria.'}`,

      declaracao: `Declaramos para os devidos fins que o(a) Sr.(a.) ${name}, portador(a) do CPF nº ${cpf}, é beneficiário(a) do Programa Itapajé Mais Saúde${num ? ', sob o Nº de Protocolo ' + num : ''}, instituído pela Lei Municipal nº 2.399/2025 da Prefeitura Municipal de ${MUNICIPIO}/${UF}.\n\n${dadosExtra?.obs || 'O(A) referido(a) paciente encontra-se em acompanhamento pelo Serviço de Apoio Social desta Secretaria Municipal de Saúde, tendo preenchido todos os critérios de elegibilidade estabelecidos pelo referido Programa.'}\n\nA presente declaração é expedida para os fins que se fizerem necessários.`,
    };

    return corpos[tipo] || corpos.oficio;
  },

  /* Gera sugestões de parágrafos contextuais */
  getSuggestions(tipo, imsCase) {
    const c = imsCase;
    const sugs = {
      oficio: [
        'Reiteramos a urgência no atendimento, considerando o agravamento do quadro clínico.',
        'Solicitamos retorno no prazo de 5 (cinco) dias úteis para fins de acompanhamento.',
        'O(A) paciente encontra-se em situação de vulnerabilidade social que demanda atenção prioritária.',
      ],
      autorizacao: [
        'A autorização é válida por 30 (trinta) dias a partir da data de emissão.',
        'O hospital credenciado deverá comunicar a realização do procedimento a esta Secretaria.',
        'Em caso de intercorrências, contatar esta Secretaria pelo ' + PHONE_OFICIAL + '.',
      ],
      parecer_social: [
        c && c.mother ? 'Mãe: ' + c.mother + (c.motherProf ? ', ' + c.motherProf : '') + ', confirmando contexto familiar de trabalhadores rurais.' : '',
        'A ausência de renda regular compromete o acesso a procedimentos eletivos na rede privada.',
        'Recomenda-se acompanhamento pós-procedimento pelo Serviço Social para verificação das condições de recuperação.',
      ].filter(Boolean),
      regulacao: [
        'Verificado que o(a) paciente aguarda há mais de 90 dias na fila do SISREG sem previsão.',
        'O médico assistente atestou a necessidade do procedimento com caráter de urgência relativa.',
        'A não realização do procedimento poderá resultar em agravamento irreversível do quadro clínico.',
      ],
    };
    return sugs[tipo] || sugs.oficio;
  },
};

/* ════════════════════════════════════════════════════════════
   PRINT MOD — Impressão Completa, Lote, Protocolos
════════════════════════════════════════════════════════════ */
const PrintMod = {
  _ptab: 'individual',

  switchTab(tab, btn) {
    this._ptab = tab;
    document.querySelectorAll('.print-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.print-panel').forEach(p => p.classList.add('hidden'));
    if (btn) btn.classList.add('active');
    const panel = document.getElementById('print-' + tab);
    if (panel) panel.classList.remove('hidden');
    if (tab === 'individual') this._populatePrintSelect();
    if (tab === 'lote') this._updateLoteCount();
    if (tab === 'protocolo') this._previewProtocolCount();
  },

  init() {
    this._populatePrintSelect();
    document.getElementById('print-ims-select')?.addEventListener('change', e => {
      this._showProcessSummary(e.target.value);
    });
  },

  _populatePrintSelect() {
    const sel = document.getElementById('print-ims-select');
    if (!sel) return;
    const ims = DB.getIMS().sort((a, b) => a.name.localeCompare(b.name));
    sel.innerHTML = '<option value="">— Selecionar Caso IMS —</option>' +
      ims.map(x => `<option value="${x.id}">[${Utils.esc(x.solicitNum)}] ${Utils.esc(x.name)}</option>`).join('');
  },

  _showProcessSummary(id) {
    const el = document.getElementById('print-process-summary');
    if (!id) { el.classList.add('hidden'); return; }
    const c = DB.getIMSCase(id);
    if (!c) return;
    const hist = DB.getHistory(id);
    el.classList.remove('hidden');
    const steps = [
      { label: '📄 Cadastro de Atendimento', done: true },
      { label: '📋 Parecer Social', done: !!DB.getReports().find(r => r.imsId === id) },
      { label: '🏥 Relatório de Regulação', done: !!c.regulation },
      { label: '✅ Guia de Autorização', done: c.status === 'Aprovado' || c.status === 'Agendado' || c.status === 'Realizado' },
      { label: '📅 Comprovante de Agendamento', done: !!c.scheduledDate },
    ];
    el.innerHTML = `
      <div style="margin:.75rem 0;padding:.875rem;background:var(--green-pale);border-radius:var(--radius);border:1px solid var(--green-border)">
        <div style="font-size:12px;font-weight:600;color:var(--green-dark);margin-bottom:.5rem">Etapas do Processo — ${Utils.esc(c.name)}</div>
        ${steps.map(s => `<div style="display:flex;align-items:center;gap:8px;font-size:13px;padding:3px 0;color:${s.done ? 'var(--green-dark)' : 'var(--text-muted)'}">
          <span style="font-size:15px">${s.done ? '✓' : '○'}</span>${s.label}
        </div>`).join('')}
        <div style="margin-top:.75rem;font-size:12px;color:var(--text-muted)">Histórico: ${hist.length} atualização(ões) registrada(s)</div>
      </div>`;
  },

  /* ── CONSTRUTOR DE PÁGINAS A4 ── */
  _buildHeader(lh) {
    const align = lh.align || 'center';
    const posMap = { left: 'left', center: 'center', right: 'right' };
    let h = `<div class="doc-header-wrap">`;
    if (lh.image) h += `<div class="doc-header-img-area" style="text-align:${posMap[lh.imgPos] || 'left'}"><img class="doc-header-img" src="${lh.image}" alt="Logo"></div>`;
    if (lh.line1) h += `<div class="doc-header-lines" style="text-align:${align};font-size:13pt;font-weight:bold;text-transform:uppercase">${Utils.esc(lh.line1)}</div>`;
    if (lh.line2) h += `<div class="doc-header-lines" style="text-align:${align};font-size:11pt">${Utils.esc(lh.line2)}</div>`;
    if (lh.line3) h += `<div class="doc-header-lines" style="text-align:${align};font-size:10pt;color:#3a6a3a">${Utils.esc(lh.line3)}</div>`;
    h += `</div><div class="doc-divider" style="background:${lh.accentColor || '#2d7d32'}"></div>`;
    return h;
  },

  _buildFooter(lh, r) {
    let f = `<div class="doc-footer-area">`;
    f += `<div>${Utils.esc(lh.footer1 || (ENDERECO_SECRETARIA + ', CEP: ' + CEP_SECRETARIA + ' — ' + MUNICIPIO + '/' + UF))}</div>`;
    if (lh.footer2 || r.unitPhone) f += `<div>${Utils.esc(lh.footer2 || (r.unitPhone + ' · saude@itapaje.ce.gov.br · www.itapaje.ce.gov.br'))}</div>`;
    if (lh.footer3) f += `<div>${Utils.esc(lh.footer3)}</div>`;
    if (lh.legal) f += `<div style="margin-top:2px;font-style:italic;font-size:7.5pt;color:#888">${Utils.esc(lh.legal)}</div>`;
    f += '</div>';
    return f;
  },

  _field(label, value) {
    if (!value) return '';
    return `<tr><td class="lbl">${label}</td><td class="val">${Utils.esc(value)}</td></tr>`;
  },

  _localDate(city) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    return `<div class="doc-local-date">${city || MUNICIPIO} – ${UF}, ${today}</div>`;
  },

  _signs2(r, lh) {
    const manager = r.managerName || 'Francisco Maílson de Sousa Moreira';
    const social = r.socialName || '___________________________';
    return `<div class="doc-sign-row" style="grid-template-columns:1fr 1fr">
      <div class="doc-sign-block">
        <div style="height:40px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div class="doc-sign-line-top">${Utils.esc(social)}</div>
        <div class="doc-sign-sub">${Utils.esc(r.socialReg || 'Assistente Social')}</div>
      </div>
      <div class="doc-sign-block">
        <div style="height:40px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div class="doc-sign-line-top">${Utils.esc(manager)}</div>
        <div class="doc-sign-sub">${Utils.esc(r.managerRole || 'Gerente de Apoio Social')}<br>${Utils.esc(r.unit || 'Secretaria Municipal de Saúde')}<br>Tel.: ${PHONE_OFICIAL}</div>
      </div>
    </div>`;
  },

  _signs1center(r) {
    const manager = r.managerName || 'Francisco Maílson de Sousa Moreira';
    return `<div style="text-align:center;margin-top:14mm">
      <div style="display:inline-block;text-align:center;min-width:220px">
        <div style="height:40px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div style="font-size:11pt;font-weight:bold">${Utils.esc(manager)}</div>
        <div style="font-size:9.5pt;color:#333">${Utils.esc(r.managerRole || 'Gerente de Apoio Social')}</div>
        <div style="font-size:9.5pt;color:#333">${Utils.esc(r.unit || 'Secretaria Municipal de Saúde')}</div>
        <div style="font-size:9.5pt">Tel.: ${PHONE_OFICIAL}</div>
      </div>
    </div>`;
  },

  /* ── CAPA DO PROCESSO ── */
  _buildCapa(c, lh, r) {
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content" style="text-align:center">
        <div class="doc-capa-title">Processo Administrativo de Solicitação de<br>Procedimento pelo Projeto<br>Itapajé Mais Saúde</div>
        <div class="doc-capa-num">Nº ${Utils.esc(c.solicitNum)} — ${Utils.esc(c.procedure?.split('—')[0] || c.procedure || 'Cirurgia')}</div>
        <div class="doc-capa-paciente">
          <div class="doc-capa-label">PACIENTE</div>
          <div class="doc-capa-name">${Utils.esc(c.name)}</div>
        </div>
        <div class="doc-capa-proc"><strong>PROCEDIMENTO:</strong> ${Utils.esc(c.procedure?.toUpperCase() || '')}</div>
        <div class="doc-capa-date">${new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }).toUpperCase()}</div>
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── CADASTRO DE ATENDIMENTO (Ficha) ── */
  _buildFicha(c, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Cadastro de Atendimento</div>
        <div class="doc-ref-box">
          <strong>Nº da Solicitação:</strong> ${Utils.esc(c.solicitNum)} &nbsp;|&nbsp;
          <strong>Data:</strong> ${Utils.fDate(c.date)} &nbsp;|&nbsp;
          <strong>Procedimento:</strong> ${Utils.esc(c.procedure?.toUpperCase())}
        </div>

        <div class="doc-section-header">Cadastro do Beneficiário</div>
        <table class="doc-table">
          ${this._field('Nome', c.name)}
          ${this._field('Endereço', c.address)}
          ${this._field('Bairro / Zona', c.neighborhood)}
          ${this._field('Ponto de Referência', c.reference)}
          ${this._field('Data de Nascimento', Utils.fDate(c.birth) + (c.birth ? ' (' + Utils.age(c.birth) + ')' : ''))}
          ${this._field('Sexo', c.gender)}
          ${this._field('Renda Familiar', 'R$ ' + c.income + ' — ' + c.incomeRange)}
          ${this._field('Telefone', c.phone)}
          ${this._field('Escolaridade', c.education)}
          ${this._field('Profissão', c.profession)}
          ${this._field('RG / CIN', c.rg + (c.rgOrg ? ' · ' + c.rgOrg : ''))}
          ${this._field('CPF', c.cpf)}
          ${this._field('Município', MUNICIPIO + ' — ' + UF)}
        </table>

        <div class="doc-section-header">Situação Habitacional</div>
        <table class="doc-table"><tr><td colspan="2" style="padding:6px 7px">${Utils.esc(c.housing || '—')}${c.services ? ' · ' + Utils.esc(c.services) : ''}</td></tr></table>

        <div class="doc-section-header">Dados da Mãe</div>
        <table class="doc-table">
          ${this._field('Nome da Mãe', c.mother)}
          ${this._field('Profissão', c.motherProf)}
          ${this._field('Escolaridade', c.motherEdu)}
        </table>

        <div style="margin:10px 0;font-size:10.5pt;text-align:justify">
          Encaminho ficha de atendimento para o Serviço Social para parecer social em ${Utils.fDate(c.date) || today}.
        </div>

        ${this._localDate()}
        ${this._signs1center(r)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── RELATÓRIO SOCIAL / PARECER ── */
  _buildParecer(c, lh, r, reportText) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const text = reportText || IAOficios.gerarCorpo('parecer_social', c, {});
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Relatório Social — Parecer Técnico</div>
        <div class="doc-ref-box"><strong>Paciente:</strong> ${Utils.esc(c.name)} &nbsp;|&nbsp; <strong>Nº:</strong> ${Utils.esc(c.solicitNum)} &nbsp;|&nbsp; <strong>Proc.:</strong> ${Utils.esc(c.procedure)}</div>
        ${this._localDate()}
        <div class="doc-body-text">${Utils.esc(text).replace(/\n/g, '</div><div class="doc-body-text">')}</div>
        <br>
        ${this._signs2(r, lh)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── RELATÓRIO DE REGULAÇÃO ── */
  _buildRegulacao(c, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const text = c.regulation || IAOficios.gerarCorpo('regulacao', c, {});
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Relatório do Setor de Regulação Municipal</div>
        ${this._localDate()}
        <div class="doc-body-text">${Utils.esc(text).replace(/\n/g, '</div><div class="doc-body-text">')}</div>
        <br>
        ${this._localDate()}
        ${this._signs1center(r)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── GUIA DE AUTORIZAÇÃO ── */
  _buildAutorizacao(c, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const bodyText = IAOficios.gerarCorpo('autorizacao', c, {});
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Guia de Autorização</div>
        <div class="doc-section-header">Situação do Paciente</div>
        <table class="doc-table">
          ${this._field('Nome do Paciente', c.name)}
          ${this._field('Nº da Solicitação', c.solicitNum)}
          ${this._field('Data', Utils.fDate(c.date))}
          ${this._field('Procedimento', c.procedure?.toUpperCase())}
          ${this._field('CPF', c.cpf)}
        </table>
        ${this._localDate()}
        <div class="doc-body-text-noindent">${Utils.esc(bodyText).replace(/\n/g, '</div><div class="doc-body-text-noindent">')}</div>
        <div class="doc-auth-box">FICA AUTORIZADO</div>
        <div class="doc-body-text-noindent">a realização do procedimento <strong>${Utils.esc(c.procedure?.toUpperCase())}</strong> pelo Programa Itapajé Mais Saúde para o(a) paciente <strong>${Utils.esc(c.name.toUpperCase())}</strong>.</div>
        <br>
        ${this._localDate()}
        ${this._signs1center(r)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── COMPROVANTE DE AGENDAMENTO ── */
  _buildAgendamento(c, lh, r) {
    if (!c.scheduledDate) return '';
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Comprovante de Agendamento</div>
        <div class="doc-ref-box">
          <strong>Nº da Solicitação:</strong> ${Utils.esc(c.solicitNum)} &nbsp;|&nbsp;
          <strong>Status:</strong> ${Utils.esc(c.status)}
        </div>

        <div class="doc-section-header">Dados do Paciente</div>
        <table class="doc-table">
          ${this._field('Nome', c.name)}
          ${this._field('CPF', c.cpf)}
          ${this._field('Telefone', c.phone)}
          ${this._field('Procedimento', c.procedure?.toUpperCase())}
        </table>

        <div class="doc-section-header">Dados do Agendamento</div>
        <table class="doc-table">
          ${this._field('Data', Utils.fDate(c.scheduledDate))}
          ${this._field('Horário', c.scheduledTime || '—')}
          ${this._field('Hospital / Local', c.hospital || '—')}
          ${this._field('Endereço', c.hospitalAddress || '—')}
        </table>

        <div style="margin:10px 0;font-size:10.5pt;text-align:justify;padding:8px 12px;background:#e8f5e9;border-radius:4px;border-left:4px solid #2d7d32">
          <strong>Instruções:</strong> O(A) paciente deverá comparecer ao local indicado munido(a) de documento de identidade original, CPF e este comprovante de agendamento. Em caso de dúvidas ou necessidade de reagendamento, entrar em contato com a Secretaria Municipal de Saúde pelo telefone ${PHONE_OFICIAL}.
        </div>

        ${this._localDate()}
        ${this._signs1center(r)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  /* ── PROCESSO COMPLETO (todas as páginas) ── */
  buildCompleteProcess(id) {
    const c = DB.getIMSCase(id);
    if (!c) return '';
    const lh = DB.getLH();
    const r = DB.getResp();
    const reports = DB.getReports().filter(x => x.imsId === id);
    const reportText = reports.length > 0 ? reports[0].text : null;

    let pages = '';
    pages += this._buildCapa(c, lh, r);
    pages += this._buildFicha(c, lh, r);
    pages += this._buildParecer(c, lh, r, reportText);
    pages += this._buildRegulacao(c, lh, r);
    pages += this._buildAutorizacao(c, lh, r);
    if (c.scheduledDate) pages += this._buildAgendamento(c, lh, r);
    return pages;
  },

  previewComplete() {
    const id = document.getElementById('print-ims-select').value;
    if (!id) { UI.toast('Selecione um caso IMS.', 'error'); return; }
    const html = this.buildCompleteProcess(id);
    document.getElementById('print-preview-content').innerHTML = html;
    UI.showModal('modal-print-preview');
  },

  printComplete() {
    const id = document.getElementById('print-ims-select').value;
    if (!id) { UI.toast('Selecione um caso IMS.', 'error'); return; }
    this._printWin(this.buildCompleteProcess(id), 'Processo Completo — ' + (DB.getIMSCase(id)?.name || ''));
  },

  /* ── LOTE / PRESTAÇÃO DE CONTAS ── */
  toggleLoteDates(v) {
    const el = document.getElementById('lote-dates');
    if (el) el.style.display = v === 'custom' ? 'grid' : 'none';
    this._updateLoteCount();
  },

  _getLoteData() {
    const period = document.getElementById('lote-period')?.value || 'month';
    const status = document.getElementById('lote-status')?.value || 'all';
    const start = document.getElementById('lote-start')?.value;
    const end = document.getElementById('lote-end')?.value;
    let data = Utils.filterByPeriod(DB.getIMS(), period, start, end);
    if (status !== 'all') data = data.filter(x => x.status === status);
    return data.sort((a, b) => (a.solicitNum || '').localeCompare(b.solicitNum || ''));
  },

  _updateLoteCount() {
    const data = this._getLoteData();
    const el = document.getElementById('lote-preview-count');
    if (el) {
      el.classList.remove('hidden');
      el.style.cssText = 'padding:.75rem 1rem;background:var(--green-light);border-radius:var(--radius);border:1px solid var(--green-border);font-size:13px;color:var(--green-dark);margin:.75rem 0';
      el.innerHTML = `<strong>${data.length}</strong> caso(s) encontrado(s) para impressão.`;
    }
  },

  _buildLoteConsolidado(data, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const counts = {};
    data.forEach(x => { counts[x.status] = (counts[x.status] || 0) + 1; });
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Relatório Consolidado — Programa Itapajé Mais Saúde</div>
        <div class="doc-ref-box">Prestação de Contas · Gerado em: ${today} · Total de Casos: ${data.length}</div>

        <div class="doc-section-header">Resumo por Status</div>
        <table class="batch-summary-table">
          <tr><th>Status</th><th>Quantidade</th><th>%</th></tr>
          ${Object.entries(counts).map(([k, v]) => `<tr><td>${Utils.esc(k)}</td><td>${v}</td><td>${Math.round(v / data.length * 100)}%</td></tr>`).join('')}
          <tr style="font-weight:bold;background:#e8f5e9"><td>TOTAL</td><td>${data.length}</td><td>100%</td></tr>
        </table>

        <div class="doc-section-header" style="margin-top:12px">Lista de Casos — Protocolos</div>
        <table class="batch-summary-table">
          <tr><th style="width:32%">Nº Protocolo</th><th style="width:38%">Paciente</th><th style="width:18%">Procedimento</th><th style="width:12%">Status</th></tr>
          ${data.map((x, i) => `<tr>
            <td style="font-family:monospace;font-size:9.5pt">${Utils.esc(x.solicitNum)}</td>
            <td style="font-size:10pt">${Utils.esc(x.name)}</td>
            <td style="font-size:9pt">${Utils.esc(x.procedure?.split('—')[1]?.trim() || x.procedure?.split(' ').slice(0, 2).join(' ') || '—')}</td>
            <td style="font-size:9pt">${Utils.esc(x.status)}</td>
          </tr>`).join('')}
        </table>

        ${this._localDate()}
        ${this._signs2(r, lh)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  _buildLoteDetalhado(data, lh, r) {
    let pages = '';
    data.forEach(c => {
      pages += this._buildFicha(c, lh, r);
    });
    return pages;
  },

  _buildResumoExecutivo(data, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const approved = data.filter(x => ['Aprovado', 'Agendado', 'Realizado'].includes(x.status)).length;
    const done = data.filter(x => x.status === 'Realizado').length;
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Resumo Executivo — Programa Itapajé Mais Saúde</div>
        <div class="doc-ref-box">Lei Municipal nº 2.399/2025 · ${today}</div>
        <div style="margin:12px 0;font-size:11pt;line-height:1.9;text-align:justify">
          O Programa Itapajé Mais Saúde, em consonância com os objetivos estabelecidos pela Lei Municipal nº 2.399/2025 e o Decreto nº 49/2025, registrou no período referenciado um total de <strong>${data.length}</strong> solicitações formalizadas junto à Secretaria Municipal de Saúde do Município de ${MUNICIPIO}/${UF}, Tel.: ${PHONE_OFICIAL}.
        </div>
        <div style="font-size:11pt;line-height:1.9;text-align:justify;margin-bottom:10px">
          Do total de casos analisados, <strong>${approved}</strong> foram aprovados e encaminhados para realização dos procedimentos, representando ${data.length > 0 ? Math.round(approved/data.length*100) : 0}% dos casos. Destes, <strong>${done}</strong> procedimento(s) ${done === 1 ? 'foi efetivamente realizado' : 'foram efetivamente realizados'}, configurando atendimento integral às demandas identificadas.
        </div>
        <table class="batch-summary-table" style="margin:12px 0">
          <tr><th>Indicador</th><th>Valor</th></tr>
          <tr><td>Total de solicitações</td><td>${data.length}</td></tr>
          <tr><td>Aprovados (incluindo agendados)</td><td>${approved}</td></tr>
          <tr><td>Procedimentos realizados</td><td>${done}</td></tr>
          <tr><td>Taxa de aprovação</td><td>${data.length > 0 ? Math.round(approved/data.length*100) : 0}%</td></tr>
          <tr><td>Taxa de realização</td><td>${approved > 0 ? Math.round(done/approved*100) : 0}%</td></tr>
        </table>
        ${this._localDate()}
        ${this._signs2(r, lh)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  previewLote() {
    const data = this._getLoteData();
    if (data.length === 0) { UI.toast('Nenhum caso no período selecionado.', 'error'); return; }
    const lh = DB.getLH(); const r = DB.getResp();
    const tipo = document.getElementById('lote-type')?.value || 'consolidado';
    let html = '';
    if (tipo === 'consolidado') html = this._buildLoteConsolidado(data, lh, r);
    else if (tipo === 'detalhado') html = this._buildLoteDetalhado(data, lh, r);
    else html = this._buildResumoExecutivo(data, lh, r);
    document.getElementById('print-preview-content').innerHTML = html;
    UI.showModal('modal-print-preview');
  },

  printLote() {
    const data = this._getLoteData();
    if (data.length === 0) { UI.toast('Nenhum caso no período selecionado.', 'error'); return; }
    const lh = DB.getLH(); const r = DB.getResp();
    const tipo = document.getElementById('lote-type')?.value || 'consolidado';
    let html = '';
    if (tipo === 'consolidado') html = this._buildLoteConsolidado(data, lh, r);
    else if (tipo === 'detalhado') html = this._buildLoteDetalhado(data, lh, r);
    else html = this._buildResumoExecutivo(data, lh, r);
    this._printWin(html, 'Relatório de Lote — ' + tipo);
  },

  /* ── LISTA DE PROTOCOLOS ── */
  _previewProtocolCount() {
    const ims = DB.getIMS();
    UI.toast(ims.length + ' protocolo(s) disponíveis.');
  },

  _buildProtocolList(data, lh, r) {
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    return `<div class="doc-a4">
      ${this._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">Lista de Protocolos — Programa Itapajé Mais Saúde 2026</div>
        <div class="doc-ref-box">Emitido em: ${today} &nbsp;|&nbsp; Secretaria Municipal de Saúde — ${MUNICIPIO}/${UF} &nbsp;|&nbsp; Tel.: ${PHONE_OFICIAL}</div>
        <table class="batch-summary-table">
          <tr><th style="width:30%">Nº Protocolo</th><th style="width:34%">Paciente</th><th style="width:20%">Data Solic.</th><th style="width:16%">Status</th></tr>
          ${data.map((x, i) => `<tr>
            <td style="font-family:monospace;font-size:10pt;font-weight:bold;color:#1b5e20">${Utils.esc(x.solicitNum)}</td>
            <td style="font-size:10pt">${Utils.esc(x.name)}</td>
            <td style="font-size:10pt">${Utils.fDate(x.date || new Date(x.createdAt).toISOString().split('T')[0])}</td>
            <td style="font-size:9.5pt">${Utils.esc(x.status)}</td>
          </tr>`).join('')}
        </table>
        <div style="margin-top:10px;font-size:9.5pt;color:#555">Total: ${data.length} protocolo(s) · Numeração padrão: AAAA.MM.DD.SEQUENCIAL — Ex: 2026.04.11.00</div>
        ${this._localDate()}
        ${this._signs1center(r)}
      </div>
      ${this._buildFooter(lh, r)}
    </div>`;
  },

  previewProtocols() {
    const period = document.getElementById('proto-period')?.value || 'all';
    const order = document.getElementById('proto-order')?.value || 'num';
    let data = DB.getIMS();
    if (period === 'month') data = Utils.filterByPeriod(data, 'month');
    else if (period === 'year') data = Utils.filterByPeriod(data, 'year');
    if (order === 'num') data.sort((a, b) => (a.solicitNum || '').localeCompare(b.solicitNum || ''));
    else if (order === 'name') data.sort((a, b) => a.name.localeCompare(b.name));
    else data.sort((a, b) => b.createdAt - a.createdAt);
    if (data.length === 0) { UI.toast('Nenhum protocolo encontrado.', 'error'); return; }
    const lh = DB.getLH(); const r = DB.getResp();
    document.getElementById('print-preview-content').innerHTML = this._buildProtocolList(data, lh, r);
    UI.showModal('modal-print-preview');
  },

  printProtocols() {
    const period = document.getElementById('proto-period')?.value || 'all';
    const order = document.getElementById('proto-order')?.value || 'num';
    let data = DB.getIMS();
    if (period === 'month') data = Utils.filterByPeriod(data, 'month');
    else if (period === 'year') data = Utils.filterByPeriod(data, 'year');
    if (order === 'num') data.sort((a, b) => (a.solicitNum || '').localeCompare(b.solicitNum || ''));
    else if (order === 'name') data.sort((a, b) => a.name.localeCompare(b.name));
    if (data.length === 0) { UI.toast('Nenhum protocolo.', 'error'); return; }
    this._printWin(this._buildProtocolList(data, DB.getLH(), DB.getResp()), 'Protocolos IMS');
  },

  /* ── WINDOW PRINT ── */
  _printWin(html, title) {
    const lh = DB.getLH(); const r = DB.getResp();
    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
      <title>${title || 'SAS — Itapajé Mais Saúde'}</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Times New Roman',Times,serif;background:#fff;font-size:11.5pt}
        .doc-a4{width:210mm;min-height:297mm;page-break-after:always;margin:0 auto;display:grid;grid-template-rows:auto 1fr auto;background:#fff}
        .doc-a4:last-child{page-break-after:avoid}
        .doc-header-wrap{padding:8mm 15mm 0}
        .doc-header-img{max-height:62px;object-fit:contain}
        .doc-header-img-area{margin-bottom:5px}
        .doc-header-lines{line-height:1.35}
        .doc-divider{height:3px;margin:4px 15mm 0}
        .doc-content{padding:6mm 15mm 4mm}
        .doc-footer-area{padding:4mm 15mm 6mm;border-top:1px solid #aaa;font-size:8.5pt;color:#444;text-align:center;line-height:1.6}
        .doc-subject{text-align:center;font-size:12.5pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin:6px 0 12px;letter-spacing:.5px}
        .doc-section-header{font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:4px 8px;margin:8px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32}
        .doc-table{width:100%;border-collapse:collapse;margin-bottom:8px}
        .doc-table td{padding:4px 7px;font-size:10.5pt;vertical-align:top;border:.5px solid #ccc}
        .lbl{font-weight:bold;background:#f5f5f5;width:38%}
        .val{width:62%}
        .doc-body-text{font-size:11pt;line-height:1.9;text-align:justify;margin:6px 0;text-indent:1.25cm}
        .doc-body-text-noindent{font-size:11pt;line-height:1.9;text-align:justify;margin:6px 0}
        .doc-local-date{text-align:right;font-size:10.5pt;margin:6px 0 10px;font-style:italic}
        .doc-auth-box{text-align:center;margin:10mm 0 6mm;padding:6px 0;border:1.5px solid #2d7d32;font-size:13pt;font-weight:bold;text-transform:uppercase;background:#e8f5e9;letter-spacing:1px}
        .doc-sign-row{display:grid;gap:28px;margin-top:14mm}
        .doc-sign-block{text-align:center}
        .doc-sign-line-top{border-top:1px solid #000;padding-top:5px;font-size:10.5pt;font-weight:bold}
        .doc-sign-sub{font-size:9.5pt;color:#333;line-height:1.5}
        .doc-ref-box{background:#e8f5e9;border:1px solid #2d7d32;padding:7px 12px;font-size:10.5pt;margin:8px 0;border-radius:4px}
        .doc-capa-title{text-align:center;font-size:14pt;font-weight:bold;text-transform:uppercase;margin:10mm 0 6mm;line-height:1.4}
        .doc-capa-num{text-align:center;font-size:12pt;font-weight:bold;margin-bottom:8mm}
        .doc-capa-paciente{text-align:center;border:2px solid #2d7d32;padding:8mm;margin:8mm 0;background:#f9fff9}
        .doc-capa-label{font-size:10pt;text-decoration:underline;margin-bottom:4px}
        .doc-capa-name{font-size:16pt;font-weight:bold}
        .doc-capa-proc{text-align:center;font-size:12pt;margin:8mm 0}
        .doc-capa-date{text-align:center;font-size:13pt;font-weight:bold;margin-top:8mm}
        .batch-summary-table{width:100%;border-collapse:collapse;margin:8px 0}
        .batch-summary-table th{background:#2d7d32;color:#fff;padding:5px 8px;font-size:10pt;text-align:left}
        .batch-summary-table td{padding:4px 8px;border-bottom:.5px solid #ccc;font-size:10pt}
        .batch-summary-table tr:nth-child(even) td{background:#f5fff5}
        @media print{@page{size:A4;margin:0}}
      </style>
    </head><body>${html}</body></html>`);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 700);
  },
};

/* ════════════════════════════════════════════════════════════
   OFICIOS MELHORADOS — IA + Separação Ofício vs Guias
════════════════════════════════════════════════════════════ */
const OficiosMod = {
  _tipo: 'autorizacao',
  _imsCase: null,
  _iaTimer: null,

  init() {
    this._populateIMSRef();
    this._setupTypeTabs();
    // Restaura número gabinete
    const gp = DB.getGabPhone();
    const gpEl = document.getElementById('gabinete-phone');
    if (gp && gpEl) gpEl.value = gp;
    Oficios.renderTable();
  },

  _populateIMSRef() {
    const sel = document.getElementById('oficio-ims-ref');
    if (!sel) return;
    const ims = DB.getIMS().sort((a, b) => a.name.localeCompare(b.name));
    sel.innerHTML = '<option value="">— Nenhum —</option>' +
      ims.map(x => `<option value="${x.id}">[${Utils.esc(x.solicitNum)}] ${Utils.esc(x.name)}</option>`).join('');
    sel.addEventListener('change', () => this._onIMSRefChange(sel.value));
  },

  _setupTypeTabs() {
    // Observa mudança no select de tipo
    const tp = document.getElementById('oficio-type');
    if (tp) tp.addEventListener('change', () => this.switchDocType(tp.value));
  },

  switchDocType(tipo) {
    this._tipo = tipo;
    this._triggerIAGeneration();
  },

  _onIMSRefChange(imsId) {
    this._imsCase = imsId ? DB.getIMSCase(imsId) : null;
    if (!this._imsCase) return;
    const c = this._imsCase;
    // Auto-preenche campos
    const dest = document.getElementById('oficio-dest');
    if (dest && !dest.value) dest.value = c.name;
    const subj = document.getElementById('oficio-subject');
    if (subj && !subj.value) {
      const tipo = document.getElementById('oficio-type')?.value || 'autorizacao';
      const labels = { autorizacao: 'Autorização para Procedimento Cirúrgico', regulacao: 'Relatório de Regulação', parecer_social: 'Parecer Social', oficio: 'Ofício', encaminhamento: 'Encaminhamento' };
      subj.value = `${labels[tipo] || 'Documento'} — Programa Itapajé Mais Saúde — ${c.name}`;
    }
    const local = document.getElementById('oficio-local');
    if (local && c.hospital) local.value = c.hospital;
    const pd = document.getElementById('oficio-proc-date');
    if (pd && c.scheduledDate) pd.value = c.scheduledDate;
    const pt = document.getElementById('oficio-proc-time');
    if (pt && c.scheduledTime) pt.value = c.scheduledTime;
    this._triggerIAGeneration();
  },

  _triggerIAGeneration() {
    clearTimeout(this._iaTimer);
    this._iaTimer = setTimeout(() => this._runIA(), 400);
  },

  _runIA() {
    const tipo = document.getElementById('oficio-type')?.value || 'autorizacao';
    const imsRef = document.getElementById('oficio-ims-ref')?.value;
    const imsCase = imsRef ? DB.getIMSCase(imsRef) : null;
    const dest = document.getElementById('oficio-dest')?.value || '';
    const obs = document.getElementById('oficio-obs-extra')?.value || '';

    const body = document.getElementById('oficio-body');
    if (!body) return;

    // Só gera se body estiver vazio ou for padrão
    if (body.value && body.value.length > 50 && !body.dataset.iaGenerated) return;

    const text = IAOficios.gerarCorpo(tipo, imsCase, { dest, obs });
    body.value = text;
    body.dataset.iaGenerated = '1';

    // Sugestões
    this._showSuggestions(tipo, imsCase);
  },

  _showSuggestions(tipo, imsCase) {
    const container = document.getElementById('ia-suggestions-container');
    if (!container) return;
    const sugs = IAOficios.getSuggestions(tipo, imsCase);
    container.innerHTML = `
      <div class="ia-suggest-label">⟡ Clique para inserir sugestão no texto</div>
      ${sugs.map((s, i) => `<div class="ia-chunk" onclick="OficiosMod.insertSuggestion(${i})" data-text="${Utils.esc(s)}">${Utils.esc(s)}</div>`).join('')}`;
  },

  insertSuggestion(idx) {
    const chunks = document.querySelectorAll('.ia-chunk');
    const chunk = chunks[idx];
    if (!chunk) return;
    const text = chunk.getAttribute('data-text');
    const body = document.getElementById('oficio-body');
    if (body) {
      body.value = (body.value ? body.value + '\n\n' : '') + text;
      body.dataset.iaGenerated = '';
      chunk.classList.add('applied');
      UI.toast('Parágrafo inserido!');
    }
  },

  clearIAFlag() {
    const body = document.getElementById('oficio-body');
    if (body) body.dataset.iaGenerated = '';
  },

  /* Gera número do ofício apenas para tipo oficio, guias têm ref interna */
  isOficio(tipo) {
    return tipo === 'oficio' || tipo === 'encaminhamento' || tipo === 'declaracao';
  },

  buildDocPage(o) {
    const r = DB.getResp(); const lh = DB.getLH();
    const imsRef = o.imsRef ? DB.getIMSCase(o.imsRef) : null;
    const today = o.date ? Utils.fDate(o.date) : new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const isOficio = this.isOficio(o.type);

    if (isOficio) {
      return PrintMod._printWin(this._buildOficioPage(o, imsRef, lh, r, today), o.subject || 'Ofício');
    } else {
      // Guias usam layout centralizado
      return PrintMod._printWin(this._buildGuiaPage(o, imsRef, lh, r, today), o.subject || 'Guia');
    }
  },

  _buildOficioPage(o, imsRef, lh, r, today) {
    return `<div class="doc-a4">
      ${PrintMod._buildHeader(lh)}
      <div class="doc-content">
        <div style="text-align:right;font-size:10.5pt;margin-bottom:8px">${MUNICIPIO} – ${UF}, ${today}</div>
        <div style="text-align:center;margin-bottom:4px"><span class="doc-oficio-badge">Ofício</span></div>
        <div class="doc-of-num">Ofício Nº ${Utils.esc(o.num)}</div>
        ${o.dest ? `<div class="doc-destinatario"><strong>À(Ao):</strong> ${Utils.esc(o.dest)}</div>` : ''}
        <div class="doc-subject">${Utils.esc(o.subject || 'ASSUNTO')}</div>
        ${imsRef ? `<div class="doc-ref-box"><strong>Ref.:</strong> Caso IMS Nº ${Utils.esc(imsRef.solicitNum)} — Paciente: ${Utils.esc(imsRef.name)}</div>` : ''}
        <div class="doc-body-text">${Utils.esc(o.body || '').replace(/\n/g, '</div><div class="doc-body-text">')}</div>
        ${o.local || o.procDate ? `<div style="margin:12px 0;font-size:10.5pt">${o.procDate ? '<strong>Data:</strong> ' + Utils.fDate(o.procDate) + (o.procTime ? ' às ' + o.procTime : '') + '<br>' : ''}${o.local ? '<strong>Local:</strong> ' + Utils.esc(o.local) : ''}${imsRef?.hospitalAddress ? '<br>' + Utils.esc(imsRef.hospitalAddress) : ''}</div>` : ''}
        ${PrintMod._signs1center(r)}
      </div>
      ${PrintMod._buildFooter(lh, r)}
    </div>`;
  },

  _buildGuiaPage(o, imsRef, lh, r, today) {
    const typeLabels = { autorizacao: 'Guia de Autorização', regulacao: 'Relatório de Regulação Municipal', parecer_social: 'Relatório Social — Parecer Técnico', encaminhamento: 'Encaminhamento', declaracao: 'Declaração' };
    const label = typeLabels[o.type] || o.type;
    return `<div class="doc-a4">
      ${PrintMod._buildHeader(lh)}
      <div class="doc-content">
        <div class="doc-subject">${label}</div>
        ${imsRef ? `<div class="doc-ref-box">
          <strong>Nome:</strong> ${Utils.esc(imsRef.name)} &nbsp;|&nbsp;
          <strong>Nº:</strong> ${Utils.esc(imsRef.solicitNum)} &nbsp;|&nbsp;
          <strong>Data:</strong> ${Utils.fDate(imsRef.date)} &nbsp;|&nbsp;
          <strong>Proc.:</strong> ${Utils.esc(imsRef.procedure?.toUpperCase())}
        </div>` : o.dest ? `<div class="doc-ref-box"><strong>Paciente/Destinatário:</strong> ${Utils.esc(o.dest)}</div>` : ''}
        <div style="text-align:right;font-size:10.5pt;margin:6px 0 10px;font-style:italic">${MUNICIPIO} – ${UF}, ${today}</div>
        <div class="doc-body-text">${Utils.esc(o.body || '').replace(/\n/g, '</div><div class="doc-body-text">')}</div>
        ${o.type === 'autorizacao' ? `<div class="doc-auth-box">FICA AUTORIZADO</div>` : ''}
        ${o.local || o.procDate ? `<div style="margin:10px 0;font-size:10.5pt;text-align:center;border:1px solid #2d7d32;padding:8px;background:#f9fff9">
          ${o.procDate ? '<strong>Data:</strong> ' + Utils.fDate(o.procDate) + (o.procTime ? ' | <strong>Horário:</strong> ' + o.procTime : '') + '<br>' : ''}
          ${o.local ? '<strong>Local:</strong> ' + Utils.esc(o.local) : ''}
          ${imsRef?.hospitalAddress ? '<br>' + Utils.esc(imsRef.hospitalAddress) : ''}
        </div>` : ''}
        <div style="text-align:right;font-size:10.5pt;margin:10px 0;font-style:italic">${MUNICIPIO} – ${UF}, ${today}</div>
        ${PrintMod._signs1center(r)}
      </div>
      ${PrintMod._buildFooter(lh, r)}
    </div>`;
  },
};

/* ════════════════════════════════════════════════════════════
   MOBILE UI — Toggle sidebar, topbar
════════════════════════════════════════════════════════════ */
const MobileUI = {
  init() {
    // Garante topbar mobile existe
    const topbar = document.getElementById('topbar-mobile');
    if (topbar) topbar.classList.remove('hidden');
    // Fecha sidebar ao trocar de aba no mobile
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        if (window.innerWidth <= 600) MobileUI.closeSidebar();
      });
    });
    // Atualiza avatar topbar
    const session = DB.getSession();
    if (session) {
      const av = document.getElementById('topbar-avatar');
      if (av) av.textContent = Utils.initials(session.user);
    }
  },
  openSidebar() {
    document.getElementById('sidebar')?.classList.add('open');
    const ov = document.getElementById('sidebar-overlay');
    if (ov) { ov.classList.remove('hidden'); ov.classList.add('active'); }
    document.body.style.overflow = 'hidden';
  },
  closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    const ov = document.getElementById('sidebar-overlay');
    if (ov) { ov.classList.add('hidden'); ov.classList.remove('active'); }
    document.body.style.overflow = '';
  },
  toggle() {
    const sb = document.getElementById('sidebar');
    if (sb?.classList.contains('open')) this.closeSidebar();
    else this.openSidebar();
  },
};

/* ════════════════════════════════════════════════════════════
   PATCH — adiciona ao UI.toggleSidebar e UI.switchTab
════════════════════════════════════════════════════════════ */
if (typeof UI !== 'undefined') {
  UI.toggleSidebar = () => MobileUI.toggle();
  const _origSwitch = UI.switchTab.bind(UI);
  UI.switchTab = (id, btn) => {
    _origSwitch(id, btn);
    // Adiciona callbacks extras
    if (id === 'print') PrintMod.init();
    if (id === 'oficios') OficiosMod.init();
  };
}

/* ════════════════════════════════════════════════════════════
   INIT DOS NOVOS MÓDULOS
════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  MobileUI.init();
  // Adiciona ouvinte no body oficio para limpar flag IA quando usuário edita
  document.getElementById('oficio-body')?.addEventListener('input', () => OficiosMod.clearIAFlag());
  // Adiciona print tabs se existir
  const firstPrintTab = document.querySelector('.print-tab');
  if (firstPrintTab) PrintMod.switchTab('individual', firstPrintTab);
  // Patch nos botões de imprimir do oficio
  const printOfBtn = document.getElementById('btn-print-oficio');
  if (printOfBtn) printOfBtn.onclick = () => {
    const id = document.getElementById('oficio-id')?.value;
    if (!id) { UI.toast('Salve o documento primeiro.', 'error'); return; }
    const o = DB.getOficiosAll().find(x => x.id === id);
    if (o) OficiosMod.buildDocPage(o);
  };
});

/* ════════════════════════════════════════════════════════════
   GUIAS — Autorizações, Pareceres, Regulação (separado de Ofícios)
════════════════════════════════════════════════════════════ */
const Guias = {
  _imsCase: null,

  openForm(id = null) {
    const f = document.getElementById('guias-form');
    f.classList.remove('hidden');
    document.getElementById('guias-form-title').textContent = id ? 'Editar Guia' : 'Nova Guia';
    this._populateIMSRef();
    if (!id) {
      ['guia-body', 'guia-local'].forEach(x => { const el = document.getElementById(x); if (el) el.value = ''; });
      ['guia-date', 'guia-proc-date', 'guia-proc-time'].forEach(x => { const el = document.getElementById(x); if (el) el.value = ''; });
      document.getElementById('guia-date').value = new Date().toISOString().split('T')[0];
    }
  },

  closeForm() {
    document.getElementById('guias-form').classList.add('hidden');
  },

  _populateIMSRef() {
    const sel = document.getElementById('guia-ims-ref');
    if (!sel) return;
    const ims = DB.getIMS().sort((a, b) => a.name.localeCompare(b.name));
    sel.innerHTML = '<option value="">— Nenhum —</option>' +
      ims.map(x => `<option value="${x.id}">[${Utils.esc(x.solicitNum)}] ${Utils.esc(x.name)}</option>`).join('');
  },

  autoFillFromIMS() {
    const id = document.getElementById('guia-ims-ref').value;
    this._imsCase = id ? DB.getIMSCase(id) : null;
    if (this._imsCase) {
      const c = this._imsCase;
      if (c.hospital) document.getElementById('guia-local').value = c.hospital;
      if (c.scheduledDate) document.getElementById('guia-proc-date').value = c.scheduledDate;
      if (c.scheduledTime) document.getElementById('guia-proc-time').value = c.scheduledTime;
    }
  },

  onTypeChange() {
    // Quando tipo muda, limpa body para gerar novo
    const body = document.getElementById('guia-body');
    if (body) body.value = '';
  },

  generateAI() {
    const tipo = document.getElementById('guia-type')?.value || 'autorizacao';
    const id = document.getElementById('guia-ims-ref')?.value;
    const imsCase = id ? DB.getIMSCase(id) : null;
    const body = document.getElementById('guia-body');
    if (!body) return;
    // Mapa de tipos para IAOficios
    const tipoMap = {
      cadastro_atendimento: 'regulacao',
      autorizacao: 'autorizacao',
      parecer_social: 'parecer_social',
      regulacao: 'regulacao',
      encaminhamento: 'encaminhamento',
    };
    const text = IAOficios.gerarCorpo(tipoMap[tipo] || tipo, imsCase, {});
    // Efeito digitação
    body.value = '';
    let i = 0;
    const interval = setInterval(() => {
      body.value += text[i++];
      if (i >= text.length) clearInterval(interval);
    }, Math.max(4, Math.min(12, 2500 / text.length)));
    UI.toast('Gerando texto com IA...');
  },

  save() {
    const body = document.getElementById('guia-body')?.value.trim();
    if (!body) { UI.toast('Preencha o conteúdo.', 'error'); return; }
    const all = DB.getOficiosAll();
    const imsRef = document.getElementById('guia-ims-ref')?.value;
    const imsCase = imsRef ? DB.getIMSCase(imsRef) : null;
    const tipo = document.getElementById('guia-type')?.value || 'autorizacao';
    const o = {
      id: Utils.uid(),
      num: 'GUIA/' + Utils.genOficioNum(),
      type: tipo,
      dest: imsCase ? imsCase.name : '—',
      subject: tipo.replace(/_/g, ' ').toUpperCase(),
      body,
      local: document.getElementById('guia-local')?.value || '',
      procDate: document.getElementById('guia-proc-date')?.value || '',
      procTime: document.getElementById('guia-proc-time')?.value || '',
      imsRef: imsRef || '',
      date: document.getElementById('guia-date')?.value || '',
      isGuia: true,
      createdAt: Date.now(),
    };
    all.push(o);
    DB.saveOficios(all);
    this.closeForm();
    this.renderTable();
    UI.toast('Guia salva!');
  },

  renderTable() {
    const all = DB.getOficiosAll().filter(x => x.isGuia);
    const tb = document.getElementById('guias-tbody');
    if (!tb) return;
    if (all.length === 0) { tb.innerHTML = '<tr class="empty-row"><td colspan="5">Nenhuma guia registrada.</td></tr>'; return; }
    tb.innerHTML = [...all].sort((a, b) => b.createdAt - a.createdAt).map(o => {
      const typeLabels = { cadastro_atendimento: 'Cadastro Atend.', autorizacao: 'Guia Autorização', parecer_social: 'Parecer Social', regulacao: 'Rel. Regulação', encaminhamento: 'Encaminhamento' };
      return `<tr>
        <td>${typeLabels[o.type] || o.type}</td>
        <td class="table-name">${Utils.esc(o.dest)}</td>
        <td><span class="table-num">${Utils.esc(o.imsRef ? (DB.getIMSCase(o.imsRef)?.solicitNum || '—') : '—')}</span></td>
        <td>${Utils.fDate(o.date)}</td>
        <td><div class="table-actions">
          <button onclick="Guias.printPreviewOf('${o.id}')">🖨 Imprimir</button>
          <button class="btn-delete" onclick="Guias.del('${o.id}')">Excluir</button>
        </div></td>
      </tr>`;
    }).join('');
  },

  printPreview() {
    UI.toast('Salve a guia primeiro para pré-visualizar.', 'error');
  },

  printPreviewOf(id) {
    const o = DB.getOficiosAll().find(x => x.id === id);
    if (!o) return;
    const imsRef = o.imsRef ? DB.getIMSCase(o.imsRef) : null;
    const lh = DB.getLH(); const r = DB.getResp();
    const today = o.date ? Utils.fDate(o.date) : new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const html = OficiosMod._buildGuiaPage(o, imsRef, lh, r, today);
    document.getElementById('print-preview-content').innerHTML = html;
    UI.showModal('modal-print-preview');
  },

  del(id) {
    DB.saveOficios(DB.getOficiosAll().filter(x => x.id !== id));
    this.renderTable();
    UI.toast('Guia excluída.');
  },
};

/* ════════════════════════════════════════════
   PATCH OFICIOS — IA integrada ao módulo existente
════════════════════════════════════════════ */
if (typeof Oficios !== 'undefined') {
  Oficios.generateAI = function() {
    const imsRefEl = document.getElementById('oficio-ims-ref');
    const imsId = imsRefEl?.value;
    const imsCase = imsId ? DB.getIMSCase(imsId) : null;
    const dest = document.getElementById('oficio-dest')?.value || '';
    const fecho = document.getElementById('oficio-fecho')?.value || 'Atenciosamente';
    const r = DB.getResp();

    const text = IAOficios.gerarCorpo('oficio', imsCase, { dest }) + '\n\n' + fecho + '\n\n' +
      (r.managerName || 'Francisco Maílson de Sousa Moreira') + '\n' +
      (r.managerRole || 'Gerente de Apoio Social') + '\n' +
      (r.unit || 'Secretaria Municipal de Saúde') + ' — ' + MUNICIPIO + '/' + UF + '\n' +
      'Tel.: ' + PHONE_OFICIAL;

    const body = document.getElementById('oficio-body');
    if (!body) return;
    body.value = '';
    let i = 0;
    const interval = setInterval(() => {
      body.value += text[i++];
      if (i >= text.length) clearInterval(interval);
    }, Math.max(4, Math.min(12, 2500 / text.length)));
    UI.toast('Gerando ofício com IA...');
  };

  Oficios.autoFillFromIMS = function() {
    const id = document.getElementById('oficio-ims-ref')?.value;
    const c = id ? DB.getIMSCase(id) : null;
    if (!c) return;
    const dest = document.getElementById('oficio-dest');
    if (dest && !dest.value) dest.value = c.name;
    const subj = document.getElementById('oficio-subject');
    if (subj && !subj.value) subj.value = 'Ofício referente ao Programa Itapajé Mais Saúde — Paciente: ' + c.name;
  };

  // Override printPreview para usar OficiosMod
  Oficios.printPreview = function() {
    const id = document.getElementById('oficio-id')?.value;
    if (!id) { UI.toast('Salve o ofício primeiro.', 'error'); return; }
    const o = DB.getOficiosAll().find(x => x.id === id);
    if (!o) return;
    const imsRef = o.imsRef ? DB.getIMSCase(o.imsRef) : null;
    const lh = DB.getLH(); const r = DB.getResp();
    const today = o.date ? Utils.fDate(o.date) : new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const html = OficiosMod._buildOficioPage(o, imsRef, lh, r, today);
    document.getElementById('print-preview-content').innerHTML = html;
    UI.showModal('modal-print-preview');
  };
}

/* ════════════════════════════════════════════
   PATCH PRINT — override IMS detail print
════════════════════════════════════════════ */
if (typeof Print !== 'undefined') {
  Print.printIMS = function(id) {
    const html = PrintMod.buildCompleteProcess(id);
    PrintMod._printWin(html, 'Processo Completo — ' + (DB.getIMSCase(id)?.name || ''));
  };
}

// Adicionar Guias ao switchTab
document.addEventListener('DOMContentLoaded', () => {
  if (typeof UI !== 'undefined') {
    const _origSwitch2 = UI.switchTab.bind(UI);
    UI.switchTab = (id, btn) => {
      _origSwitch2(id, btn);
      if (id === 'guias') Guias.renderTable();
    };
  }
});

/* ═══════════════════════════════════════════════════════════════
   SAS v4.2 — PATCH DEFINITIVO
   WhatsApp completo · Ofício ABNT sem IMS · IMS 3 páginas padrão
   Tel.: (85) 9 9126-4880 · Francisco Maílson de Sousa Moreira
   ═══════════════════════════════════════════════════════════════ */

/* ── CONSTANTES GLOBAIS ── */
const PHONE_SEC    = '(85) 9 9126-4880';
const MANAGER_NAME = 'Francisco Maílson de Sousa Moreira';
const MANAGER_ROLE = 'Gerente de Apoio Social';
const SEC_NOME     = 'Secretaria Municipal de Saúde';
const SEC_END      = 'R. São Francisco, Nº 225 – Centro, Itapajé/CE';
const SEC_EMAIL    = 'saude@itapaje.ce.gov.br';
const SEC_SITE     = 'www.itapaje.ce.gov.br';
const CEP_SEC      = 'CEP: 62.600-000';
const CIDADE       = 'Itapajé';
const UF_SIGLA     = 'CE';

/* ══════════════════════════════════════════════════════════════
   ① WHATSAPP — Override definitivo de todas as mensagens
══════════════════════════════════════════════════════════════ */

/* Rodapé padrão de todas as mensagens ao PACIENTE */
function _waFooterPaciente() {
  const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  return `\n\n─────────────────────────\n📞 *${PHONE_SEC}*\n👤 Gerente de Apoio Social\n*${MANAGER_NAME}*\n🏥 *${SEC_NOME}*\n📍 ${SEC_END}\n_${hoje}_`;
}

/* Rodapé padrão das mensagens ao GABINETE */
function _waFooterGabinete() {
  const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  return `\n\n─────────────────────────\n_${MANAGER_NAME}_\n_${MANAGER_ROLE}_\n_${SEC_NOME} — ${CIDADE}/${UF_SIGLA}_\n_Tel.: ${PHONE_SEC}_\n_${hoje}_`;
}

/* ── MENSAGENS PARA PACIENTE ── */
function waMsgPaciente(item, tipo) {
  const isIMS  = !!item.solicitNum;
  const prog   = isIMS ? '*Programa Itapajé Mais Saúde*' : `*${SEC_NOME}*`;
  const proc   = item.procedure  || item.desc || '';
  const num    = item.solicitNum || '';
  const sched  = item.scheduledDate
    ? Utils.fDate(item.scheduledDate) + (item.scheduledTime ? ' às ' + item.scheduledTime : '')
    : '';
  const hosp   = item.hospital || '';
  const hospEnd= item.hospitalAddress || '';

  const msgs = {

    status:
      `Olá, *${item.name}*! 👋\n\n` +
      `Informamos que seu processo junto ao ${prog} foi atualizado.\n\n` +
      `📋 *Status atual:* ${item.status}\n` +
      (num  ? `🔢 *Nº do processo:* ${num}\n`          : '') +
      (proc ? `🏥 *Procedimento:* ${proc}\n`            : '') +
      `\nDúvidas? Entre em contato conosco.` +
      _waFooterPaciente(),

    aprovado:
      `✅ *${item.name}*, seu processo foi *APROVADO*!\n\n` +
      `🎉 O ${prog} confirma a aprovação da sua solicitação.\n\n` +
      (num   ? `🔢 *Nº:* ${num}\n`                       : '') +
      (proc  ? `🏥 *Procedimento:* ${proc}\n`             : '') +
      (sched ? `📅 *Data/Hora:* ${sched}\n`              : '') +
      (hosp  ? `🏨 *Local:* ${hosp}\n`                   : '') +
      (hospEnd ? `📍 ${hospEnd}\n`                        : '') +
      `\n📌 *Orientações:*\n` +
      `• Comparecer com 30 min de antecedência\n` +
      `• Levar RG/CNH original e CPF\n` +
      `• Apresentar este comprovante\n` +
      `\nDúvidas? Entre em contato conosco.` +
      _waFooterPaciente(),

    pendente:
      `⚠️ *${item.name}*, seu processo está com *DOCUMENTAÇÃO PENDENTE*.\n\n` +
      (num ? `🔢 *Nº:* ${num}\n\n` : '') +
      `Por favor, compareça à Secretaria Municipal de Saúde para regularizar.\n\n` +
      `📍 *${SEC_END}*\n\nDúvidas? Entre em contato conosco.` +
      _waFooterPaciente(),

    agendamento:
      `📅 *${item.name}*, seu procedimento foi *AGENDADO*!\n\n` +
      (proc  ? `🏥 *Procedimento:* ${proc}\n` : '') +
      (sched ? `📅 *Data/Hora:* ${sched}\n`  : '') +
      (hosp  ? `🏨 *Local:* ${hosp}\n`        : '') +
      (hospEnd ? `📍 ${hospEnd}\n`             : '') +
      `\n📌 *Lembre-se:*\n` +
      `• Chegar 30 min antes\n• Trazer RG/CNH original e CPF\n• Trazer este comprovante\n` +
      `\nDúvidas? Entre em contato conosco.` +
      _waFooterPaciente(),

    reprovado:
      `❌ *${item.name}*, seu processo *não foi aprovado* neste momento.\n\n` +
      (num ? `🔢 *Nº:* ${num}\n\n` : '') +
      `Compareça à Secretaria Municipal de Saúde para obter mais informações.\n\n` +
      `📍 *${SEC_END}*\n\nDúvidas? Entre em contato conosco.` +
      _waFooterPaciente(),

    custom:
      (document.getElementById('wa-custom-msg')?.value || '') + _waFooterPaciente(),
  };

  return msgs[tipo] || msgs.status;
}

/* ── MENSAGEM GABINETE — CASO IMS (todos os dados) ── */
function waMsgGabineteIMS(item, tipo, parecer, visitDate) {
  const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  const r    = DB.getResp();

  const blocoSolicitacao =
    `🔢 *Nº Solicitação:* ${item.solicitNum || '—'}\n` +
    `📅 *Data do Pedido:* ${Utils.fDate(item.date) || '—'}\n` +
    `📅 *Data da Visita Social:* ${visitDate ? Utils.fDate(visitDate) : '[INFORMAR]'}\n` +
    `🏥 *Procedimento:* ${item.procedure || '—'}\n` +
    `🏨 *Hospital previsto:* ${item.hospital || '[INFORMAR]'}\n` +
    (item.scheduledDate
      ? `📅 *Agend.:* ${Utils.fDate(item.scheduledDate)}${item.scheduledTime ? ' às ' + item.scheduledTime : ''}\n`
      : '');

  const blocoPaciente =
    `👤 *Nome:* ${item.name}\n` +
    `🗓 *Nascimento:* ${Utils.fDate(item.birth)} (${Utils.age(item.birth)})\n` +
    `🪪 *CPF:* ${item.cpf || '—'}\n` +
    `📞 *Telefone:* ${item.phone}\n` +
    `🏠 *Endereço:* ${item.address || '—'}, ${item.neighborhood || '—'}, ${CIDADE}/${UF_SIGLA}\n` +
    `💰 *Renda:* R$ ${item.income || '—'} (${item.incomeRange || '—'})\n` +
    `🏡 *Habitação:* ${item.housing || '—'}${item.services ? ' · ' + item.services : ''}\n` +
    `👩 *Mãe:* ${item.mother || '—'}${item.motherProf ? ' (' + item.motherProf + ')' : ''}\n` +
    `💼 *Profissão:* ${item.profession || '—'}\n` +
    `📚 *Escolaridade:* ${item.education || '—'}`;

  const blocoElegibilidade =
    `${item.eligResident  ? '✅' : '❌'} Residente em ${CIDADE}/CE\n` +
    `${item.eligIncome    ? '✅' : '❌'} Renda ≤ 2 salários mínimos\n` +
    `${item.eligFila      ? '✅' : '❌'} Em fila SUS sem previsão\n` +
    `${item.eligIndicacao ? '✅' : '❌'} Indicação médica cirúrgica\n` +
    `${item.eligDocs      ? '✅' : '❌'} Documentação apresentada`;

  const blocoRegulacao = item.regulation ||
    'Paciente em fila de espera no SISREG/CE sem previsão de agendamento.';

  const blocoParecer = parecer ||
    `Paciente preenche os critérios de elegibilidade da Lei Municipal nº 2.399/2025. Parecer FAVORÁVEL à inclusão no Programa Itapajé Mais Saúde.`;

  const corpo =
    `*🏥 ${SEC_NOME.toUpperCase()}*\n` +
    `*Serviço de Apoio Social — ${CIDADE}/${UF_SIGLA}*\n` +
    `_${hoje}_\n\n` +
    (tipo === 'solicitacao_total'
      ? `*━━ SOLICITAÇÃO TOTAL — PROG. IMS ━━*\n*⚡ Aguarda APROVAÇÃO ou REPROVAÇÃO*\n\n`
      : tipo === 'urgente'
        ? `*🚨 CASO URGENTE — ${item.name.toUpperCase()} 🚨*\n\n`
        : `*📋 ${tipo === 'parecer' ? 'PARECER SOCIAL' : 'RELATÓRIO COMPLETO'}*\n\n`) +
    `*━━━━━━ DADOS DO PROCESSO ━━━━━━*\n` + blocoSolicitacao +
    `\n*━━━━━━ DADOS DO PACIENTE ━━━━━━*\n` + blocoPaciente +
    `\n\n*━━━━━━ REGULAÇÃO SISREG ━━━━━━*\n${blocoRegulacao}` +
    `\n\n*━━━━━━ ELEGIBILIDADE ━━━━━━*\n` + blocoElegibilidade +
    `\n\n*━━━━━━ PARECER TÉCNICO ━━━━━━*\n${blocoParecer}` +
    (item.obs ? `\n\n*📝 Observações:* ${item.obs}` : '') +
    `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━━━*\n` +
    (tipo === 'solicitacao_total' || tipo === 'urgente'
      ? `✅ *[APROVAR]* — Responda: APROVADO\n❌ *[REPROVAR]* — Responda: REPROVADO\n` +
        `*━━━━━━━━━━━━━━━━━━━━━━━━━━━━*`
      : ``) +
    _waFooterGabinete();

  return corpo;
}

/* ── MENSAGEM GABINETE — PACIENTE GERAL (todos os dados) ── */
function waMsgGabineteGeral(patient, parecer, visitDate) {
  const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  const hist = DB.getHistory(patient.id).slice(0, 3);

  const blocoPaciente =
    `👤 *Nome:* ${patient.name}\n` +
    `🗓 *Nascimento:* ${Utils.fDate(patient.birth)} (${Utils.age(patient.birth)})\n` +
    `🪪 *CPF:* ${patient.cpf || '—'}\n` +
    `📞 *Telefone:* ${patient.phone}\n` +
    `🏠 *Endereço:* ${patient.street || '—'}, ${patient.number || ''}, ${patient.neighborhood || '—'}, ${CIDADE}/${UF_SIGLA}\n` +
    `💰 *Situação financeira:* ${patient.financial || '—'}\n` +
    `🎁 *Benefícios:* ${patient.benefits || 'Nenhum informado'}\n` +
    `👩 *Mãe:* ${patient.mother || '—'}\n` +
    `👨 *Pai:* ${patient.father || '—'}`;

  const blocoProcesso =
    `📋 *Status atual:* ${patient.status}\n` +
    `📅 *Data da Visita Social:* ${visitDate ? Utils.fDate(visitDate) : '[INFORMAR]'}\n` +
    (patient.obs ? `📝 *Observações:* ${patient.obs}` : '');

  const blocoHist = hist.length > 0
    ? hist.map(h => `• [${Utils.fDate(new Date(h.at).toISOString().split('T')[0])}] ${h.status} — ${h.obs}`).join('\n')
    : 'Sem histórico anterior.';

  return (
    `*🏥 ${SEC_NOME.toUpperCase()}*\n` +
    `*Serviço de Apoio Social — ${CIDADE}/${UF_SIGLA}*\n` +
    `_${hoje}_\n\n` +
    `*━━ SOLICITAÇÃO TOTAL — ATENDIMENTO GERAL ━━*\n` +
    `*⚡ Aguarda APROVAÇÃO ou REPROVAÇÃO*\n\n` +
    `*━━━━━━ DADOS DO PACIENTE ━━━━━━*\n` + blocoPaciente +
    `\n\n*━━━━━━ STATUS DO PROCESSO ━━━━━━*\n` + blocoProcesso +
    `\n\n*━━━━━━ HISTÓRICO RECENTE ━━━━━━*\n` + blocoHist +
    `\n\n*━━━━━━ PARECER TÉCNICO ━━━━━━*\n` +
    (parecer || 'Paciente atendido pelo Serviço Social. Solicitamos análise e decisão do gabinete.') +
    `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━━━*\n` +
    `✅ *[APROVAR]* — Responda: APROVADO\n` +
    `❌ *[REPROVAR]* — Responda: REPROVADO\n` +
    `*━━━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
    _waFooterGabinete()
  );
}

/* ── Injeta os overrides no WhatsApp ── */
document.addEventListener('DOMContentLoaded', () => {

  if (typeof WhatsApp === 'undefined') return;

  /* Override _buildPatientMsg */
  WhatsApp._buildPatientMsg = waMsgPaciente;

  /* Override _buildGabineteMsg — detecta IMS vs Geral */
  WhatsApp._buildGabineteMsg = function(item, tipo, parecer, visitDate) {
    if (item && item.solicitNum) {
      return waMsgGabineteIMS(item, tipo, parecer, visitDate);
    }
    return waMsgGabineteGeral(item, parecer, visitDate);
  };

  /* Override previewMsg para usar nova função */
  WhatsApp.previewMsg = function() {
    const val  = document.getElementById('wa-patient-select')?.value;
    const tipo = document.getElementById('wa-msg-type')?.value || 'status';
    const cg   = document.getElementById('wa-custom-group');
    if (cg) cg.style.display = tipo === 'custom' ? 'flex' : 'none';
    if (!val) { const b = document.getElementById('wa-bubble-text'); if (b) b.textContent = 'Selecione um paciente.'; return; }
    const [ptype, id] = val.split(':');
    const item = ptype === 'ims' ? DB.getIMSCase(id) : DB.getPatient(id);
    if (!item) return;
    const bubble = document.getElementById('wa-bubble-text');
    if (bubble) bubble.textContent = waMsgPaciente(item, tipo);
  };

  /* Override previewGabinete */
  WhatsApp.previewGabinete = function() {
    const val     = document.getElementById('wa-gab-patient')?.value;
    const tipo    = document.getElementById('wa-gab-type')?.value || 'solicitacao_total';
    const parecer = document.getElementById('wa-parecer')?.value?.trim();
    const vd      = document.getElementById('wa-visit-date')?.value;
    const prev    = document.getElementById('wa-gab-preview');
    if (!val || !prev) { if (prev) prev.textContent = 'Selecione um caso.'; return; }
    const [ptype, id] = val.split(':');
    const item = ptype === 'ims' ? DB.getIMSCase(id) : DB.getPatient(id);
    if (!item) return;
    if (item.solicitNum) prev.textContent = waMsgGabineteIMS(item, tipo, parecer, vd);
    else prev.textContent = waMsgGabineteGeral(item, parecer, vd);
  };

  /* Override sendToPatient */
  WhatsApp.sendToPatient = function() {
    const val  = document.getElementById('wa-patient-select')?.value;
    if (!val) { UI.toast('Selecione um paciente.', 'error'); return; }
    const tipo = document.getElementById('wa-msg-type')?.value || 'status';
    const [ptype, id] = val.split(':');
    const item = ptype === 'ims' ? DB.getIMSCase(id) : DB.getPatient(id);
    if (!item) return;
    const phone = Utils.cleanPhone(item.phone);
    if (!phone) { UI.toast('Paciente sem telefone.', 'error'); return; }
    const msg = waMsgPaciente(item, tipo);
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'paciente', name: item.name, phone: item.phone, type: tipo, at: Date.now() });
    if (typeof WhatsApp.renderHistory === 'function') WhatsApp.renderHistory();
    UI.toast('WhatsApp aberto para ' + item.name + '!');
  };

  /* Override sendToGabinete */
  WhatsApp.sendToGabinete = function() {
    const val     = document.getElementById('wa-gab-patient')?.value;
    const gPhone  = document.getElementById('gabinete-phone')?.value;
    if (!val)    { UI.toast('Selecione um caso.', 'error'); return; }
    if (!gPhone) { UI.toast('Informe o número do gabinete.', 'error'); return; }
    const tipo    = document.getElementById('wa-gab-type')?.value || 'solicitacao_total';
    const parecer = document.getElementById('wa-parecer')?.value?.trim();
    const vd      = document.getElementById('wa-visit-date')?.value;
    const [ptype, id] = val.split(':');
    const item = ptype === 'ims' ? DB.getIMSCase(id) : DB.getPatient(id);
    if (!item) return;
    DB.saveGabPhone(gPhone);
    const msg = item.solicitNum
      ? waMsgGabineteIMS(item, tipo, parecer, vd)
      : waMsgGabineteGeral(item, parecer, vd);
    window.open(`https://wa.me/55${Utils.cleanPhone(gPhone)}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'gabinete', name: item.name, phone: gPhone, type: tipo, at: Date.now() });
    if (typeof WhatsApp.renderHistory === 'function') WhatsApp.renderHistory();
    UI.toast('Mensagem enviada ao gabinete!');
  };

  /* Override sendDecision */
  WhatsApp.sendDecision = function(decision) {
    const val    = document.getElementById('wa-gab-patient')?.value;
    const gPhone = document.getElementById('gabinete-phone')?.value;
    if (!val) { UI.toast('Selecione um caso.', 'error'); return; }
    const [ptype, id] = val.split(':');
    const item = ptype === 'ims' ? DB.getIMSCase(id) : DB.getPatient(id);
    if (!item) return;
    const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const msg =
      `*${decision === 'Aprovado' ? '✅ APROVADO' : '❌ REPROVADO'}*\n\n` +
      `*Paciente:* ${item.name}\n` +
      (item.solicitNum ? `*Nº:* ${item.solicitNum}\n` : '') +
      (item.procedure  ? `*Procedimento:* ${item.procedure}\n` : '') +
      `\n_${MANAGER_NAME}_\n_${MANAGER_ROLE}_\n_${SEC_NOME}_\n_${hoje}_`;
    if (gPhone) window.open(`https://wa.me/55${Utils.cleanPhone(gPhone)}?text=${encodeURIComponent(msg)}`, '_blank');
    /* Atualiza status no banco */
    if (item.solicitNum) {
      item.status = decision; DB.upsertIMS(item);
    } else {
      item.status = decision; DB.upsertPatient(item);
    }
    DB.addHistory(id, { id: Utils.uid(), status: decision, obs: 'Decisão via WhatsApp', user: DB.getSession()?.user || 'Gabinete', at: Date.now() });
    DB.addWAHist({ id: Utils.uid(), to: 'gabinete_decisao', name: item.name, phone: gPhone, type: decision, at: Date.now() });
    if (typeof Dashboard !== 'undefined') Dashboard.refresh();
    if (typeof WhatsApp.renderHistory === 'function') WhatsApp.renderHistory();
    UI.toast('Decisão "' + decision + '" registrada!');
  };

  /* Override notifyPatientStatus */
  WhatsApp.notifyPatientStatus = function() {
    const item = (typeof StatusMod !== 'undefined') ? StatusMod.currentItem() : null;
    if (!item) { UI.toast('Selecione um paciente na aba Status.', 'error'); return; }
    const phone = Utils.cleanPhone(item.phone);
    if (!phone) { UI.toast('Sem telefone cadastrado.', 'error'); return; }
    const msg = waMsgPaciente(item, 'status');
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'paciente', name: item.name, phone: item.phone, type: 'status', at: Date.now() });
    if (typeof WhatsApp.renderHistory === 'function') WhatsApp.renderHistory();
    UI.toast('WhatsApp aberto!');
  };

  /* Override notifyFromIMS */
  WhatsApp.notifyFromIMS = function(id) {
    const c = DB.getIMSCase(id);
    if (!c) return;
    const phone = Utils.cleanPhone(c.phone);
    if (!phone) { UI.toast('Sem telefone cadastrado.', 'error'); return; }
    const tipoMap = { 'Aprovado': 'aprovado', 'Agendado': 'agendamento', 'Reprovado': 'reprovado', 'Pendente de docs': 'pendente' };
    const tipo = tipoMap[c.status] || 'status';
    const msg = waMsgPaciente(c, tipo);
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'paciente', name: c.name, phone: c.phone, type: tipo, at: Date.now() });
    if (typeof WhatsApp.renderHistory === 'function') WhatsApp.renderHistory();
    UI.toast('WhatsApp aberto para ' + c.name + '!');
  };

}); /* fim DOMContentLoaded WhatsApp */


/* ══════════════════════════════════════════════════════════════
   ② OFÍCIO ABNT — modelo formal sem IMS
   Campos mínimos → IA completa os 3 parágrafos
══════════════════════════════════════════════════════════════ */

const OFICIO_ABNT = {

  /* Gera número sequencial 001/2026 */
  nextNum() {
    const yr  = new Date().getFullYear();
    const all = DB.getOficiosAll().filter(x => !x.isGuia && (x.num || '').endsWith('/' + yr));
    return String(all.length + 1).padStart(3, '0') + '/' + yr;
  },

  /* IA completa o corpo com base nos campos mínimos */
  gerarIA({ destNome, destCargo, destInst, assunto, obsLivre }) {
    const r    = DB.getResp();
    const mgr  = r.managerName || MANAGER_NAME;
    const role = r.managerRole || MANAGER_ROLE;
    const unit = r.unit        || SEC_NOME;
    const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

    /* Determina o verbo/objetivo pelo assunto */
    let objetivoP1 = 'solicitar/comunicar/encaminhar [INFORMAR]';
    const al = (assunto || '').toLowerCase();
    if (al.includes('encaminh'))  objetivoP1 = `encaminhar à apreciação de Vossa Senhoria o presente processo, para os fins que se fizerem necessários`;
    else if (al.includes('solic')) objetivoP1 = `solicitar a atenção e as providências cabíveis de Vossa Senhoria em relação ao assunto acima referenciado`;
    else if (al.includes('inform') || al.includes('comunic')) objetivoP1 = `comunicar a Vossa Senhoria as providências adotadas por esta Secretaria Municipal de Saúde no que tange ao assunto em referência`;
    else if (al.includes('esclar')) objetivoP1 = `prestar esclarecimentos a Vossa Senhoria acerca do assunto acima referenciado, na forma que segue`;
    else if (assunto) objetivoP1 = `tratar sobre o assunto "${assunto}", solicitando as providências que couberem à sua alçada`;

    const p2 = obsLivre
      ? obsLivre
      : `[INFORMAR — detalhes, prazos, fundamentação legal ou justificativa. Se houver Base Legal, cite aqui, ex: "Em conformidade com a Lei Municipal nº 2.399/2025..."].`;

    const p3 = `Coloco-me à disposição para quaisquer esclarecimentos adicionais que se fizerem necessários, podendo ser contatado pelo telefone ${PHONE_SEC} ou pelo e-mail ${SEC_EMAIL}.`;

    const sigla = 'APOIO SOCIAL';
    const num   = this.nextNum();
    const loc   = `${CIDADE}/${UF_SIGLA}, ${hoje}.`;

    return {
      num,
      texto:
`OFÍCIO Nº ${num} – ${sigla}

${loc}

Ao Senhor(a): ${destNome || '[NOME DO DESTINATÁRIO]'}
${destCargo || '[CARGO DO DESTINATÁRIO]'}
${destInst  || '[INSTITUIÇÃO]'}

Assunto: ${assunto || '[ASSUNTO]'}

Senhor(a) ${destCargo ? destCargo.split(/[\s,]+/)[destCargo.split(/[\s,]+/).length - 1] || destCargo : '[Cargo]'},

1. Ao cumprimentá-lo(a) cordialmente, venho por meio deste ${objetivoP1}.

2. ${p2}

3. ${p3}

Atenciosamente,

${mgr}
${role}
${unit}
${CIDADE}/${UF_SIGLA} · Tel.: ${PHONE_SEC}
${SEC_EMAIL}`,
    };
  },

  /* Página A4 do ofício para impressão */
  buildPaginaOficio(o, lh, r) {
    const hoje = o.date
      ? Utils.fDate(o.date)
      : new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    const mgr  = r.managerName || MANAGER_NAME;
    const role = r.managerRole || MANAGER_ROLE;
    const unit = r.unit        || SEC_NOME;

    /* Linhas do corpo com indentação de parágrafo */
    const bodyLines = (o.body || '').split('\n').map(l =>
      l.trim()
        ? `<div style="font-size:11.5pt;line-height:2;text-align:justify;text-indent:${/^\d+\./.test(l.trim()) ? '0' : '1.2cm'};margin:2px 0">${Utils.esc(l)}</div>`
        : '<div style="height:8px"></div>'
    ).join('');

    return `<div class="doc-a4">
      ${(typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh) : ''}
      <div class="doc-content">

        <div style="text-align:right;font-size:11pt;margin-bottom:6px;font-style:italic">
          ${CIDADE} – ${UF_SIGLA}, ${hoje}.
        </div>

        <div style="text-align:center;margin-bottom:3px">
          <span style="background:#1b5e20;color:#fff;font-size:8.5pt;padding:2px 12px;border-radius:2px;text-transform:uppercase;letter-spacing:1.5px">Ofício</span>
        </div>
        <div style="text-align:center;font-size:13pt;font-weight:bold;letter-spacing:.5px;margin-bottom:10px">
          OFÍCIO Nº ${Utils.esc(o.num || '—')}
        </div>

        ${o.dest ? `
        <div style="margin:10px 0 14px;font-size:11pt;line-height:1.7">
          <strong>Ao Senhor(a):</strong> ${Utils.esc(o.dest)}<br>
          ${o.destCargo ? Utils.esc(o.destCargo) + '<br>' : ''}
          ${o.destInst  ? Utils.esc(o.destInst)  + '<br>' : ''}
        </div>` : ''}

        ${o.subject ? `
        <div style="text-align:center;font-size:11.5pt;font-weight:bold;text-transform:uppercase;
                    border-top:1.5px solid #000;border-bottom:1.5px solid #000;
                    padding:5px 0;margin:10px 0 14px;letter-spacing:.3px">
          Assunto: ${Utils.esc(o.subject)}
        </div>` : ''}

        ${bodyLines}

        <div style="margin-top:16mm;text-align:center">
          <div style="display:inline-block;text-align:center;min-width:200px">
            <div style="height:44px;border-bottom:1px solid #000;margin-bottom:5px"></div>
            <div style="font-size:11.5pt;font-weight:bold">${Utils.esc(mgr)}</div>
            <div style="font-size:10pt;color:#333">${Utils.esc(role)}</div>
            <div style="font-size:10pt;color:#333">${Utils.esc(unit)}</div>
            <div style="font-size:10pt">Tel.: ${PHONE_SEC}</div>
          </div>
        </div>

      </div>
      ${(typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : ''}
    </div>`;
  },
};

/* ── Injeta overrides no módulo Oficios ── */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof Oficios === 'undefined') return;

  /* Override generateAI — só usa OficioABNT, ignora IMS */
  Oficios.generateAI = function() {
    const destNome  = document.getElementById('oficio-dest')?.value?.trim()       || '';
    const destCargo = document.getElementById('oficio-dest-cargo')?.value?.trim() || '';
    const destInst  = document.getElementById('oficio-dest-inst')?.value?.trim()  || '';
    const assunto   = document.getElementById('oficio-subject')?.value?.trim()    || '';
    const obsLivre  = document.getElementById('oficio-obs-p2')?.value?.trim()     || '';

    const { num, texto } = OFICIO_ABNT.gerarIA({ destNome, destCargo, destInst, assunto, obsLivre });

    /* Preenche número */
    const numEl = document.getElementById('oficio-num');
    if (numEl && !numEl.value) {
      numEl.value = num;
      const prev = document.getElementById('oficio-num-preview');
      if (prev) prev.textContent = 'Nº: ' + num;
    }

    /* Digita corpo com efeito IA */
    const body = document.getElementById('oficio-body');
    if (!body) return;
    body.value = '';
    let i = 0;
    const sp = Math.max(4, Math.min(12, 3000 / texto.length));
    const timer = setInterval(() => {
      body.value += texto[i++];
      body.scrollTop = body.scrollHeight;
      if (i >= texto.length) { clearInterval(timer); UI.toast('Ofício gerado com IA ✓'); }
    }, sp);
  };

  /* Override printPreview — usa OFICIO_ABNT.buildPaginaOficio */
  Oficios.printPreview = function() {
    const body     = document.getElementById('oficio-body')?.value?.trim();
    const dest     = document.getElementById('oficio-dest')?.value     || '';
    const destCargo= document.getElementById('oficio-dest-cargo')?.value || '';
    const destInst = document.getElementById('oficio-dest-inst')?.value  || '';
    const num      = document.getElementById('oficio-num')?.value       || '';
    const assunto  = document.getElementById('oficio-subject')?.value   || '';
    const date     = document.getElementById('oficio-date')?.value      || '';
    const local    = document.getElementById('oficio-local')?.value     || '';
    const procDate = document.getElementById('oficio-proc-date')?.value || '';
    const procTime = document.getElementById('oficio-proc-time')?.value || '';

    if (!body) { UI.toast('Gere ou preencha o corpo do ofício.', 'error'); return; }

    const lh = (typeof DB !== 'undefined') ? DB.getLH()  : {};
    const r  = (typeof DB !== 'undefined') ? DB.getResp() : {};
    const o  = { num, type:'oficio', dest, destCargo, destInst, subject:assunto, body, local, procDate, procTime, date };
    const html = OFICIO_ABNT.buildPaginaOficio(o, lh, r);
    const el = document.getElementById('print-preview-content');
    if (el) el.innerHTML = html;
    if (typeof UI !== 'undefined') UI.showModal('modal-print-preview');
  };

}); /* fim DOMContentLoaded Oficios */


/* ══════════════════════════════════════════════════════════════
   ③ IMS — IMPRESSÃO 3 PÁGINAS (override PrintMod.buildCompleteProcess)
══════════════════════════════════════════════════════════════ */

const IMS3Pages = {

  /* PÁGINA 1 — Capa */
  capa(c, lh, r) {
    const hoje = new Date().toLocaleDateString('pt-BR', { day:'2-digit', month:'long', year:'numeric' });
    const modalidade = /exam/i.test(c.procedure || '') ? 'EXAME' : 'CIRURGIA';
    const hdr = (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh) : '';
    const ftr = (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '';
    return `<div class="doc-a4">
      ${hdr}
      <div class="doc-content" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:215mm;text-align:center;padding:8mm 15mm">

        <div style="font-size:14pt;font-weight:bold;text-transform:uppercase;line-height:1.5;margin-bottom:10mm">
          PROCESSO ADMINISTRATIVO DE SOLICITAÇÃO<br>DE PROCEDIMENTO PELO PROJETO<br>ITAPAJÉ MAIS SAÚDE
        </div>

        <div style="font-size:11pt;margin-bottom:2mm">
          <strong>PROCESSO ADMINISTRATIVO Nº:</strong> <span style="font-family:monospace">${Utils.esc(c.solicitNum)}</span>
        </div>
        <div style="font-size:10.5pt;margin-bottom:8mm">
          <strong>MODALIDADE:</strong> ${modalidade} &nbsp;|&nbsp;
          <strong>Lei Municipal nº 2.399/2025</strong>
        </div>

        <div style="border:2px solid #2d7d32;width:85%;padding:7mm 10mm;background:#f9fff9;margin-bottom:8mm">
          <div style="font-size:10pt;text-decoration:underline;margin-bottom:4mm">
            ASSUNTO: Solicitação de Procedimento pelo Projeto Itapajé Mais Saúde
          </div>
          <div style="font-size:11pt;font-weight:bold;margin-bottom:4mm">DADOS DO BENEFICIÁRIO</div>
          <table style="width:100%;text-align:left;font-size:10.5pt;border-collapse:collapse">
            <tr><td style="font-weight:bold;padding:3px 0;width:42%">Nome:</td>
                <td>${Utils.esc(c.name)}</td></tr>
            <tr><td style="font-weight:bold;padding:3px 0">CPF:</td>
                <td>${Utils.esc(c.cpf || '[INFORMAR]')}</td></tr>
            <tr><td style="font-weight:bold;padding:3px 0">Procedimento:</td>
                <td>${Utils.esc(c.procedure || '[INFORMAR]')}</td></tr>
          </table>
        </div>

        <div style="font-size:10.5pt;font-style:italic">
          LOCAL E DATA: ${CIDADE}/${UF_SIGLA}, ${hoje}.
        </div>
      </div>
      ${ftr}
    </div>`;
  },

  /* PÁGINA 2 — Cadastro + Parecer Social */
  cadastroParecer(c, lh, r, reportText) {
    const hoje = new Date().toLocaleDateString('pt-BR', { day:'2-digit', month:'long', year:'numeric' });
    const hdr = (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh) : '';
    const ftr = (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '';
    const mgr  = r.managerName || MANAGER_NAME;
    const role = r.managerRole || MANAGER_ROLE;
    const unit = r.unit        || SEC_NOME;
    const social = r.socialName || '[INFORMAR]';
    const cress  = r.socialReg  || 'CRESS nº [INFORMAR]';

    const parecerTexto = reportText ||
      `Após entrevista e análise documental realizadas em ${hoje}, constatou-se que o(a) paciente ` +
      `${c.name} reside no Município de ${CIDADE}/${UF_SIGLA}` +
      (c.address ? `, em ${c.address}, ${c.neighborhood}` : '') +
      `, e apresenta situação de vulnerabilidade socioeconômica` +
      (c.income ? `, com renda familiar de R$ ${c.income} (${c.incomeRange || '—'})` : '') +
      `, que o(a) torna elegível aos benefícios da Lei Municipal nº 2.399/2025 e do Decreto nº 49/2025.` +
      (c.regulation ? `\n\n${c.regulation}` : '');

    const row = (l, v) => v
      ? `<tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 7px;border:.5px solid #ccc;width:38%;white-space:nowrap">${l}</td><td style="padding:4px 7px;border:.5px solid #ccc">${Utils.esc(v)}</td></tr>`
      : '';

    return `<div class="doc-a4">
      ${hdr}
      <div class="doc-content">
        <div style="text-align:center;font-size:13pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:5px;margin-bottom:8px">
          Cadastro de Atendimento e Parecer Social
        </div>
        <div style="background:#e8f5e9;border:1px solid #2d7d32;padding:5px 10px;font-size:10.5pt;margin-bottom:8px;border-radius:3px">
          <strong>Nº:</strong> ${Utils.esc(c.solicitNum)} &nbsp;·&nbsp;
          <strong>Data:</strong> ${Utils.fDate(c.date)} &nbsp;·&nbsp;
          <strong>Procedimento:</strong> ${Utils.esc((c.procedure || '').toUpperCase())}
        </div>
        <div style="font-size:10pt;margin-bottom:7px;text-align:justify">
          <strong>OBJETIVO:</strong> Subsidiar tecnicamente a análise da solicitação de procedimento pelo Programa Itapajé Mais Saúde.
        </div>

        <div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:3px 8px;margin:5px 0 4px;text-transform:uppercase;border-left:4px solid #2d7d32">
          1. PERFIL SOCIOECONÔMICO
        </div>
        <table style="width:100%;border-collapse:collapse;margin-bottom:6px;font-size:10.5pt">
          ${row('Nome completo', c.name)}
          ${row('Nascimento', Utils.fDate(c.birth) + ' (' + Utils.age(c.birth) + ')')}
          ${row('Endereço', (c.address || '[INFORMAR]') + ', ' + (c.neighborhood || '') + ', ' + CIDADE + '/' + UF_SIGLA)}
          ${c.reference ? row('Ponto de referência', c.reference) : ''}
          ${row('Renda Familiar', 'R$ ' + (c.income || '[INFORMAR]') + ' — ' + (c.incomeRange || ''))}
          ${row('Situação Habitacional', (c.housing || '[INFORMAR]') + (c.services ? ' · ' + c.services : ''))}
          ${row('Composição Familiar / Mãe', (c.mother || '[INFORMAR]') + (c.motherProf ? ' — ' + c.motherProf : ''))}
          ${row('CPF', c.cpf || '[INFORMAR]')}
          ${row('Telefone', c.phone)}
          ${row('Profissão', c.profession || '[INFORMAR]')}
          ${row('Escolaridade', c.education || '[INFORMAR]')}
        </table>

        <div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:3px 8px;margin:6px 0 4px;text-transform:uppercase;border-left:4px solid #2d7d32">
          2. PARECER TÉCNICO
        </div>
        <div style="font-size:10.5pt;line-height:1.85;text-align:justify;margin:4px 0 6px;text-indent:1.2cm">
          ${Utils.esc(parecerTexto).replace(/\n/g, '</div><div style="font-size:10.5pt;line-height:1.85;text-align:justify;margin:4px 0;text-indent:1.2cm">')}
        </div>

        <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:6px 12px;font-size:11pt;font-weight:bold;text-align:center;margin:8px 0">
          CONCLUSÃO: O Serviço Social manifesta parecer FAVORÁVEL à inclusão no programa.
        </div>

        <div style="text-align:right;font-size:10.5pt;margin:8px 0 10px;font-style:italic">
          ${CIDADE} – ${UF_SIGLA}, ${hoje}.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:28px;margin-top:10mm">
          <div style="text-align:center">
            <div style="height:40px;border-bottom:1px solid #000;margin-bottom:4px"></div>
            <div style="font-size:10.5pt;font-weight:bold">${Utils.esc(social)}</div>
            <div style="font-size:9.5pt;color:#333">${Utils.esc(cress)}</div>
          </div>
          <div style="text-align:center">
            <div style="height:40px;border-bottom:1px solid #000;margin-bottom:4px"></div>
            <div style="font-size:10.5pt;font-weight:bold">${Utils.esc(mgr)}</div>
            <div style="font-size:9.5pt;color:#333">${Utils.esc(role)}<br>${Utils.esc(unit)}</div>
          </div>
        </div>
      </div>
      ${ftr}
    </div>`;
  },

  /* PÁGINA 3 — Guia de Autorização + Agendamento */
  autorizacaoAgendamento(c, lh, r) {
    const hoje = new Date().toLocaleDateString('pt-BR', { day:'2-digit', month:'long', year:'numeric' });
    const hdr = (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh) : '';
    const ftr = (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '';
    const mgr  = r.managerName || MANAGER_NAME;
    const role = r.managerRole || MANAGER_ROLE;
    const unit = r.unit        || SEC_NOME;
    const hasAgend = !!c.scheduledDate;

    return `<div class="doc-a4">
      ${hdr}
      <div class="doc-content">
        <div style="text-align:center;font-size:13pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:5px;margin-bottom:8px">
          Guia de Autorização e Agendamento
        </div>

        <div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:3px 8px;margin:5px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32">
          AUTORIZAÇÃO DE PROCEDIMENTO
        </div>
        <div style="font-size:10.5pt;line-height:1.85;text-align:justify;margin:4px 0 8px;text-indent:1.2cm">
          Em conformidade com a Lei Municipal nº 2.399, de 15 de abril de 2025, e com o Decreto nº 49,
          de 30 de maio de 2025, fica <strong>AUTORIZADA</strong> a realização do procedimento abaixo
          descrito pelo Programa Itapajé Mais Saúde:
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:8px;font-size:10.5pt">
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc;width:38%">Paciente</td>
              <td style="padding:4px 8px;border:.5px solid #ccc"><strong>${Utils.esc(c.name)}</strong></td></tr>
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">CPF</td>
              <td style="padding:4px 8px;border:.5px solid #ccc">${Utils.esc(c.cpf || '[INFORMAR]')}</td></tr>
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">Nº Solicitação</td>
              <td style="padding:4px 8px;border:.5px solid #ccc;font-family:monospace">${Utils.esc(c.solicitNum)}</td></tr>
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">Procedimento</td>
              <td style="padding:4px 8px;border:.5px solid #ccc"><strong>${Utils.esc((c.procedure || '[INFORMAR]').toUpperCase())}</strong></td></tr>
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">Local de Realização</td>
              <td style="padding:4px 8px;border:.5px solid #ccc">${Utils.esc(c.hospital || '[INFORMAR]')}</td></tr>
          ${c.hospitalAddress ? `<tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">Endereço do Local</td>
              <td style="padding:4px 8px;border:.5px solid #ccc">${Utils.esc(c.hospitalAddress)}</td></tr>` : ''}
          <tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc">Data Prevista</td>
              <td style="padding:4px 8px;border:.5px solid #ccc">
                ${hasAgend ? Utils.fDate(c.scheduledDate) : '[INFORMAR]'}
                ${c.scheduledTime ? ' &nbsp;|&nbsp; <strong>Horário:</strong> ' + c.scheduledTime : ' | Horário: [INFORMAR]'}
              </td></tr>
        </table>

        <div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:3px 8px;margin:8px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32">
          ORIENTAÇÕES AO PACIENTE
        </div>
        <div style="font-size:10.5pt;line-height:1.9;padding:0 4px;margin-bottom:8px">
          1. Comparecer com <strong>30 (trinta) minutos</strong> de antecedência ao local indicado.<br>
          2. Levar <strong>documento de identidade original</strong> (RG ou CNH) e <strong>CPF</strong>.<br>
          3. Apresentar <strong>esta guia de autorização</strong> devidamente assinada.<br>
          4. Em caso de impossibilidade, contatar previamente: <strong>${PHONE_SEC}</strong>.
        </div>

        <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:6px 12px;font-size:10.5pt;text-align:center;margin:8px 0">
          <strong>${SEC_NOME}</strong><br>
          Tel.: <strong>${PHONE_SEC}</strong> &nbsp;·&nbsp; ${SEC_EMAIL}<br>
          ${SEC_END} &nbsp;·&nbsp; ${CEP_SEC}
        </div>

        <div style="text-align:right;font-size:10.5pt;margin:8px 0 10px;font-style:italic">
          ${CIDADE} – ${UF_SIGLA}, ${hoje}.
        </div>

        <div style="text-align:center;margin-top:10mm">
          <div style="display:inline-block;min-width:210px">
            <div style="height:42px;border-bottom:1px solid #000;margin-bottom:4px"></div>
            <div style="font-size:11pt;font-weight:bold">${Utils.esc(mgr)}</div>
            <div style="font-size:10pt;color:#333">${Utils.esc(role)}</div>
            <div style="font-size:10pt;color:#333">${Utils.esc(unit)}</div>
            <div style="font-size:10pt">Tel.: ${PHONE_SEC}</div>
          </div>
        </div>

      </div>
      ${ftr}
    </div>`;
  },

  /* Monta as 3 páginas completas */
  buildAll(id) {
    const c = DB.getIMSCase(id);
    if (!c) return '';
    const lh = DB.getLH();
    const r  = DB.getResp();
    const reports = DB.getReports().filter(x => x.imsId === id);
    const reportText = reports.length > 0 ? reports[0].text : null;
    return this.capa(c, lh, r)
         + this.cadastroParecer(c, lh, r, reportText)
         + this.autorizacaoAgendamento(c, lh, r);
  },
};

/* ── Injeta override no PrintMod ── */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof PrintMod !== 'undefined') {
    PrintMod.buildCompleteProcess = id => IMS3Pages.buildAll(id);
  }
  if (typeof Print !== 'undefined') {
    Print.printIMS = id => {
      const html = IMS3Pages.buildAll(id);
      if (typeof PrintMod !== 'undefined') PrintMod._printWin(html, 'Processo IMS — ' + (DB.getIMSCase(id)?.name || ''));
    };
  }
});

/* ── Popula select de pacientes gerais no Relatório Social ── */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof Relatorio === 'undefined') return;

  const _origInit = (typeof Relatorio.init === 'function') ? Relatorio.init.bind(Relatorio) : () => {};
  Relatorio.init = function() {
    _origInit();
    const sel = document.getElementById('rel-patient-select');
    if (!sel) return;
    const pts = DB.getPatients().sort((a, b) => a.name.localeCompare(b.name));
    sel.innerHTML = '<option value="">— Paciente Geral —</option>' +
      pts.map(p => `<option value="pat:${p.id}">${Utils.esc(p.name)}</option>`).join('');
  };

  /* Override save — vincula ao IMS ou ao paciente geral */
  Relatorio.save = function() {
    if (!this._lastReport) { UI.toast('Gere um relatório primeiro.', 'error'); return; }
    /* IMS */
    if (this._imsCase) {
      DB.addReport({ id: Utils.uid(), imsId: this._imsCase.id, patientId: null, patientName: this._imsCase.name, text: this._lastReport, at: Date.now() });
      UI.toast('Relatório salvo para ' + this._imsCase.name + '!');
      return;
    }
    /* Paciente geral */
    const sel = document.getElementById('rel-patient-select');
    if (sel && sel.value) {
      const [, pid] = sel.value.split(':');
      const pt = DB.getPatient(pid);
      if (pt) {
        DB.addReport({ id: Utils.uid(), imsId: null, patientId: pid, patientName: pt.name, text: this._lastReport, at: Date.now() });
        UI.toast('Relatório salvo para ' + pt.name + '!');
        return;
      }
    }
    UI.toast('Selecione um caso IMS ou paciente geral antes de salvar.', 'error');
  };
});

console.log('SAS v4.2 — Patches carregados ✓ Tel: ' + PHONE_SEC);
/* ═══════════════════════════════════════════════════════════════
   SAS v4.2 — PATCH DEFINITIVO
   WhatsApp completo · Ofício ABNT puro · IMS 3 páginas · Relatório geral
   Tel.: (85) 9 9126-4880 · Francisco Maílson de Sousa Moreira
   ═══════════════════════════════════════════════════════════════ */

const _PHONE   = '(85) 9 9126-4880';
const _GERENTE = 'Francisco Maílson de Sousa Moreira';
const _CARGO   = 'Gerente de Apoio Social';
const _SECR    = 'Secretaria Municipal de Saúde';
const _MUNIC   = 'Itapajé';
const _UF      = 'CE';
const _END_SEC = 'R. São Francisco, Nº 225 – Centro, Itapajé/CE';
const _CEP     = 'CEP: 62.600-000';
const _EMAIL   = 'saude@itapaje.ce.gov.br';
const _SITE    = 'www.itapaje.ce.gov.br';

function _hoje()  { return new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'}); }
function _hojeS() { return new Date().toLocaleDateString('pt-BR'); }
function _esc(s)  { return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'):''; }
function _fd(s)   { if(!s)return '[INFORMAR]'; const[y,m,d]=s.split('-'); return `${d}/${m}/${y}`; }
function _age(b)  {
  if(!b)return '';
  const t=new Date(),x=new Date(b);
  let a=t.getFullYear()-x.getFullYear();
  if(t.getMonth()-x.getMonth()<0||(t.getMonth()===x.getMonth()&&t.getDate()<x.getDate()))a--;
  return a+' anos';
}

/* ══ WHATSAPP ══ */
const WA = {
  _rod() { return `\n\n📞 ${_PHONE}\n👤 ${_CARGO}\n*${_GERENTE}*\n${_SECR} — ${_MUNIC}/${_UF}\n_${_hojeS()}_`; },

  msgPaciente(item, tipo) {
    const isIMS = !!item.solicitNum;
    const prog  = isIMS ? 'Programa *Itapajé Mais Saúde*' : `*${_SECR}*`;
    const rod   = this._rod();
    const lp = item.procedure||item.obs||'';
    const ln = item.solicitNum||'';
    const ld = item.scheduledDate ? `\n📅 *Data:* ${_fd(item.scheduledDate)}${item.scheduledTime?' às '+item.scheduledTime:''}` : '';
    const lh = item.hospital        ? `\n🏨 *Local:* ${item.hospital}`          : '';
    const le = item.hospitalAddress ? `\n📍 ${item.hospitalAddress}`             : '';
    const msgs = {
      status:      `Olá, *${item.name}*! 👋\n\nInformamos que seu processo junto ao ${prog} foi atualizado.\n\n📋 *Status:* ${item.status}${ln?'\n🔢 *Nº:* '+ln:''}${lp?'\n🏥 *Procedimento:* '+lp:''}\n\nEm caso de dúvidas, entre em contato conosco.`+rod,
      aprovado:    `✅ *${item.name}*, seu processo foi *APROVADO*!\n\n🎉 ${prog} informa que sua solicitação foi aprovada.${lp?'\n🏥 *Procedimento:* '+lp:''}${ln?'\n🔢 *Nº:* '+ln:''}${ld}${lh}${le}\n\n📌 *Orientações:*\n• Comparecer 30 min antes\n• Levar RG original e CPF\n• Apresentar este comprovante\n\nEm caso de dúvidas, entre em contato conosco.`+rod,
      pendente:    `⚠️ *${item.name}*, seu processo está com *DOCUMENTAÇÃO PENDENTE*.\n\n${ln?'🔢 *Nº:* '+ln+'\n':''}Por favor, compareça à ${_SECR} para regularizar.\n\n📍 *${_END_SEC}*\n\nEm caso de dúvidas, entre em contato conosco.`+rod,
      agendamento: `📅 *${item.name}*, seu procedimento foi *AGENDADO*!\n\n${lp?'🏥 *Procedimento:* '+lp:''}${ld}${lh}${le}\n\n📌 *Lembre-se:*\n• Chegar 30 min antes\n• Trazer RG original e CPF\n• Apresentar este comprovante\n\nEm caso de dúvidas, entre em contato conosco.`+rod,
      reprovado:   `❌ *${item.name}*, seu processo *não foi aprovado* neste momento.\n\n${ln?'🔢 *Nº:* '+ln+'\n\n':''}Por favor, compareça à ${_SECR} para informações sobre alternativas.\n\n📍 *${_END_SEC}*\n\nEm caso de dúvidas, entre em contato conosco.`+rod,
      custom:      document.getElementById('wa-custom-msg')?.value||'',
    };
    return msgs[tipo]||msgs.status;
  },

  _blocoIMS(c, visitDate, parecer) {
    const e = [
      [c.eligResident,'Residente em Itapajé/CE'],[c.eligIncome,'Renda ≤ 2 salários'],
      [c.eligFila,'Fila SUS sem previsão'],[c.eligIndicacao,'Indicação médica'],[c.eligDocs,'Documentação completa'],
    ].map(([v,l])=>`${v?'✅':'❌'} ${l}`).join('\n');
    return '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📋 DADOS DO PACIENTE*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n👤 *Nome:* ${c.name}`+
      `\n🗓 *Nascimento:* ${_fd(c.birth)} (${_age(c.birth)})`+
      `\n🪪 *CPF:* ${c.cpf||'[INFORMAR]'}`+
      `\n📞 *Telefone:* ${c.phone}`+
      `\n🏠 *Endereço:* ${c.address||'—'}, ${c.neighborhood||'—'}, ${_MUNIC}/${_UF}`+
      `\n💰 *Renda:* R$ ${c.income||'—'} (${c.incomeRange||'—'})`+
      `\n🏡 *Habitação:* ${c.housing||'—'}${c.services?' · '+c.services:''}`+
      `\n👩 *Mãe:* ${c.mother||'—'}${c.motherProf?' ('+c.motherProf+')':''}`+
      `\n👔 *Profissão:* ${c.profession||'—'}`+
      '\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*🏥 DADOS DO PROCESSO IMS*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n🔢 *Nº Solicitação:* ${c.solicitNum}`+
      `\n📅 *Data do Pedido:* ${_fd(c.date)}`+
      `\n📅 *Data Visita Social:* ${visitDate?_fd(visitDate):'[INFORMAR]'}`+
      `\n🔬 *Procedimento:* ${c.procedure||'—'}`+
      `\n🏨 *Hospital:* ${c.hospital||'[INFORMAR]'}`+
      (c.scheduledDate?`\n📆 *Agendado:* ${_fd(c.scheduledDate)}${c.scheduledTime?' às '+c.scheduledTime:''}`:'') +
      '\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📡 SISREG — REGULAÇÃO*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n${c.regulation||'Paciente em fila de espera no SISREG sem previsão de atendimento pelo SUS.'}` +
      '\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📝 PARECER TÉCNICO*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n${parecer||'Paciente preenche os critérios da Lei nº 2.399/2025. Parecer FAVORÁVEL ao Programa Itapajé Mais Saúde.'}` +
      `\n\n*Elegibilidade:*\n${e}`;
  },

  _blocoGeral(p, visitDate, parecer) {
    return '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📋 DADOS DO PACIENTE*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n👤 *Nome:* ${p.name}`+
      `\n🗓 *Nascimento:* ${_fd(p.birth)} (${_age(p.birth)})`+
      `\n🪪 *CPF:* ${p.cpf||'[INFORMAR]'}`+
      `\n📞 *Telefone:* ${p.phone}`+
      `\n🏠 *Endereço:* ${(p.street||'—')+(p.number?', '+p.number:'')+', '+(p.neighborhood||'—')+', '+_MUNIC+'/'+_UF}`+
      `\n💰 *Situação financeira:* ${p.financial||'—'}`+
      `\n🎁 *Benefícios:* ${p.benefits||'Nenhum'}`+
      `\n👩 *Mãe:* ${p.mother||'—'}`+
      (p.obs?`\n📝 *Obs.:* ${p.obs}`:'')+
      '\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📊 STATUS DO ATENDIMENTO*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n📋 *Status:* ${p.status}`+
      `\n📅 *Data Visita Social:* ${visitDate?_fd(visitDate):'[INFORMAR]'}`+
      '\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      '\n*📝 PARECER TÉCNICO*'+
      '\n*━━━━━━━━━━━━━━━━━━━━━━━━*'+
      `\n${parecer||'Paciente atendido pelo Serviço Social. Aguarda decisão do gabinete.'}`;
  },

  msgGabinete(item, tipo, parecer, visitDate) {
    const r    = (typeof DB!=='undefined') ? DB.getResp() : {};
    const unit = r.unit||_SECR;
    const isIMS = !!item.solicitNum;
    const bloco = isIMS ? this._blocoIMS(item,visitDate,parecer) : this._blocoGeral(item,visitDate,parecer);
    const cab   = `*🏥 ${unit.toUpperCase()} — ${_MUNIC}/${_UF}*\n_${_hoje()}_\n\n`;
    const rodape = `\n\n_${_GERENTE}_\n_${_CARGO}_\n_Tel.: ${_PHONE}_`;
    const decBtn = `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━*\n✅ *[APROVAR]* — Responda: APROVADO\n❌ *[REPROVAR]* — Responda: REPROVADO\n*━━━━━━━━━━━━━━━━━━━━━━━━*`;
    if(tipo==='solicitacao_total') {
      const label = isIMS ? '*━━ SOLICITAÇÃO TOTAL — PROGRAMA IMS ━━*' : '*━━ SOLICITAÇÃO TOTAL — ATEND. GERAL ━━*';
      return cab+label+'\n*⚠️ Aguarda APROVAÇÃO ou REPROVAÇÃO*\n'+bloco+decBtn+rodape;
    }
    const labels = { parecer:'*📋 ENCAMINHAMENTO DE PARECER SOCIAL*', urgente:'*🚨 CASO URGENTE*', relatorio:'*📊 RELATÓRIO COMPLETO*' };
    return cab+(labels[tipo]||labels.parecer)+'\n'+bloco+rodape;
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if(typeof WhatsApp==='undefined') return;
  WhatsApp._buildPatientMsg  = (item,tipo)             => WA.msgPaciente(item,tipo);
  WhatsApp._buildGabineteMsg = (item,tipo,par,vis)      => WA.msgGabinete(item,tipo,par,vis);
  WhatsApp.notifyFromIMS = function(id) {
    const c=DB.getIMSCase(id); if(!c)return;
    const phone=Utils.cleanPhone(c.phone); if(!phone){UI.toast('Sem telefone.','error');return;}
    const map={'Aprovado':'aprovado','Agendado':'agendamento','Reprovado':'reprovado','Pendente de docs':'pendente'};
    const msg=WA.msgPaciente(c,map[c.status]||'status');
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'paciente',name:c.name,phone:c.phone,type:map[c.status]||'status',at:Date.now()});
    WhatsApp.renderHistory?.(); UI.toast('WhatsApp aberto para '+c.name);
  };
  WhatsApp.notifyPatientStatus = function() {
    const item=(typeof StatusMod!=='undefined')?StatusMod.currentItem?.():null;
    if(!item){UI.toast('Selecione um paciente na aba Status.','error');return;}
    const phone=Utils.cleanPhone(item.phone); if(!phone){UI.toast('Sem telefone.','error');return;}
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(WA.msgPaciente(item,'status'))}`,'_blank');
    DB.addWAHist({id:Utils.uid(),to:'paciente',name:item.name,phone:item.phone,type:'status',at:Date.now()});
    WhatsApp.renderHistory?.(); UI.toast('WhatsApp aberto!');
  };
});

/* ══ OFÍCIO ABNT PURO (sem IMS) ══ */
const OficioABNT = {
  nextNum() {
    if(typeof DB==='undefined')return'001';
    const ano=new Date().getFullYear();
    return String(DB.getOficiosAll().filter(x=>!x.isGuia&&x.num&&x.num.includes('/'+ano)).length+1).padStart(3,'0');
  },
  gerarIA({destNome,destCargo,destInst,assunto,detalhes,fecho,numOficio}) {
    const r=(typeof DB!=='undefined')?DB.getResp():{};
    const mgr=r.managerName||_GERENTE, cargo=r.managerRole||_CARGO, unit=r.unit||_SECR;
    const num=numOficio||this.nextNum(), ano=new Date().getFullYear();
    const al=(assunto||'').toLowerCase();
    let verbo='solicitar';
    if(al.includes('encaminh'))verbo='encaminhar';
    else if(al.includes('comunic')||al.includes('inform'))verbo='comunicar';
    else if(al.includes('convocar'))verbo='convocar';
    else if(al.includes('notific'))verbo='notificar';
    const p1=`Ao cumprimentá-lo(a) cordialmente, venho por meio deste ${verbo}, em nome da ${unit} do Município de ${_MUNIC}/${_UF}, ${assunto?assunto.toLowerCase():'[INFORMAR O OBJETIVO PRINCIPAL DO OFÍCIO]'}.`;
    const p2=detalhes||`Ressaltamos que esta solicitação fundamenta-se nas atribuições desta ${unit} e visa garantir a continuidade e qualidade dos serviços prestados à população do Município de ${_MUNIC}/${_UF}, em conformidade com as normas vigentes e os princípios da administração pública.`;
    const p3=`Coloco-me à disposição de Vossa Senhoria para quaisquer esclarecimentos, podendo ser contatado pelo telefone ${_PHONE} ou pelo e-mail ${_EMAIL}.`;
    return `OFÍCIO Nº ${num}/${ano} – APOIO SOCIAL\n\n`+
      `${_MUNIC}/${_UF}, ${_hoje()}.\n\n`+
      `Ao Senhor(a): ${destNome||'[Nome do Destinatário]'}\n`+
      `${destCargo||'[Cargo do Destinatário]'}\n`+
      `${destInst||'[Instituição]'}\n\n`+
      `Assunto: ${assunto||'[Assunto]'}\n\n`+
      `Senhor(a) ${destCargo?(destCargo.split(' ').slice(-1)[0]||'[Cargo]'):'[Cargo]'},\n\n`+
      `1. ${p1}\n\n2. ${p2}\n\n3. ${p3}\n\n`+
      `${fecho||'Atenciosamente'},\n\n\n${mgr}\n${cargo}\n${unit}\n`+
      `${_MUNIC}/${_UF} — Tel.: ${_PHONE}\n${_EMAIL}`;
  },
  buildPage(dados,lh,r) {
    const {num,body,dest,destCargo,assunto,date,local,procDate,procTime}=dados;
    const mgr=r.managerName||_GERENTE,cargo=r.managerRole||_CARGO,unit=r.unit||_SECR;
    const hdr=(typeof PrintMod!=='undefined')?PrintMod._buildHeader(lh):'';
    const ftr=(typeof PrintMod!=='undefined')?PrintMod._buildFooter(lh,r):'';
    const hoje=date?_fd(date):_hoje();
    return `<div class="doc-a4">${hdr}
      <div class="doc-content">
        <div style="text-align:right;font-size:10.5pt;font-style:italic;margin-bottom:8px">${_MUNIC} – ${_UF}, ${hoje}.</div>
        <div style="text-align:center;margin-bottom:3px"><span style="background:#1b5e20;color:#fff;font-size:9pt;padding:2px 10px;border-radius:3px;text-transform:uppercase;letter-spacing:1px">Ofício</span></div>
        <div style="text-align:center;font-size:12pt;font-weight:bold;margin:5px 0 12px;letter-spacing:.5px">${_esc(num||'Nº —')}</div>
        ${dest?`<div style="margin:0 0 14px;font-size:11pt;line-height:1.7"><strong>Ao Senhor(a):</strong> ${_esc(dest)}<br>${destCargo?_esc(destCargo):''}</div>`:''}
        ${assunto?`<div style="text-align:center;font-size:11.5pt;font-weight:bold;text-transform:uppercase;border-bottom:1.5px solid #000;padding-bottom:6px;margin:0 0 14px">${_esc(assunto)}</div>`:''}
        <div style="font-size:11pt;line-height:1.9;text-align:justify;white-space:pre-wrap">${_esc(body||'')}</div>
        ${local||procDate?`<div style="margin:14px 0;font-size:10.5pt;border:1px solid #ccc;padding:8px 12px;border-radius:4px">${procDate?'<strong>Data:</strong> '+_fd(procDate)+(procTime?' às '+procTime:'')+'<br>':''}${local?'<strong>Local:</strong> '+_esc(local):''}</div>`:''}
        <div style="text-align:center;margin-top:14mm"><div style="display:inline-block;text-align:center;min-width:220px">
          <div style="height:40px;border-bottom:1px solid #000;margin-bottom:5px"></div>
          <div style="font-size:11pt;font-weight:bold">${_esc(mgr)}</div>
          <div style="font-size:9.5pt;color:#333">${_esc(cargo)}</div>
          <div style="font-size:9.5pt;color:#333">${_esc(unit)}</div>
          <div style="font-size:9.5pt">Tel.: ${_PHONE}</div>
        </div></div>
      </div>${ftr}</div>`;
  },
};

document.addEventListener('DOMContentLoaded', ()=>{
  if(typeof Oficios==='undefined')return;
  const imsGrp=document.getElementById('oficio-ims-ref')?.closest('.form-group');
  if(imsGrp)imsGrp.style.display='none';
  Oficios.generateAI=function(){
    const numEl=document.getElementById('oficio-num');
    if(numEl&&!numEl.value){ const n=OficioABNT.nextNum()+'/'+new Date().getFullYear(); numEl.value=n; const p=document.getElementById('oficio-num-preview'); if(p)p.textContent='Nº: '+n; }
    const text=OficioABNT.gerarIA({numOficio:document.getElementById('oficio-num')?.value?.split('/')[0]||'',destNome:document.getElementById('oficio-dest')?.value?.trim()||'',destCargo:document.getElementById('oficio-dest-cargo')?.value?.trim()||'',destInst:'',assunto:document.getElementById('oficio-subject')?.value?.trim()||'',detalhes:'',fecho:document.getElementById('oficio-fecho')?.value||'Atenciosamente'});
    const body=document.getElementById('oficio-body'); if(!body)return;
    body.value=''; let i=0; const sp=Math.max(5,Math.min(15,3000/text.length));
    const t=setInterval(()=>{body.value+=text[i++];body.scrollTop=body.scrollHeight;if(i>=text.length){clearInterval(t);UI.toast('Ofício gerado ✓');}},sp);
  };
  Oficios.autoFillFromIMS=function(){};
  Oficios.printPreview=function(){
    const body=document.getElementById('oficio-body')?.value?.trim(); if(!body){UI.toast('Gere o corpo primeiro.','error');return;}
    const lh=DB.getLH(),r=DB.getResp();
    document.getElementById('print-preview-content').innerHTML=OficioABNT.buildPage({num:document.getElementById('oficio-num')?.value||'',body,dest:document.getElementById('oficio-dest')?.value||'',destCargo:document.getElementById('oficio-dest-cargo')?.value||'',assunto:document.getElementById('oficio-subject')?.value||'',date:document.getElementById('oficio-date')?.value||'',local:document.getElementById('oficio-local')?.value||'',procDate:document.getElementById('oficio-proc-date')?.value||'',procTime:document.getElementById('oficio-proc-time')?.value||''},lh,r);
    UI.showModal('modal-print-preview');
  };
});

/* ══ IMS — 3 PÁGINAS PADRONIZADAS ══ */
const IMSPrint3P={
  _h(lh){return(typeof PrintMod!=='undefined')?PrintMod._buildHeader(lh):''},
  _f(lh,r){return(typeof PrintMod!=='undefined')?PrintMod._buildFooter(lh,r):''},
  _row(l,v){if(!v)return'';return`<tr><td style="font-weight:bold;background:#f5f5f5;padding:4px 7px;border:.5px solid #ccc;width:38%;vertical-align:top">${l}</td><td style="padding:4px 7px;border:.5px solid #ccc;vertical-align:top">${_esc(v)}</td></tr>`;},
  _sec(t){return`<div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:4px 8px;margin:8px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32">${t}</div>`;},
  _s2(r){const m=r.managerName||_GERENTE,mc=r.managerRole||_CARGO,s=r.socialName||'_________________________',sc=r.socialReg||'Assistente Social',u=r.unit||_SECR;return`<div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;margin-top:12mm"><div style="text-align:center"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:4px"></div><div style="font-size:10.5pt;font-weight:bold">${_esc(s)}</div><div style="font-size:9.5pt;color:#333">${_esc(sc)}</div></div><div style="text-align:center"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:4px"></div><div style="font-size:10.5pt;font-weight:bold">${_esc(m)}</div><div style="font-size:9.5pt;color:#333">${_esc(mc)}</div><div style="font-size:9.5pt;color:#333">${_esc(u)}</div><div style="font-size:9.5pt">Tel.: ${_PHONE}</div></div></div>`;},
  _s1(r){const m=r.managerName||_GERENTE,mc=r.managerRole||_CARGO,u=r.unit||_SECR;return`<div style="text-align:center;margin-top:12mm"><div style="display:inline-block;min-width:230px;text-align:center"><div style="height:36px;border-bottom:1px solid #000;margin-bottom:4px"></div><div style="font-size:11pt;font-weight:bold">${_esc(m)}</div><div style="font-size:9.5pt;color:#333">${_esc(mc)}</div><div style="font-size:9.5pt;color:#333">${_esc(u)}</div><div style="font-size:9.5pt">Tel.: ${_PHONE}</div></div></div>`;},

  pag1(c,lh,r){
    const mod=(c.procedure||'').toLowerCase().includes('exam')?'EXAME':'CIRURGIA';
    return`<div class="doc-a4">${this._h(lh)}<div class="doc-content" style="display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:10mm">
      <div style="font-size:13pt;font-weight:bold;text-transform:uppercase;line-height:1.5;margin-bottom:8mm">PROCESSO ADMINISTRATIVO DE SOLICITAÇÃO<br>DE PROCEDIMENTO PELO PROJETO<br>ITAPAJÉ MAIS SAÚDE</div>
      <div style="font-size:11pt;font-weight:bold;margin-bottom:2mm">PROCESSO ADMINISTRATIVO Nº: <span style="font-family:monospace">${_esc(c.solicitNum)}</span></div>
      <div style="font-size:10.5pt;margin-bottom:8mm">MODALIDADE: ${mod} &nbsp;|&nbsp; Lei Municipal nº 2.399/2025</div>
      <div style="border:2px solid #2d7d32;padding:8mm 14mm;background:#f9fff9;width:90%;margin-bottom:8mm">
        <div style="font-size:10.5pt;margin-bottom:4mm">ASSUNTO: Solicitação de Procedimento pelo Projeto Itapajé Mais Saúde</div>
        <div style="font-size:11.5pt;font-weight:bold;margin-bottom:5mm">DADOS DO BENEFICIÁRIO</div>
        <table style="width:100%;font-size:10.5pt;text-align:left;border-collapse:collapse">
          <tr><td style="font-weight:bold;padding:3px 0;width:40%">Nome:</td><td>${_esc(c.name)}</td></tr>
          <tr><td style="font-weight:bold;padding:3px 0">CPF:</td><td>${_esc(c.cpf||'[INFORMAR]')}</td></tr>
          <tr><td style="font-weight:bold;padding:3px 0">Procedimento solicitado:</td><td>${_esc(c.procedure||'[INFORMAR]')}</td></tr>
        </table>
      </div>
      <div style="font-size:10.5pt;font-style:italic">LOCAL E DATA: ${_MUNIC}/${_UF}, ${_hoje()}.</div>
    </div>${this._f(lh,r)}</div>`;
  },

  pag2(c,lh,r,rptText){
    const par=rptText||`Após entrevista e análise documental realizada pelo Serviço Social desta ${r.unit||_SECR}, constatou-se que o(a) paciente ${c.name} reside no Município de ${_MUNIC}/${_UF}${c.address?', em '+c.address+', '+c.neighborhood:''}, e apresenta situação de vulnerabilidade socioeconômica${c.income?', com renda familiar de R$ '+c.income+' ('+c.incomeRange+')':''}, que o(a) torna elegível aos benefícios da Lei Municipal nº 2.399/2025 e do Decreto nº 49/2025.`;
    const reg=c.regulation||`O(A) paciente encontra-se em fila de espera no Sistema de Regulação do Estado do Ceará (SISREG), sem previsão de agendamento pelo SUS, sendo encaminhado(a) pelo médico assistente para realização de procedimento especializado em Hospital Terciário.`;
    return`<div class="doc-a4">${this._h(lh)}<div class="doc-content">
      <div style="text-align:center;font-size:12pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:10px">Cadastro de Atendimento e Parecer Social</div>
      <div style="background:#e8f5e9;border:1px solid #2d7d32;padding:6px 12px;font-size:10.5pt;margin-bottom:10px;border-radius:4px"><strong>Nº:</strong> ${_esc(c.solicitNum)} &nbsp;|&nbsp; <strong>Data:</strong> ${_fd(c.date)} &nbsp;|&nbsp; <strong>Proc.:</strong> ${_esc((c.procedure||'').toUpperCase())}</div>
      <div style="font-size:10.5pt;text-align:justify;margin-bottom:8px"><strong>OBJETIVO:</strong> Subsidiar tecnicamente a análise da solicitação de procedimento pelo Programa Itapajé Mais Saúde.</div>
      ${this._sec('1. PERFIL SOCIOECONÔMICO')}
      <table style="width:100%;border-collapse:collapse;margin-bottom:6px;font-size:10.5pt">
        ${this._row('Nome completo',c.name)}
        ${this._row('Data de Nascimento',_fd(c.birth)+(_age(c.birth)?' ('+_age(c.birth)+')':''))}
        ${this._row('Endereço',(c.address||'[INFORMAR]')+', '+(c.neighborhood||'')+', '+_MUNIC+'/'+_UF)}
        ${c.reference?this._row('Ponto de referência',c.reference):''}
        ${this._row('Renda Familiar','R$ '+(c.income||'[INFORMAR]')+' — '+(c.incomeRange||''))}
        ${this._row('Situação Habitacional',(c.housing||'[INFORMAR]')+(c.services?' · '+c.services:''))}
        ${this._row('CPF',c.cpf||'[INFORMAR]')}
        ${this._row('Telefone',c.phone)}
        ${this._row('Composição Familiar / Mãe',(c.mother||'[INFORMAR]')+(c.motherProf?' — '+c.motherProf:''))}
        ${this._row('Profissão',c.profession||'[INFORMAR]')}
        ${this._row('Escolaridade',c.education||'[INFORMAR]')}
      </table>
      ${this._sec('2. PARECER TÉCNICO')}
      <div style="font-size:11pt;line-height:1.9;text-align:justify;text-indent:1.25cm;margin:4px 0 6px">${_esc(par)}</div>
      <div style="font-size:11pt;line-height:1.8;text-align:justify;text-indent:1.25cm;margin:4px 0 8px">${_esc(reg)}</div>
      <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:7px 12px;font-size:11pt;font-weight:bold;text-align:center;margin:10px 0">CONCLUSÃO: O Serviço Social manifesta parecer FAVORÁVEL à inclusão no Programa Itapajé Mais Saúde.</div>
      <div style="text-align:right;font-size:10.5pt;margin:8px 0;font-style:italic">${_MUNIC} – ${_UF}, ${_hoje()}.</div>
      ${this._s2(r)}
    </div>${this._f(lh,r)}</div>`;
  },

  pag3(c,lh,r){
    return`<div class="doc-a4">${this._h(lh)}<div class="doc-content">
      <div style="text-align:center;font-size:12pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:10px">Guia de Autorização e Agendamento</div>
      ${this._sec('AUTORIZAÇÃO DE PROCEDIMENTO')}
      <div style="font-size:11pt;line-height:1.9;text-align:justify;text-indent:1.25cm;margin:6px 0">Em conformidade com o Decreto nº 49/2025, fica <strong>AUTORIZADA</strong> a realização do procedimento abaixo descrito pelo Programa Itapajé Mais Saúde:</div>
      <table style="width:100%;border-collapse:collapse;margin:8px 0;font-size:10.5pt">
        ${this._row('Procedimento',(c.procedure||'[INFORMAR]').toUpperCase())}
        ${this._row('Paciente',c.name)}
        ${this._row('CPF',c.cpf||'[INFORMAR]')}
        ${this._row('Nº Solicitação',c.solicitNum)}
        ${this._row('Local de Realização',c.hospital||'[INFORMAR]')}
        ${c.hospitalAddress?this._row('Endereço do Local',c.hospitalAddress):''}
        ${this._row('Data Prevista',(c.scheduledDate?_fd(c.scheduledDate):'[INFORMAR]')+' | Horário: '+(c.scheduledTime||'[INFORMAR]'))}
      </table>
      ${this._sec('ORIENTAÇÕES AO PACIENTE')}
      <div style="font-size:10.5pt;line-height:1.8;padding:0 4px;margin:4px 0">
        1. Comparecer com <strong>30 (trinta) minutos</strong> de antecedência.<br>
        2. Levar <strong>documento de identidade original</strong> (RG ou CNH) e <strong>CPF</strong>.<br>
        3. Apresentar <strong>esta guia de autorização</strong> assinada.<br>
        4. Em caso de impossibilidade, contatar: 📞 <strong>${_PHONE}</strong>
      </div>
      <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:7px 12px;font-size:10.5pt;margin:10px 0;text-align:center">
        <strong>${_SECR} — ${_MUNIC}/${_UF}</strong><br>
        ${_END_SEC} · ${_CEP}<br>
        Tel.: ${_PHONE} · ${_EMAIL}
      </div>
      <div style="text-align:right;font-size:10.5pt;margin:8px 0;font-style:italic">${_MUNIC} – ${_UF}, ${_hoje()}.</div>
      ${this._s1(r)}
    </div>${this._f(lh,r)}</div>`;
  },

  buildAll(id){
    if(typeof DB==='undefined')return'';
    const c=DB.getIMSCase(id); if(!c)return'';
    const lh=DB.getLH(),r=DB.getResp();
    const rpts=DB.getReports().filter(x=>x.imsId===id);
    return this.pag1(c,lh,r)+this.pag2(c,lh,r,rpts[0]?.text||null)+this.pag3(c,lh,r);
  },
};

document.addEventListener('DOMContentLoaded', ()=>{
  if(typeof PrintMod!=='undefined') PrintMod.buildCompleteProcess = id => IMSPrint3P.buildAll(id);
  if(typeof Print!=='undefined') Print.printIMS = function(id){
    const html=IMSPrint3P.buildAll(id);
    if(typeof PrintMod!=='undefined') PrintMod._printWin(html,'Processo IMS — '+(DB.getIMSCase(id)?.name||''));
  };
});

/* ══ RELATÓRIO SOCIAL — salva para IMS e geral ══ */
document.addEventListener('DOMContentLoaded', ()=>{
  if(typeof Relatorio==='undefined')return;
  const _oi=Relatorio.init?.bind(Relatorio);
  Relatorio.init=function(){
    _oi?.();
    const sel=document.getElementById('rel-patient-select'); if(!sel)return;
    const pts=DB.getPatients().sort((a,b)=>a.name.localeCompare(b.name));
    sel.innerHTML='<option value="">— Paciente Geral —</option>'+
      pts.map(p=>`<option value="pat:${p.id}">${_esc(p.name)}</option>`).join('');
  };
  Relatorio.save=function(){
    if(!this._lastReport){UI.toast('Gere um relatório primeiro.','error');return;}
    if(this._imsCase){
      DB.addReport({id:Utils.uid(),imsId:this._imsCase.id,patientId:null,patientName:this._imsCase.name,text:this._lastReport,mode:'saved',at:Date.now()});
      UI.toast('Relatório salvo para '+this._imsCase.name+' (IMS)!'); return;
    }
    const sel=document.getElementById('rel-patient-select');
    if(sel&&sel.value&&sel.value.startsWith('pat:')){
      const id=sel.value.split(':')[1],pt=DB.getPatient(id);
      if(pt){DB.addReport({id:Utils.uid(),imsId:null,patientId:id,patientName:pt.name,text:this._lastReport,mode:'saved',at:Date.now()});UI.toast('Relatório salvo para '+pt.name+' (Geral)!');return;}
    }
    UI.toast('Selecione um caso IMS ou paciente geral.','error');
  };
});

console.log('SAS v4.2 carregado ✓');
/* ═══════════════════════════════════════════════════════
   SAS v4.3 — PATCH FINAL DEFINITIVO
   Substitui: WhatsApp · Ofício ABNT · IMS 3-páginas · Relatório Save
   ═══════════════════════════════════════════════════════ */

/* ── constantes institucionais ── */
const C = {
  phone   : '(85) 9 9126-4880',
  gerente : 'Francisco Maílson de Sousa Moreira',
  cargo   : 'Gerente de Apoio Social',
  secr    : 'Secretaria Municipal de Saúde',
  munic   : 'Itapajé',
  uf      : 'CE',
  end     : 'R. São Francisco, Nº 225 – Centro, Itapajé/CE',
  cep     : 'CEP: 62.600-000',
  email   : 'saude@itapaje.ce.gov.br',
  site    : 'www.itapaje.ce.gov.br',
  lei     : 'Lei Municipal nº 2.399/2025',
  dec     : 'Decreto nº 49/2025',
};

const F = {
  hoje : () => new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'}),
  hojeS: () => new Date().toLocaleDateString('pt-BR'),
  esc  : s  => s ? String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : '',
  data : s  => { if(!s) return '[INFORMAR]'; const[y,m,d]=s.split('-'); return`${d}/${m}/${y}`; },
  idade: b  => {
    if(!b) return '';
    const t=new Date(), x=new Date(b);
    let a=t.getFullYear()-x.getFullYear();
    if(t.getMonth()-x.getMonth()<0||(t.getMonth()===x.getMonth()&&t.getDate()<x.getDate()))a--;
    return a+' anos';
  },
};

/* ════════════════════════════════════════════════
   WHATSAPP — mensagens completas
════════════════════════════════════════════════ */
const WAmsg = {

  /* rodapé fixo de todas as mensagens para pacientes */
  _rodapePaciente() {
    return `\n\n──────────────────────\n📞 ${C.phone}\n👤 ${C.cargo}\n*${C.gerente}*\n${C.secr} — ${C.munic}/${C.uf}\n_${F.hojeS()}_`;
  },

  /* rodapé fixo das mensagens para gabinete */
  _rodapGabinete() {
    return `\n\n_${C.gerente}_\n_${C.cargo}_\n_Tel.: ${C.phone}_`;
  },

  /* ── Mensagem para PACIENTE ── */
  paraPaciente(item, tipo) {
    const rod  = this._rodapePaciente();
    const isIMS = !!item.solicitNum;
    const prog  = isIMS ? 'Programa *Itapajé Mais Saúde*' : `*${C.secr}*`;
    const proc  = item.procedure || item.obs || '';
    const num   = item.solicitNum || '';
    const lp    = proc  ? `\n🏥 *Procedimento:* ${proc}` : '';
    const ln    = num   ? `\n🔢 *Nº do processo:* ${num}` : '';
    const ld    = item.scheduledDate ? `\n📅 *Data:* ${F.data(item.scheduledDate)}${item.scheduledTime ? ' às '+item.scheduledTime : ''}` : '';
    const lh    = item.hospital        ? `\n🏨 *Local:* ${item.hospital}`          : '';
    const le    = item.hospitalAddress ? `\n📍 ${item.hospitalAddress}`             : '';

    const msgs = {
      status:
        `Olá, *${item.name}*! 👋\n\n` +
        `Seu processo junto ao ${prog} foi atualizado.\n\n` +
        `📋 *Status atual:* ${item.status}` + ln + lp +
        `\n\nEm caso de dúvidas, entre em contato conosco.` + rod,

      aprovado:
        `✅ *${item.name}*, seu processo foi *APROVADO*!\n\n` +
        `🎉 ${prog} informa que sua solicitação foi aprovada.` +
        lp + ln + ld + lh + le +
        `\n\n📌 *Orientações:*\n` +
        `• Comparecer 30 minutos antes\n` +
        `• Levar documento de identidade original (RG ou CNH)\n` +
        `• Levar CPF\n` +
        `• Apresentar este comprovante\n\n` +
        `Em caso de dúvidas, entre em contato conosco.` + rod,

      pendente:
        `⚠️ *${item.name}*, seu processo está com *DOCUMENTAÇÃO PENDENTE*.\n\n` +
        (num ? `🔢 *Nº:* ${num}\n` : '') +
        `Por favor, compareça à ${C.secr} para regularizar sua situação.\n\n` +
        `📍 *${C.end}*\n\n` +
        `Em caso de dúvidas, entre em contato conosco.` + rod,

      agendamento:
        `📅 *${item.name}*, seu procedimento foi *AGENDADO*!\n\n` +
        lp + ld + lh + le +
        `\n\n📌 *Lembre-se:*\n` +
        `• Chegar 30 minutos antes\n` +
        `• Trazer RG ou CNH original\n` +
        `• Trazer CPF\n` +
        `• Apresentar este comprovante\n\n` +
        `Em caso de dúvidas, entre em contato conosco.` + rod,

      reprovado:
        `❌ *${item.name}*, seu processo *não foi aprovado* neste momento.\n\n` +
        (num ? `🔢 *Nº:* ${num}\n\n` : '') +
        `Compareça à ${C.secr} para informações sobre alternativas disponíveis.\n\n` +
        `📍 *${C.end}*\n\n` +
        `Em caso de dúvidas, entre em contato conosco.` + rod,

      custom: document.getElementById('wa-custom-msg')?.value || '',
    };
    return msgs[tipo] || msgs.status;
  },

  /* ── Bloco de dados IMS para gabinete ── */
  _blocoIMS(c, visitDate, parecer) {
    const elig = [
      [c.eligResident,  'Residente em Itapajé/CE'],
      [c.eligIncome,    'Renda ≤ 2 salários mínimos'],
      [c.eligFila,      'Em fila SUS sem previsão'],
      [c.eligIndicacao, 'Indicação médica cirúrgica'],
      [c.eligDocs,      'Documentação completa'],
    ].map(([v,l]) => `${v ? '✅' : '❌'} ${l}`).join('\n');

    return (
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*👤 DADOS DO PACIENTE*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n• *Nome:* ${c.name}` +
      `\n• *Nasc.:* ${F.data(c.birth)} (${F.idade(c.birth)})` +
      `\n• *CPF:* ${c.cpf || '[INFORMAR]'}` +
      `\n• *Tel.:* ${c.phone}` +
      `\n• *End.:* ${c.address || '—'}, ${c.neighborhood || '—'}, ${C.munic}/${C.uf}` +
      (c.reference ? `\n• *Ref.:* ${c.reference}` : '') +
      `\n• *Renda:* R$ ${c.income || '—'} (${c.incomeRange || '—'})` +
      `\n• *Habitação:* ${c.housing || '—'}${c.services ? ' · ' + c.services : ''}` +
      `\n• *Mãe:* ${c.mother || '—'}${c.motherProf ? ' (' + c.motherProf + ')' : ''}` +
      `\n• *Profissão:* ${c.profession || '—'}` +
      `\n• *Escolaridade:* ${c.education || '—'}` +
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*🏥 PROCESSO IMS*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n• *Nº Solicitação:* ${c.solicitNum}` +
      `\n• *Data do Pedido:* ${F.data(c.date)}` +
      `\n• *Data Visita Social:* ${visitDate ? F.data(visitDate) : '[INFORMAR]'}` +
      `\n• *Procedimento:* ${c.procedure || '—'}` +
      `\n• *Hospital Previsto:* ${c.hospital || '[INFORMAR]'}` +
      (c.scheduledDate ? `\n• *Agendamento:* ${F.data(c.scheduledDate)}${c.scheduledTime ? ' às ' + c.scheduledTime : ''}` : '') +
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*📡 SITUAÇÃO SISREG*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n${c.regulation || 'Paciente em fila de espera no SISREG do Estado do Ceará, sem previsão de atendimento pelo SUS.'}` +
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*📝 PARECER TÉCNICO*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n${parecer || 'Paciente preenche os critérios da ' + C.lei + '. Serviço Social emite parecer FAVORÁVEL à inclusão no Programa Itapajé Mais Saúde.'}` +
      `\n\n*Elegibilidade:*\n${elig}`
    );
  },

  /* ── Bloco de dados GERAL para gabinete ── */
  _blocoGeral(p, visitDate, parecer) {
    return (
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*👤 DADOS DO PACIENTE*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n• *Nome:* ${p.name}` +
      `\n• *Nasc.:* ${F.data(p.birth)} (${F.idade(p.birth)})` +
      `\n• *CPF:* ${p.cpf || '[INFORMAR]'}` +
      `\n• *Tel.:* ${p.phone}` +
      `\n• *End.:* ${(p.street||'—')+(p.number?', '+p.number:'')+', '+(p.neighborhood||'—')+', '+C.munic+'/'+C.uf}` +
      `\n• *Situação Financeira:* ${p.financial || '—'}` +
      `\n• *Benefícios:* ${p.benefits || 'Nenhum'}` +
      `\n• *Mãe:* ${p.mother || '—'}` +
      `\n• *Pai:* ${p.father || '—'}` +
      (p.obs ? `\n• *Obs.:* ${p.obs}` : '') +
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*📊 STATUS DO ATENDIMENTO*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n• *Status atual:* ${p.status}` +
      `\n• *Data Visita Social:* ${visitDate ? F.data(visitDate) : '[INFORMAR]'}` +
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n*📝 PARECER TÉCNICO*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n${parecer || 'Paciente atendido pelo Serviço Social desta Secretaria. Aguarda decisão do gabinete.'}`
    );
  },

  /* ── Mensagem para GABINETE (IMS ou Geral) ── */
  paraGabinete(item, tipo, parecer, visitDate) {
    const r     = (typeof DB !== 'undefined') ? DB.getResp() : {};
    const unit  = r.unit || C.secr;
    const isIMS = !!item.solicitNum;
    const bloco = isIMS
      ? this._blocoIMS(item, visitDate, parecer)
      : this._blocoGeral(item, visitDate, parecer);
    const rod   = this._rodapGabinete();
    const cab   = `*🏥 ${unit.toUpperCase()} — ${C.munic}/${C.uf}*\n_${F.hoje()}_\n\n`;
    const botoesDecisao =
      `\n\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*` +
      `\n✅ *[APROVAR]* → Responda: *APROVADO*` +
      `\n❌ *[REPROVAR]* → Responda: *REPROVADO*` +
      `\n*━━━━━━━━━━━━━━━━━━━━━━━━━━*`;

    if (tipo === 'solicitacao_total') {
      const titulo = isIMS
        ? `*━━ SOLICITAÇÃO TOTAL — PROGRAMA IMS ━━*\n*⚠️ Aguarda APROVAÇÃO ou REPROVAÇÃO*`
        : `*━━ SOLICITAÇÃO TOTAL — ATENDIMENTO GERAL ━━*\n*⚠️ Aguarda APROVAÇÃO ou REPROVAÇÃO*`;
      return cab + titulo + '\n' + bloco + botoesDecisao + rod;
    }

    const labels = {
      parecer  : `*📋 ENCAMINHAMENTO DE PARECER SOCIAL*`,
      urgente  : `*🚨 CASO URGENTE — ATENÇÃO PRIORITÁRIA*`,
      relatorio: `*📊 RELATÓRIO COMPLETO DO CASO*`,
    };
    return cab + (labels[tipo] || labels.parecer) + '\n' + bloco + rod;
  },
};

/* ── instala overrides no WhatsApp ── */
window.addEventListener('load', () => {
  if (typeof WhatsApp === 'undefined') return;

  WhatsApp._buildPatientMsg  = (item, tipo)            => WAmsg.paraPaciente(item, tipo);
  WhatsApp._buildGabineteMsg = (item, tipo, par, vis)  => WAmsg.paraGabinete(item, tipo, par, vis);

  WhatsApp.notifyFromIMS = function(id) {
    const c = DB.getIMSCase(id);
    if (!c) return;
    const phone = Utils.cleanPhone(c.phone);
    if (!phone) { UI.toast('Sem telefone cadastrado.', 'error'); return; }
    const map = { 'Aprovado':'aprovado', 'Agendado':'agendamento', 'Reprovado':'reprovado', 'Pendente de docs':'pendente' };
    const msg = WAmsg.paraPaciente(c, map[c.status] || 'status');
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'paciente', name: c.name, phone: c.phone, type: map[c.status] || 'status', at: Date.now() });
    WhatsApp.renderHistory?.();
    UI.toast('WhatsApp aberto para ' + c.name);
  };

  WhatsApp.notifyPatientStatus = function() {
    const item = (typeof StatusMod !== 'undefined') ? StatusMod.currentItem?.() : null;
    if (!item) { UI.toast('Selecione um paciente na aba Status.', 'error'); return; }
    const phone = Utils.cleanPhone(item.phone);
    if (!phone) { UI.toast('Sem telefone cadastrado.', 'error'); return; }
    const msg = WAmsg.paraPaciente(item, 'status');
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    DB.addWAHist({ id: Utils.uid(), to: 'paciente', name: item.name, phone: item.phone, type: 'status', at: Date.now() });
    WhatsApp.renderHistory?.();
    UI.toast('WhatsApp aberto!');
  };
});

/* ════════════════════════════════════════════════
   OFÍCIO ABNT PURO — sem vínculo com IMS
════════════════════════════════════════════════ */
const ABNT = {

  _proximoNum() {
    if (typeof DB === 'undefined') return '001';
    const ano  = new Date().getFullYear();
    const lista = DB.getOficiosAll().filter(x => !x.isGuia && x.num && x.num.includes('/' + ano));
    return String(lista.length + 1).padStart(3, '0');
  },

  /* Gera o texto completo com IA */
  gerar({ destNome, destCargo, destInst, assunto, detalhes, fecho, numOficio }) {
    const r     = (typeof DB !== 'undefined') ? DB.getResp() : {};
    const mgr   = r.managerName || C.gerente;
    const cargo = r.managerRole || C.cargo;
    const unit  = r.unit        || C.secr;
    const num   = numOficio || this._proximoNum();
    const ano   = new Date().getFullYear();

    /* detecta verbo pela palavra-chave do assunto */
    const al = (assunto || '').toLowerCase();
    let verbo = 'solicitar';
    if      (al.includes('encaminh'))              verbo = 'encaminhar';
    else if (al.includes('comunic') || al.includes('inform')) verbo = 'comunicar';
    else if (al.includes('convocar'))              verbo = 'convocar';
    else if (al.includes('notific'))               verbo = 'notificar';
    else if (al.includes('requer'))                verbo = 'requerer';

    const p1 = `Ao cumprimentá-lo(a) cordialmente, venho por meio deste ${verbo}, em nome da ${unit} do Município de ${C.munic}/${C.uf}, ${assunto ? assunto.toLowerCase() : '[INFORMAR O OBJETIVO PRINCIPAL DO OFÍCIO]'}.`;

    const p2 = detalhes ||
      `Informamos que tal medida fundamenta-se nas atribuições institucionais desta ${unit} e visa garantir a continuidade e a qualidade dos serviços de saúde prestados à população do Município de ${C.munic}/${C.uf}, em conformidade com os princípios da legalidade, impessoalidade, moralidade, publicidade e eficiência previstos no artigo 37 da Constituição Federal e com as normas municipais vigentes.`;

    const p3 = `Coloco-me à disposição de Vossa Senhoria para quaisquer esclarecimentos adicionais, podendo ser contatado pelo telefone ${C.phone} ou pelo endereço eletrônico ${C.email}.`;

    return (
      `OFÍCIO Nº ${num}/${ano} – APOIO SOCIAL\n\n` +
      `${C.munic}/${C.uf}, ${F.hoje()}.\n\n` +
      `Ao Senhor(a): ${destNome  || '[Nome do Destinatário]'}\n` +
      `${destCargo || '[Cargo do Destinatário]'}\n` +
      `${destInst  || '[Instituição/Órgão]'}\n\n` +
      `Assunto: ${assunto || '[Assunto]'}\n\n` +
      `Senhor(a) ${destCargo ? (destCargo.split(' ').at(-1) || '[Cargo]') : '[Cargo]'},\n\n` +
      `1. ${p1}\n\n` +
      `2. ${p2}\n\n` +
      `3. ${p3}\n\n` +
      `${fecho || 'Atenciosamente'},\n\n\n` +
      `${mgr}\n` +
      `${cargo}\n` +
      `${unit}\n` +
      `${C.munic}/${C.uf} — Tel.: ${C.phone}\n` +
      `${C.email}`
    );
  },

  /* Constrói a página HTML para impressão */
  paginaHTML(dados, lh, r) {
    const { num, body, dest, destCargo, assunto, date, local, procDate, procTime } = dados;
    const mgr   = r.managerName || C.gerente;
    const cargo  = r.managerRole || C.cargo;
    const unit   = r.unit        || C.secr;
    const hdr    = (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh)    : '';
    const ftr    = (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '';
    const hoje   = date ? F.data(date) : F.hoje();

    return `<div class="doc-a4">${hdr}
      <div class="doc-content">
        <div style="text-align:right;font-size:10.5pt;font-style:italic;margin-bottom:10px">
          ${F.esc(C.munic)} – ${C.uf}, ${hoje}.
        </div>
        <div style="text-align:center;margin-bottom:4px">
          <span style="background:#1b5e20;color:#fff;font-size:8.5pt;padding:2px 10px;border-radius:3px;text-transform:uppercase;letter-spacing:1.5px">Ofício</span>
        </div>
        <div style="text-align:center;font-size:12pt;font-weight:bold;margin:5px 0 14px;letter-spacing:.5px">
          ${F.esc(num || 'Nº —')}
        </div>
        ${dest ? `<div style="margin:0 0 14px;font-size:11pt;line-height:1.8">
          <strong>Ao Senhor(a):</strong> ${F.esc(dest)}<br>
          ${destCargo ? F.esc(destCargo) : ''}
        </div>` : ''}
        ${assunto ? `<div style="text-align:center;font-size:11pt;font-weight:bold;text-transform:uppercase;border-bottom:1.5px solid #000;padding-bottom:6px;margin:0 0 14px">
          ${F.esc(assunto)}
        </div>` : ''}
        <div style="font-size:11pt;line-height:1.95;text-align:justify;white-space:pre-wrap">${F.esc(body || '')}</div>
        ${local || procDate ? `<div style="margin:14px 0;font-size:10.5pt;border:1px solid #ccc;padding:8px 12px;border-radius:4px">
          ${procDate ? '<strong>Data:</strong> '+F.data(procDate)+(procTime?' às '+procTime:'')+'<br>' : ''}
          ${local   ? '<strong>Local:</strong> '+F.esc(local) : ''}
        </div>` : ''}
        <div style="text-align:center;margin-top:16mm">
          <div style="display:inline-block;text-align:center;min-width:240px">
            <div style="height:42px;border-bottom:1px solid #000;margin-bottom:5px"></div>
            <div style="font-size:11pt;font-weight:bold">${F.esc(mgr)}</div>
            <div style="font-size:9.5pt;color:#333">${F.esc(cargo)}</div>
            <div style="font-size:9.5pt;color:#333">${F.esc(unit)}</div>
            <div style="font-size:9.5pt">Tel.: ${C.phone}</div>
          </div>
        </div>
      </div>${ftr}</div>`;
  },
};

/* ── instala overrides em Oficios ── */
window.addEventListener('load', () => {
  if (typeof Oficios === 'undefined') return;

  /* oculta campo de referência IMS no formulário de ofício */
  const imsRow = document.getElementById('oficio-ims-ref')?.closest('.form-group');
  if (imsRow) imsRow.style.display = 'none';
  const autoFillRow = document.getElementById('oficio-auto-fill-ims');
  if (autoFillRow) autoFillRow.style.display = 'none';

  /* gera ofício com IA */
  Oficios.generateAI = function() {
    const numEl = document.getElementById('oficio-num');
    if (numEl && !numEl.value) {
      const n = ABNT._proximoNum() + '/' + new Date().getFullYear();
      numEl.value = n;
      const prev = document.getElementById('oficio-num-preview');
      if (prev) prev.textContent = 'Nº: ' + n;
    }
    const text = ABNT.gerar({
      numOficio : document.getElementById('oficio-num')?.value?.split('/')[0] || '',
      destNome  : document.getElementById('oficio-dest')?.value?.trim()       || '',
      destCargo : document.getElementById('oficio-dest-cargo')?.value?.trim() || '',
      destInst  : '',
      assunto   : document.getElementById('oficio-subject')?.value?.trim()    || '',
      detalhes  : '',
      fecho     : document.getElementById('oficio-fecho')?.value              || 'Atenciosamente',
    });
    const body = document.getElementById('oficio-body');
    if (!body) return;
    body.value = '';
    let i = 0;
    const sp = Math.max(5, Math.min(16, 3200 / text.length));
    const tmr = setInterval(() => {
      body.value += text[i++];
      body.scrollTop = body.scrollHeight;
      if (i >= text.length) { clearInterval(tmr); UI.toast('Ofício gerado com IA ✓'); }
    }, sp);
  };

  Oficios.autoFillFromIMS = function() {}; /* ignorado */

  /* pré-visualiza / imprime */
  Oficios.printPreview = function() {
    const body = document.getElementById('oficio-body')?.value?.trim();
    if (!body) { UI.toast('Gere ou preencha o corpo do ofício primeiro.', 'error'); return; }
    const lh = DB.getLH(), r = DB.getResp();
    const html = ABNT.paginaHTML({
      num      : document.getElementById('oficio-num')?.value       || '',
      body,
      dest     : document.getElementById('oficio-dest')?.value      || '',
      destCargo: document.getElementById('oficio-dest-cargo')?.value || '',
      assunto  : document.getElementById('oficio-subject')?.value   || '',
      date     : document.getElementById('oficio-date')?.value      || '',
      local    : document.getElementById('oficio-local')?.value     || '',
      procDate : document.getElementById('oficio-proc-date')?.value  || '',
      procTime : document.getElementById('oficio-proc-time')?.value  || '',
    }, lh, r);
    document.getElementById('print-preview-content').innerHTML = html;
    UI.showModal('modal-print-preview');
  };
});

/* ════════════════════════════════════════════════
   IMS — 3 PÁGINAS PADRONIZADAS
════════════════════════════════════════════════ */
const IMS3P = {

  /* helpers de layout */
  _hdr : (lh)    => (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh)    : '',
  _ftr : (lh, r) => (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '',
  _row(label, valor) {
    if (!valor) return '';
    return `<tr>
      <td style="font-weight:bold;background:#f5f5f5;padding:4px 8px;border:.5px solid #ccc;width:40%;vertical-align:top">${label}</td>
      <td style="padding:4px 8px;border:.5px solid #ccc;vertical-align:top">${F.esc(valor)}</td>
    </tr>`;
  },
  _sec : t => `<div style="font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:4px 9px;margin:9px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32;letter-spacing:.4px">${t}</div>`,

  _assinDupla(r) {
    const m  = r.managerName || C.gerente,  mc = r.managerRole || C.cargo;
    const s  = r.socialName  || '_________________________', sc = r.socialReg || 'Assistente Social';
    const u  = r.unit        || C.secr;
    return `<div style="display:grid;grid-template-columns:1fr 1fr;gap:36px;margin-top:14mm">
      <div style="text-align:center">
        <div style="height:38px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div style="font-size:10.5pt;font-weight:bold">${F.esc(s)}</div>
        <div style="font-size:9.5pt;color:#444">${F.esc(sc)}</div>
      </div>
      <div style="text-align:center">
        <div style="height:38px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div style="font-size:10.5pt;font-weight:bold">${F.esc(m)}</div>
        <div style="font-size:9.5pt;color:#444">${F.esc(mc)}</div>
        <div style="font-size:9.5pt;color:#444">${F.esc(u)}</div>
        <div style="font-size:9.5pt">Tel.: ${C.phone}</div>
      </div>
    </div>`;
  },

  _assinCentral(r) {
    const m  = r.managerName || C.gerente,  mc = r.managerRole || C.cargo;
    const u  = r.unit        || C.secr;
    return `<div style="text-align:center;margin-top:14mm">
      <div style="display:inline-block;min-width:240px;text-align:center">
        <div style="height:38px;border-bottom:1px solid #000;margin-bottom:5px"></div>
        <div style="font-size:11pt;font-weight:bold">${F.esc(m)}</div>
        <div style="font-size:9.5pt;color:#444">${F.esc(mc)}</div>
        <div style="font-size:9.5pt;color:#444">${F.esc(u)}</div>
        <div style="font-size:9.5pt">Tel.: ${C.phone}</div>
      </div>
    </div>`;
  },

  /* ── PÁGINA 1 — Capa ── */
  pagCapa(c, lh, r) {
    const mod = (c.procedure || '').toLowerCase().includes('exam') ? 'EXAME' : 'CIRURGIA';
    return `<div class="doc-a4">${this._hdr(lh)}
      <div class="doc-content" style="display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:12mm">
        <div style="font-size:13pt;font-weight:bold;text-transform:uppercase;line-height:1.5;margin-bottom:9mm">
          PROCESSO ADMINISTRATIVO DE SOLICITAÇÃO<br>DE PROCEDIMENTO PELO PROJETO<br>ITAPAJÉ MAIS SAÚDE
        </div>
        <div style="font-size:11pt;font-weight:bold;margin-bottom:3mm">
          PROCESSO ADMINISTRATIVO Nº: <span style="font-family:monospace">${F.esc(c.solicitNum)}</span>
        </div>
        <div style="font-size:10.5pt;margin-bottom:9mm">
          MODALIDADE: ${mod} &nbsp;|&nbsp; ${C.lei}
        </div>
        <div style="border:2px solid #2d7d32;padding:9mm 15mm;background:#f9fff9;width:92%;margin-bottom:9mm">
          <div style="font-size:10.5pt;margin-bottom:5mm">
            ASSUNTO: Solicitação de Procedimento pelo Projeto Itapajé Mais Saúde
          </div>
          <div style="font-size:12pt;font-weight:bold;margin-bottom:6mm">DADOS DO BENEFICIÁRIO</div>
          <table style="width:100%;font-size:10.5pt;text-align:left;border-collapse:collapse">
            <tr><td style="font-weight:bold;padding:4px 0;width:42%">• Nome:</td>
                <td>${F.esc(c.name)}</td></tr>
            <tr><td style="font-weight:bold;padding:4px 0">• CPF:</td>
                <td>${F.esc(c.cpf || '[INFORMAR]')}</td></tr>
            <tr><td style="font-weight:bold;padding:4px 0">• Procedimento solicitado:</td>
                <td>${F.esc(c.procedure || '[INFORMAR]')}</td></tr>
          </table>
        </div>
        <div style="font-size:10.5pt;font-style:italic">
          LOCAL E DATA: ${C.munic}/${C.uf}, ${F.hoje()}.
        </div>
      </div>
      ${this._ftr(lh, r)}</div>`;
  },

  /* ── PÁGINA 2 — Cadastro + Parecer Social ── */
  pagCadastroParecer(c, lh, r, textoRelatorio) {
    const parecer = textoRelatorio ||
      `Após entrevista e análise documental realizada pelo Serviço Social desta ` +
      `${r.unit || C.secr}, constatou-se que o(a) paciente ${c.name} reside ` +
      `no Município de ${C.munic}/${C.uf}${c.address ? ', em ' + c.address + ', ' + c.neighborhood : ''}, ` +
      `e apresenta situação de vulnerabilidade socioeconômica` +
      `${c.income ? ', com renda familiar de R$ ' + c.income + ' (' + c.incomeRange + ')' : ''}, ` +
      `tornando-o(a) elegível aos benefícios da ${C.lei} e do ${C.dec}.`;

    const regulacao = c.regulation ||
      `O(A) paciente encontra-se em fila de espera no Sistema de Regulação ` +
      `do Estado do Ceará (SISREG), sem previsão de agendamento pelo SUS, sendo ` +
      `encaminhado(a) pelo médico assistente para realização de procedimento especializado.`;

    return `<div class="doc-a4">${this._hdr(lh)}
      <div class="doc-content">
        <div style="text-align:center;font-size:12pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:11px">
          Cadastro de Atendimento e Parecer Social
        </div>
        <div style="background:#e8f5e9;border:1px solid #2d7d32;padding:6px 13px;font-size:10.5pt;margin-bottom:11px;border-radius:4px">
          <strong>Nº:</strong> ${F.esc(c.solicitNum)} &nbsp;|&nbsp;
          <strong>Data:</strong> ${F.data(c.date)} &nbsp;|&nbsp;
          <strong>Proc.:</strong> ${F.esc((c.procedure || '').toUpperCase())}
        </div>
        <div style="font-size:10.5pt;text-align:justify;margin-bottom:9px">
          <strong>OBJETIVO:</strong> Subsidiar tecnicamente a análise da solicitação de procedimento
          pelo Programa Itapajé Mais Saúde.
        </div>

        ${this._sec('1. PERFIL SOCIOECONÔMICO')}
        <table style="width:100%;border-collapse:collapse;margin-bottom:7px;font-size:10.5pt">
          ${this._row('Nome completo', c.name)}
          ${this._row('Data de Nascimento', F.data(c.birth) + (F.idade(c.birth) ? ' (' + F.idade(c.birth) + ')' : ''))}
          ${this._row('Endereço', (c.address || '[INFORMAR]') + ', ' + (c.neighborhood || '') + ', ' + C.munic + '/' + C.uf)}
          ${c.reference ? this._row('Ponto de referência', c.reference) : ''}
          ${this._row('Renda Familiar', 'R$ ' + (c.income || '[INFORMAR]') + ' — ' + (c.incomeRange || ''))}
          ${this._row('Situação Habitacional', (c.housing || '[INFORMAR]') + (c.services ? ' · ' + c.services : ''))}
          ${this._row('CPF', c.cpf || '[INFORMAR]')}
          ${this._row('Telefone', c.phone)}
          ${this._row('Composição Familiar / Mãe', (c.mother || '[INFORMAR]') + (c.motherProf ? ' — ' + c.motherProf : ''))}
          ${this._row('Profissão', c.profession || '[INFORMAR]')}
          ${this._row('Escolaridade', c.education || '[INFORMAR]')}
        </table>

        ${this._sec('2. PARECER TÉCNICO')}
        <div style="font-size:11pt;line-height:1.95;text-align:justify;text-indent:1.2cm;margin:5px 0 7px">${F.esc(parecer)}</div>
        <div style="font-size:11pt;line-height:1.85;text-align:justify;text-indent:1.2cm;margin:5px 0 9px">${F.esc(regulacao)}</div>
        <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:8px 13px;font-size:11pt;font-weight:bold;text-align:center;margin:11px 0">
          CONCLUSÃO: O Serviço Social manifesta parecer FAVORÁVEL à inclusão no Programa Itapajé Mais Saúde.
        </div>

        <div style="text-align:right;font-size:10.5pt;margin:9px 0;font-style:italic">
          ${C.munic} – ${C.uf}, ${F.hoje()}.
        </div>
        ${this._assinDupla(r)}
      </div>
      ${this._ftr(lh, r)}</div>`;
  },

  /* ── PÁGINA 3 — Autorização + Agendamento ── */
  pagAutorizacao(c, lh, r) {
    return `<div class="doc-a4">${this._hdr(lh)}
      <div class="doc-content">
        <div style="text-align:center;font-size:12pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:11px">
          Guia de Autorização e Agendamento
        </div>

        ${this._sec('AUTORIZAÇÃO DE PROCEDIMENTO')}
        <div style="font-size:11pt;line-height:1.95;text-align:justify;text-indent:1.2cm;margin:6px 0 9px">
          Em conformidade com o ${C.dec}, fica <strong>AUTORIZADA</strong> a realização
          do procedimento abaixo descrito pelo Programa Itapajé Mais Saúde:
        </div>

        <table style="width:100%;border-collapse:collapse;margin:9px 0;font-size:10.5pt">
          ${this._row('• Procedimento', (c.procedure || '[INFORMAR]').toUpperCase())}
          ${this._row('• Paciente', c.name)}
          ${this._row('• CPF', c.cpf || '[INFORMAR]')}
          ${this._row('• Nº da Solicitação', c.solicitNum)}
          ${this._row('• Local de Realização', c.hospital || '[INFORMAR]')}
          ${c.hospitalAddress ? this._row('• Endereço do Local', c.hospitalAddress) : ''}
          ${this._row('• Data Prevista', (c.scheduledDate ? F.data(c.scheduledDate) : '[INFORMAR]') + ' | Horário: ' + (c.scheduledTime || '[INFORMAR]'))}
        </table>

        ${this._sec('ORIENTAÇÕES AO PACIENTE')}
        <div style="font-size:10.5pt;line-height:1.85;padding:0 5px;margin:5px 0">
          1. Comparecer com <strong>30 (trinta) minutos</strong> de antecedência ao local indicado.<br>
          2. Levar <strong>documento de identidade original</strong> (RG ou CNH) e <strong>CPF</strong>.<br>
          3. Apresentar <strong>esta guia de autorização</strong> devidamente assinada.<br>
          4. Em caso de impossibilidade de comparecimento, entrar em contato previamente:
             📞 <strong>${C.phone}</strong>
        </div>

        <div style="background:#e8f5e9;border:1.5px solid #2d7d32;padding:8px 13px;font-size:10.5pt;margin:11px 0;text-align:center">
          <strong>${C.secr} — ${C.munic}/${C.uf}</strong><br>
          ${C.end} · ${C.cep}<br>
          Tel.: ${C.phone} · ${C.email}
        </div>

        <div style="text-align:right;font-size:10.5pt;margin:9px 0;font-style:italic">
          ${C.munic} – ${C.uf}, ${F.hoje()}.
        </div>
        ${this._assinCentral(r)}
      </div>
      ${this._ftr(lh, r)}</div>`;
  },

  /* monta as 3 páginas */
  buildAll(id) {
    if (typeof DB === 'undefined') return '';
    const c = DB.getIMSCase(id);
    if (!c) return '';
    const lh  = DB.getLH();
    const r   = DB.getResp();
    const rpts = DB.getReports().filter(x => x.imsId === id);
    const txt  = rpts[0]?.text || null;
    return this.pagCapa(c, lh, r) +
           this.pagCadastroParecer(c, lh, r, txt) +
           this.pagAutorizacao(c, lh, r);
  },
};

/* ── instala overrides de impressão IMS ── */
window.addEventListener('load', () => {
  if (typeof PrintMod !== 'undefined') PrintMod.buildCompleteProcess = id => IMS3P.buildAll(id);
  if (typeof Print    !== 'undefined') Print.printIMS = function(id) {
    const html = IMS3P.buildAll(id);
    PrintMod?._printWin(html, 'Processo IMS — ' + (DB.getIMSCase(id)?.name || ''));
  };
});

/* ════════════════════════════════════════════════
   RELATÓRIO SOCIAL — salva para IMS e para geral
════════════════════════════════════════════════ */
window.addEventListener('load', () => {
  if (typeof Relatorio === 'undefined') return;

  /* popula select de pacientes gerais quando a aba carrega */
  const _origInit = Relatorio.init?.bind(Relatorio);
  Relatorio.init = function() {
    _origInit?.();
    const sel = document.getElementById('rel-patient-select');
    if (!sel) return;
    const pts = DB.getPatients().sort((a, b) => a.name.localeCompare(b.name));
    sel.innerHTML =
      '<option value="">— Paciente Geral —</option>' +
      pts.map(p => `<option value="pat:${p.id}">${F.esc(p.name)}</option>`).join('');
  };

  /* salva vinculando ao tipo correto */
  Relatorio.save = function() {
    if (!this._lastReport) { UI.toast('Gere um relatório primeiro.', 'error'); return; }

    /* caso IMS */
    if (this._imsCase) {
      DB.addReport({
        id: Utils.uid(), imsId: this._imsCase.id, patientId: null,
        patientName: this._imsCase.name, text: this._lastReport, mode: 'saved', at: Date.now(),
      });
      UI.toast('Relatório salvo para ' + this._imsCase.name + ' (IMS)!');
      return;
    }

    /* paciente geral */
    const sel = document.getElementById('rel-patient-select');
    if (sel && sel.value && sel.value.startsWith('pat:')) {
      const id = sel.value.split(':')[1];
      const pt = DB.getPatient(id);
      if (pt) {
        DB.addReport({
          id: Utils.uid(), imsId: null, patientId: id,
          patientName: pt.name, text: this._lastReport, mode: 'saved', at: Date.now(),
        });
        UI.toast('Relatório salvo para ' + pt.name + ' (Geral)!');
        return;
      }
    }
    UI.toast('Selecione um caso IMS ou um paciente geral antes de salvar.', 'error');
  };
});

console.log('SAS v4.3 — patch definitivo carregado ✓');

/* ═══════════════════════════════════════════════════════════════
   SAS v4.3 — PATCH FINAL COMPLETO
   1) Marca d'água no timbrado
   2) IA de Ofício com 3 engines (ChatGPT · Gemini · Claude) + palavras-chave
   3) Impressão profissional centralizada com marca d'água
   ═══════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════
   WATERMARK — Marca d'água
══════════════════════════════════════════════ */
const Watermark = {
  _type: 'text', // 'text' | 'image' | 'none'
  _imgSrc: null,

  setType(t) { this._type = t; },

  getData() {
    return {
      type:       this._type,
      text:       document.getElementById('wm-text')?.value || 'PREFEITURA DE ITAPAJÉ',
      color:      document.getElementById('wm-color')?.value || '#2d7d32',
      opacity:    parseInt(document.getElementById('wm-opacity')?.value || '10') / 100,
      angle:      parseInt(document.getElementById('wm-angle')?.value || '-35'),
      imgSrc:     this._imgSrc,
      imgOpacity: parseInt(document.getElementById('wm-img-opacity')?.value || '12') / 100,
    };
  },

  /* HTML inline para inserir dentro do doc-a4 na impressão */
  buildHTMLLayer(d) {
    if (!d || d.type === 'none') return '';
    if (d.type === 'image' && d.imgSrc) {
      return `<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:0;overflow:hidden">
        <img src="${d.imgSrc}" style="max-width:60%;max-height:60%;object-fit:contain;opacity:${d.imgOpacity};transform:rotate(${d.angle || -35}deg)">
      </div>`;
    }
    if (d.type === 'text' && d.text) {
      return `<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:0;overflow:hidden">
        <div style="color:${d.color};opacity:${d.opacity};font-size:52pt;font-weight:bold;white-space:nowrap;transform:rotate(${d.angle}deg);font-family:'Times New Roman',serif;letter-spacing:4px;user-select:none">${d.text}</div>
      </div>`;
    }
    return '';
  },

  /* Preview no editor */
  renderPreview(d) {
    const el = document.getElementById('lh-preview-watermark');
    if (!el) return;
    if (!d || d.type === 'none') { el.innerHTML = ''; return; }
    if (d.type === 'image' && d.imgSrc) {
      el.innerHTML = `<img src="${d.imgSrc}" style="max-width:55%;max-height:55%;object-fit:contain;opacity:${d.imgOpacity};transform:rotate(${d.angle || -35}deg)">`;
    } else if (d.type === 'text' && d.text) {
      el.innerHTML = `<div style="color:${d.color};opacity:${d.opacity};font-size:13pt;font-weight:bold;white-space:nowrap;transform:rotate(${d.angle}deg);letter-spacing:2px">${d.text}</div>`;
    }
  },
};

/* ── Patch Letterhead para marca d'água ── */
window.addEventListener('load', () => {
  if (typeof Letterhead === 'undefined') return;

  Letterhead.setWMType = function(tipo, btn) {
    Watermark.setType(tipo);
    document.querySelectorAll('.wm-tab').forEach(b => b.classList.remove('active'));
    btn?.classList.add('active');
    document.getElementById('wm-text-panel').style.display  = tipo === 'text'  ? '' : 'none';
    document.getElementById('wm-image-panel').style.display = tipo === 'image' ? '' : 'none';
    this.preview();
  };

  Letterhead.uploadWatermarkImage = function(input) {
    const file = input.files[0]; if (!file) return;
    if (file.size > 500 * 1024) { UI.toast('Imagem muito grande. Máx: 500KB', 'error'); return; }
    const reader = new FileReader();
    reader.onload = e => {
      Watermark._imgSrc = e.target.result;
      document.getElementById('wm-img-preview').innerHTML = `<img src="${e.target.result}" style="max-width:100%;max-height:80px;object-fit:contain">`;
      this.preview();
    };
    reader.readAsDataURL(file);
  };

  Letterhead.removeWatermarkImage = function() {
    Watermark._imgSrc = null;
    document.getElementById('wm-img-preview').innerHTML = '<span>Clique para carregar<br><small>PNG transparente · máx 500KB</small></span>';
    document.getElementById('wm-img-input').value = '';
    this.preview();
  };

  /* Patch preview para incluir marca d'água */
  const _origPreview = Letterhead.preview?.bind(Letterhead);
  Letterhead.preview = function() {
    _origPreview?.();
    const wmd = Watermark.getData();
    Watermark.renderPreview(wmd);
  };

  /* Patch getLH e saveLH para incluir dados de marca d'água */
  const _origSave = Letterhead.save?.bind(Letterhead);
  Letterhead.save = function() {
    _origSave?.();
    const wmd = Watermark.getData();
    const lh = DB.getLH(); lh.watermark = wmd; DB.saveLH(lh);
    UI.toast('Timbrado com marca d\'água salvo!');
  };

  const _origInit = Letterhead.init?.bind(Letterhead);
  Letterhead.init = function() {
    _origInit?.();
    const lh = DB.getLH();
    if (lh.watermark) {
      const wm = lh.watermark;
      Watermark._type = wm.type || 'none';
      Watermark._imgSrc = wm.imgSrc || null;
      if (document.getElementById('wm-text'))        document.getElementById('wm-text').value = wm.text || 'PREFEITURA DE ITAPAJÉ';
      if (document.getElementById('wm-color'))       document.getElementById('wm-color').value = wm.color || '#2d7d32';
      if (document.getElementById('wm-opacity'))     document.getElementById('wm-opacity').value = Math.round((wm.opacity||0.10)*100);
      if (document.getElementById('wm-angle'))       document.getElementById('wm-angle').value = wm.angle ?? -35;
      if (document.getElementById('wm-img-opacity')) document.getElementById('wm-img-opacity').value = Math.round((wm.imgOpacity||0.12)*100);
      if (wm.imgSrc && document.getElementById('wm-img-preview')) {
        document.getElementById('wm-img-preview').innerHTML = `<img src="${wm.imgSrc}" style="max-width:100%;max-height:80px;object-fit:contain">`;
      }
      // atualiza abas
      const tabMap = { text:'wm-tab-text', image:'wm-tab-image', none:'wm-tab-none' };
      document.querySelectorAll('.wm-tab').forEach(b => b.classList.remove('active'));
      document.getElementById(tabMap[wm.type] || 'wm-tab-none')?.classList.add('active');
      document.getElementById('wm-text-panel').style.display  = wm.type === 'text'  ? '' : 'none';
      document.getElementById('wm-image-panel').style.display = wm.type === 'image' ? '' : 'none';
      this.preview();
    }
  };
});

/* ══════════════════════════════════════════════
   IA OFÍCIO — 3 engines com prompts profissionais
══════════════════════════════════════════════ */
const AIOficio = {
  _engine: 'chatgpt', // 'chatgpt' | 'gemini' | 'claude'

  /* Palavras-chave por categoria para inserção rápida */
  keywords: {
    objetivo:     ['Solicitar','Encaminhar','Comunicar','Informar','Requerer','Notificar','Convocar','Autorizar','Recomendar'],
    juridico:     ['Em conformidade com','Nos termos do Art.','Lei Municipal nº 2.399/2025','Decreto nº 49/2025','conforme legislação vigente','em atendimento ao disposto em'],
    encerramento: ['Coloco-me à disposição','Aguardo retorno no prazo de','Certos de contar com a colaboração','Sem mais para o momento','Atenciosamente','Respeitosamente'],
    contexto:     ['situação de vulnerabilidade social','demanda reprimida','acesso gratuito ao procedimento','paciente de baixa renda','Programa Itapajé Mais Saúde','Sistema Único de Saúde — SUS'],
  },

  /* Prompts prontos para cada engine */
  prompts: {
    chatgpt: (campos) => `Você é um especialista em redação oficial de documentos públicos brasileiros.

Gere um OFÍCIO formal seguindo rigorosamente as normas do Manual de Redação da Presidência da República (3ª edição) e as diretrizes da Secretaria Municipal de Saúde de Itapajé/CE.

DADOS FORNECIDOS:
- Destinatário: ${campos.dest || '[INFORMAR]'}
- Cargo do destinatário: ${campos.destCargo || '[INFORMAR]'}
- Assunto: ${campos.assunto || '[INFORMAR]'}
- Observações: ${campos.obs || '(sem observações adicionais)'}

REGRAS OBRIGATÓRIAS:
1. Formato: OFÍCIO Nº [número]/[ano] – APOIO SOCIAL
2. Local e data: Itapajé/CE, [dia] de [mês] de [ano]
3. Tom: formal, objetivo e jurídico
4. 3 parágrafos numerados: (1) Cumprimento + objetivo, (2) Desenvolvimento com fundamentação legal, (3) Conclusão + disposição para contato
5. Fecho: Atenciosamente
6. Assinatura: Francisco Maílson de Sousa Moreira — Gerente de Apoio Social — Secretaria Municipal de Saúde — Itapajé/CE — Tel.: (85) 9 9126-4880 — saude@itapaje.ce.gov.br
7. Se faltar informação, use [INFORMAR] em negrito
8. Não use jargões, siglas sem explicação ou linguagem informal

Gere APENAS o texto do ofício, sem explicações ou comentários.`,

    gemini: (campos) => `Contexto: Você é assistente de redação oficial da Secretaria Municipal de Saúde de Itapajé/CE, especializado em documentos públicos formais conforme as normas brasileiras de redação oficial.

Tarefa: Crie um ofício formal e profissional com os seguintes dados:
• Número: próximo disponível / Ano: ${new Date().getFullYear()} / Setor: APOIO SOCIAL
• Destinatário: ${campos.dest || '[INFORMAR]'} — ${campos.destCargo || '[INFORMAR]'}
• Assunto principal: ${campos.assunto || '[INFORMAR]'}
• Contexto adicional: ${campos.obs || 'Documento da Secretaria Municipal de Saúde de Itapajé/CE'}

Estrutura obrigatória:
1. Cabeçalho: OFÍCIO Nº ___/2026 – APOIO SOCIAL
2. Data e local: Itapajé/CE, [data por extenso]
3. Endereçamento formal (Ao Senhor(a) / cargo / instituição)
4. Assunto em destaque
5. Vocativo adequado ao cargo
6. § 1 — Cumprimento cordial + apresentação do objetivo
7. § 2 — Fundamentação e desenvolvimento (cite ${campos.lei || 'legislação vigente'} se pertinente)
8. § 3 — Conclusão reforçando solicitação + contato: (85) 9 9126-4880 / saude@itapaje.ce.gov.br
9. Fecho: Atenciosamente
10. Assinatura de Francisco Maílson de Sousa Moreira, Gerente de Apoio Social

Campos sem informação: usar [INFORMAR] destacado.
Responda APENAS com o texto do ofício, pronto para copiar e assinar.`,

    claude: (campos) => `<context>
Você é um especialista sênior em redação oficial de documentos públicos municipais brasileiros, com amplo conhecimento no Manual de Redação da Presidência da República e nas normas de comunicação oficial do Estado do Ceará.
</context>

<task>
Redigir um ofício oficial da Secretaria Municipal de Saúde do Município de Itapajé/CE, com tom formal, linguagem jurídico-administrativa precisa e estrutura padronizada.
</task>

<dados>
- Número do ofício: [próximo da série] / ${new Date().getFullYear()} / Setor: APOIO SOCIAL
- Destinatário: ${campos.dest || '[INFORMAR]'}
- Cargo: ${campos.destCargo || '[INFORMAR]'}
- Assunto: ${campos.assunto || '[INFORMAR]'}
- Contexto/observações: ${campos.obs || 'Ofício expedido pela Secretaria Municipal de Saúde de Itapajé/CE no âmbito do Programa Itapajé Mais Saúde (Lei Municipal nº 2.399/2025)'}
</dados>

<regras>
1. Siga fielmente o formato do Manual de Redação da Presidência da República
2. Use vocabulário formal e preciso — evite ambiguidades
3. Paragrafo 1: cumprimento + objetivo principal (1-2 frases diretas)
4. Parágrafo 2: fundamentação legal e desenvolvimento detalhado
5. Parágrafo 3: conclusão + contato (Tel.: (85) 9 9126-4880 / saude@itapaje.ce.gov.br)
6. Campos ausentes: [INFORMAR] em negrito
7. Assinatura: Francisco Maílson de Sousa Moreira · Gerente de Apoio Social · Secretaria Municipal de Saúde · Itapajé/CE
</regras>

<output>
Retorne APENAS o texto completo do ofício, formatado e pronto para impressão. Sem introduções, explicações ou metacomentários.
</output>`,
  },

  setEngine(e) { this._engine = e; },

  getPrompt(campos) { return this.prompts[this._engine]?.(campos) || this.prompts.chatgpt(campos); },

  openURL(prompt) {
    const enc = encodeURIComponent(prompt);
    const urls = {
      chatgpt: `https://chat.openai.com/?q=${enc}`,
      gemini:  `https://gemini.google.com/app?hl=pt-BR`,
      claude:  `https://claude.ai/new?q=${enc}`,
    };
    // Para Gemini não passamos direto pois a URL não suporta query direta — copia para área de transferência
    if (this._engine === 'gemini') {
      navigator.clipboard.writeText(prompt).then(() => {
        UI.toast('Prompt copiado! Cole no Gemini (Ctrl+V)', 'success');
        window.open('https://gemini.google.com/app?hl=pt-BR', '_blank');
      });
    } else {
      navigator.clipboard.writeText(prompt).then(() => {}).catch(() => {});
      window.open(urls[this._engine], '_blank');
      UI.toast('Prompt copiado! Cole no chat se necessário.');
    }
  },
};

/* ── Painel de IA de Ofício — injeta na aba Ofícios ── */
window.addEventListener('load', () => {
  // Encontra o formulário de ofício e injeta o painel IA
  const bodyField = document.getElementById('oficio-body');
  if (!bodyField) return;
  const parent = bodyField.closest('.form-group');
  if (!parent) return;

  // Cria painel IA antes do textarea
  const panel = document.createElement('div');
  panel.className = 'ai-oficio-panel';
  panel.id = 'ai-oficio-panel';
  panel.innerHTML = `
    <div class="ai-oficio-label">🤖 Assistente IA — Escolha o modelo e clique para gerar o prompt</div>
    <div class="ai-engine-tabs">
      <button class="ai-engine-tab tab-gpt active" onclick="AIOficio.setEngine('chatgpt');this.closest('.ai-engine-tabs').querySelectorAll('.ai-engine-tab').forEach(b=>b.classList.remove('active'));this.classList.add('active');AIOficio_updatePromptPreview()">
        <span>🟢</span> ChatGPT
      </button>
      <button class="ai-engine-tab tab-gemini" onclick="AIOficio.setEngine('gemini');this.closest('.ai-engine-tabs').querySelectorAll('.ai-engine-tab').forEach(b=>b.classList.remove('active'));this.classList.add('active');AIOficio_updatePromptPreview()">
        <span>🔵</span> Gemini
      </button>
      <button class="ai-engine-tab tab-claude" onclick="AIOficio.setEngine('claude');this.closest('.ai-engine-tabs').querySelectorAll('.ai-engine-tab').forEach(b=>b.classList.remove('active'));this.classList.add('active');AIOficio_updatePromptPreview()">
        <span>🟠</span> Claude
      </button>
    </div>

    <div style="font-size:11px;font-weight:600;text-transform:uppercase;color:var(--green-dark);margin-bottom:4px">Palavras-chave — clique para inserir no campo Assunto:</div>
    <div id="ai-keywords-area" class="ai-keywords-grid"></div>

    <div style="font-size:11px;font-weight:600;text-transform:uppercase;color:var(--green-dark);margin:.5rem 0 4px">Prompt gerado para a IA:</div>
    <div class="ai-prompt-box" id="ai-prompt-preview">Preencha Destinatário e Assunto para ver o prompt.</div>

    <div style="display:flex;gap:8px;margin-top:.5rem">
      <button class="btn-green" style="flex:1" onclick="AIOficio_openIA()">🚀 Abrir IA com Prompt</button>
      <button class="btn-outline" style="flex:1" onclick="AIOficio_copyPrompt()">📋 Copiar Prompt</button>
    </div>
    <div style="font-size:11px;color:var(--text-muted);margin-top:.5rem">1. Clique em "Abrir IA" → 2. Cole o texto gerado no campo abaixo → 3. Clique em "Salvar Ofício"</div>`;

  parent.before(panel);

  // Popula palavras-chave
  const kgrid = document.getElementById('ai-keywords-area');
  if (kgrid) {
    Object.entries(AIOficio.keywords).forEach(([cat, words]) => {
      words.forEach(w => {
        const btn = document.createElement('button');
        btn.className = 'ai-keyword';
        btn.textContent = w;
        btn.onclick = () => {
          const assEl = document.getElementById('oficio-subject');
          if (assEl) { assEl.value = (assEl.value ? assEl.value + ' — ' : '') + w; AIOficio_updatePromptPreview(); }
        };
        kgrid.appendChild(btn);
      });
    });
  }

  // Observa mudanças nos campos para atualizar preview do prompt
  ['oficio-dest','oficio-dest-cargo','oficio-subject'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', AIOficio_updatePromptPreview);
  });
});

function AIOficio_getCampos() {
  return {
    dest:     document.getElementById('oficio-dest')?.value?.trim() || '',
    destCargo:document.getElementById('oficio-dest-cargo')?.value?.trim() || '',
    assunto:  document.getElementById('oficio-subject')?.value?.trim() || '',
    obs:      document.getElementById('oficio-body')?.value?.trim() || '',
    lei:      'Lei Municipal nº 2.399/2025',
  };
}

function AIOficio_updatePromptPreview() {
  const prev = document.getElementById('ai-prompt-preview'); if (!prev) return;
  const campos = AIOficio_getCampos();
  if (!campos.dest && !campos.assunto) { prev.textContent = 'Preencha Destinatário e Assunto para ver o prompt.'; return; }
  prev.textContent = AIOficio.getPrompt(campos).slice(0, 600) + '...';
}

function AIOficio_openIA() {
  const campos = AIOficio_getCampos();
  if (!campos.dest && !campos.assunto) { UI.toast('Preencha ao menos o Destinatário ou o Assunto.', 'error'); return; }
  AIOficio.openURL(AIOficio.getPrompt(campos));
}

function AIOficio_copyPrompt() {
  const campos = AIOficio_getCampos();
  const prompt = AIOficio.getPrompt(campos);
  navigator.clipboard.writeText(prompt).then(() => UI.toast('Prompt completo copiado!')).catch(() => UI.toast('Erro ao copiar.', 'error'));
}

/* ══════════════════════════════════════════════
   IMPRESSÃO PROFISSIONAL — patch _buildHeader/_buildFooter + marca d'água
══════════════════════════════════════════════ */
window.addEventListener('load', () => {
  if (typeof PrintMod === 'undefined') return;

  /* Override _buildHeader para texto mais profissional e centralizado */
  PrintMod._buildHeader = function(lh) {
    const align = lh.align || 'center';
    const posMap = { left:'left', center:'center', right:'right' };
    let h = `<div style="padding:8mm 15mm 0">`;
    if (lh.image) {
      h += `<div style="text-align:${posMap[lh.imgPos||'left']};margin-bottom:5px">
              <img src="${lh.image}" style="max-height:62px;object-fit:contain" alt="Logo">
            </div>`;
    }
    if (lh.line1) h += `<div style="text-align:${align};font-family:'Times New Roman',serif;font-size:13pt;font-weight:bold;text-transform:uppercase;letter-spacing:1px;color:#000">${lh.line1}</div>`;
    if (lh.line2) h += `<div style="text-align:${align};font-family:'Times New Roman',serif;font-size:11pt;color:#222;margin-top:1px">${lh.line2}</div>`;
    if (lh.line3) h += `<div style="text-align:${align};font-family:'Times New Roman',serif;font-size:10pt;color:#444;margin-top:1px">${lh.line3}</div>`;
    h += `</div>`;
    h += `<div style="height:3px;margin:4px 15mm 0;background:${lh.accentColor||'#2d7d32'}"></div>`;
    return h;
  };

  /* Override _buildFooter com contatos centralizados e profissionais */
  PrintMod._buildFooter = function(lh, r) {
    const l1 = lh.footer1 || (r.unitAddress || 'R. São Francisco, Nº 225 – Centro, Itapajé/CE');
    const l2 = lh.footer2 || (`Tel.: ${r.unitPhone||'(85) 9 9126-4880'} · saude@itapaje.ce.gov.br · www.itapaje.ce.gov.br`);
    const l3 = lh.footer3 || '';
    const legal = lh.legal || '';
    return `<div style="padding:4mm 15mm 6mm;border-top:1px solid #aaa;font-family:'Times New Roman',serif;font-size:8.5pt;color:#444;text-align:center;line-height:1.6">
      <div>${l1}</div>
      ${l2?`<div>${l2}</div>`:''}
      ${l3?`<div>${l3}</div>`:''}
      ${legal?`<div style="margin-top:2px;font-style:italic;font-size:7.5pt;color:#888">${legal}</div>`:''}
    </div>`;
  };

  /* Override _printWin para incluir marca d'água no CSS de impressão */
  const _origPrintWin = PrintMod._printWin?.bind(PrintMod);
  PrintMod._printWin = function(html, title) {
    const lh = DB.getLH();
    const wm = lh.watermark || {};
    let wmCSS = '';
    if (wm.type === 'text' && wm.text) {
      wmCSS = `.doc-wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(${wm.angle||'-35'}deg);font-size:72pt;font-weight:bold;color:${wm.color||'#2d7d32'};opacity:${wm.opacity||0.10};white-space:nowrap;pointer-events:none;z-index:0;font-family:'Times New Roman',serif;letter-spacing:4px}`;
    } else if (wm.type === 'image' && wm.imgSrc) {
      wmCSS = `.doc-wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(${wm.angle||'-35'}deg);max-width:60%;max-height:60%;opacity:${wm.imgOpacity||0.12};pointer-events:none;z-index:0}`;
    }
    const wmEl = (wm.type === 'text' && wm.text)
      ? `<div class="doc-wm">${wm.text}</div>`
      : (wm.type === 'image' && wm.imgSrc)
        ? `<img class="doc-wm" src="${wm.imgSrc}">`
        : '';

    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
      <title>${title||'SAS — Itapajé Mais Saúde'}</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Times New Roman',Times,serif;background:#fff;font-size:11.5pt;position:relative}
        ${wmCSS}
        .doc-a4{width:210mm;min-height:297mm;page-break-after:always;margin:0 auto;display:grid;grid-template-rows:auto 1fr auto;background:#fff;position:relative}
        .doc-a4:last-child{page-break-after:avoid}
        .doc-content{padding:6mm 15mm 4mm;position:relative;z-index:1}
        .doc-subject{text-align:center;font-size:12.5pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin:6px 0 12px;letter-spacing:.5px}
        .doc-section-hd{font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:4px 9px;margin:8px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32;letter-spacing:.4px}
        .doc-table{width:100%;border-collapse:collapse;margin-bottom:7px;font-size:10.5pt}
        .doc-table td{padding:4px 8px;border:.5px solid #ccc;vertical-align:top}
        .lbl{font-weight:bold;background:#f5f5f5;width:40%}
        .doc-body{font-size:11pt;line-height:1.95;text-align:justify;text-indent:1.2cm;margin:5px 0}
        .doc-body-ni{font-size:11pt;line-height:1.95;text-align:justify;margin:5px 0}
        .doc-auth-box{text-align:center;margin:10mm 0 6mm;padding:7px 0;border:1.5px solid #2d7d32;font-size:13pt;font-weight:bold;text-transform:uppercase;background:#e8f5e9;letter-spacing:1px}
        .doc-sign-grid{display:grid;gap:36px;margin-top:12mm}
        .doc-sign-blk{text-align:center}
        .doc-sign-ln{border-top:1px solid #000;padding-top:5px;font-size:10.5pt;font-weight:bold}
        .doc-sign-sub{font-size:9.5pt;color:#333;line-height:1.5}
        .doc-local-date{text-align:right;font-size:10.5pt;font-style:italic;margin:6px 0 10px}
        .doc-ref-box{background:#e8f5e9;border:1px solid #2d7d32;padding:6px 12px;font-size:10.5pt;margin:8px 0;border-radius:4px}
        .doc-info-box{background:#e8f5e9;border:1.5px solid #2d7d32;padding:7px 13px;font-size:10.5pt;margin:10px 0;text-align:center}
        .doc-capa-title{text-align:center;font-size:13pt;font-weight:bold;text-transform:uppercase;line-height:1.5;margin-bottom:8mm}
        .doc-capa-box{border:2px solid #2d7d32;padding:8mm 14mm;background:#f9fff9;text-align:center;margin:8mm 0}
        .doc-of-badge{display:inline-block;background:#1b5e20;color:#fff;font-size:8.5pt;padding:2px 10px;border-radius:3px;text-transform:uppercase;letter-spacing:1.5px}
        @media print{@page{size:A4;margin:0}.doc-wm{position:fixed}}
      </style>
    </head><body>${wmEl}${html}</body></html>`);
    win.document.close(); win.focus();
    setTimeout(() => win.print(), 700);
  };

  /* Re-patch IMS3P para usar novo formato de impressão */
  if (typeof IMS3P !== 'undefined') {
    /* Override pag2 para texto mais profissional e centralizado */
    const _origPag2 = IMS3P.pagCadastroParecer?.bind(IMS3P);
    IMS3P.pagCadastroParecer = function(c, lh, r, textoRelatorio) {
      const parecer = textoRelatorio ||
        `Após entrevista e análise documental realizada pelo Serviço Social desta ${r.unit||'Secretaria Municipal de Saúde de Itapajé/CE'}, constatou-se que o(a) paciente <strong>${c.name}</strong>, ` +
        `residente ${c.address?'em '+c.address+', '+c.neighborhood+',':''} no Município de Itapajé/${(typeof C!=='undefined'?C.uf:'CE')}, apresenta situação de vulnerabilidade socioeconômica ` +
        (c.income?`, com renda familiar declarada de R$ ${c.income} (${c.incomeRange}),`:'') +
        ` o que o(a) torna elegível aos benefícios da Lei Municipal nº 2.399, de 15 de abril de 2025, e do Decreto nº 49, de 30 de maio de 2025.`;

      const regulacao = c.regulation ||
        `O(A) paciente encontra-se em fila de espera no Sistema de Regulação do Estado do Ceará (SISREG), ` +
        `sem previsão de agendamento pelo Sistema Único de Saúde (SUS), tendo sido encaminhado(a) pelo médico ` +
        `assistente para realização de procedimento especializado em estabelecimento de saúde de maior complexidade.`;

      return `<div class="doc-a4">${this._hdr?.(lh)||PrintMod._buildHeader(lh)}
        <div class="doc-content">
          <div class="doc-subject">Cadastro de Atendimento e Parecer Social</div>
          <div class="doc-ref-box"><strong>Nº:</strong> ${c.solicitNum} &nbsp;|&nbsp; <strong>Data:</strong> ${(typeof F!=='undefined'?F.data(c.date):'—')} &nbsp;|&nbsp; <strong>Procedimento:</strong> ${(c.procedure||'').toUpperCase()}</div>
          <div class="doc-body-ni" style="margin-bottom:8px"><strong>OBJETIVO:</strong> Subsidiar tecnicamente a análise da solicitação de procedimento pelo Programa Itapajé Mais Saúde, conforme previsto na Lei Municipal nº 2.399/2025 e no Decreto nº 49/2025.</div>

          <div class="doc-section-hd">1. Perfil Socioeconômico do Beneficiário</div>
          <table class="doc-table">
            ${this._row?.('Nome completo',c.name)||''}
            ${this._row?.('Data de Nascimento',(typeof F!=='undefined'?F.data(c.birth):c.birth)+((typeof F!=='undefined'&&F.idade(c.birth))?' ('+F.idade(c.birth)+')':''))||''}
            ${this._row?.('Endereço',(c.address||'[INFORMAR]')+', '+(c.neighborhood||'')+', Itapajé/CE')||''}
            ${c.reference?this._row?.('Ponto de referência',c.reference)||'':''}
            ${this._row?.('Renda Familiar','R$ '+(c.income||'[INFORMAR]')+' — '+(c.incomeRange||''))||''}
            ${this._row?.('Situação Habitacional',(c.housing||'[INFORMAR]')+(c.services?' · '+c.services:''))||''}
            ${this._row?.('CPF',c.cpf||'[INFORMAR]')||''}
            ${this._row?.('Telefone',c.phone)||''}
            ${this._row?.('Composição Familiar / Mãe',(c.mother||'[INFORMAR]')+(c.motherProf?' — '+c.motherProf:''))||''}
            ${this._row?.('Profissão',c.profession||'[INFORMAR]')||''}
            ${this._row?.('Escolaridade',c.education||'[INFORMAR]')||''}
          </table>

          <div class="doc-section-hd">2. Parecer Técnico do Serviço Social</div>
          <div class="doc-body">${(typeof F!=='undefined'?F.esc(parecer):parecer)}</div>
          <div class="doc-body">${(typeof F!=='undefined'?F.esc(regulacao):regulacao)}</div>

          <div class="doc-section-hd">3. Regularidade dos Critérios de Elegibilidade</div>
          <table class="doc-table" style="margin-bottom:10px">
            <tr><td class="lbl">Residência em Itapajé/CE</td><td>${c.eligResident?'✅ Confirmado':'❌ Não confirmado'}</td></tr>
            <tr><td class="lbl">Renda ≤ 2 salários mínimos</td><td>${c.eligIncome?'✅ Confirmado':'❌ Não confirmado'}</td></tr>
            <tr><td class="lbl">Fila SUS sem previsão (SISREG)</td><td>${c.eligFila?'✅ Confirmado':'❌ Não confirmado'}</td></tr>
            <tr><td class="lbl">Indicação médica para o procedimento</td><td>${c.eligIndicacao?'✅ Confirmado':'❌ Não confirmado'}</td></tr>
            <tr><td class="lbl">Documentação completa apresentada</td><td>${c.eligDocs?'✅ Confirmado':'❌ Não confirmado'}</td></tr>
          </table>

          <div class="doc-info-box"><strong>CONCLUSÃO:</strong> O Serviço Social desta Secretaria manifesta parecer <strong>FAVORÁVEL</strong> à inclusão do(a) beneficiário(a) no Programa Itapajé Mais Saúde, estando preenchidos os requisitos estabelecidos na Lei Municipal nº 2.399/2025.</div>

          <div class="doc-local-date">Itapajé – CE, ${(typeof F!=='undefined'?F.hoje():'—')}.</div>
          ${this._s2?.(r)||''}
        </div>
        ${this._ftr?.(lh,r)||PrintMod._buildFooter(lh,r)}</div>`;
    };
  }
});

console.log('SAS v4.3 — Watermark · AI Ofício 3 engines · Impressão profissional ✓');

/* ═══════════════════════════════════════════════════════════════
   SAS v4.4 — PATCH FINAL
   1) Fix botão imprimir em TODOS os modos de visualização
   2) Módulo Ouvidoria da Saúde completo
   ═══════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════
   FIX PRINT — corrige impressão em todos os modos
══════════════════════════════════════════════ */

/* Função global de impressão — chamada pelo botão do modal */
function globalPrint() {
  const content = document.getElementById('print-preview-content');
  if (!content || !content.innerHTML.trim()) {
    UI.toast('Nenhum conteúdo para imprimir.', 'error');
    return;
  }
  // Busca dados do timbrado e marca d'água
  const lh = (typeof DB !== 'undefined') ? DB.getLH() : {};
  const wm = lh.watermark || {};

  let wmCSS = '', wmEl = '';
  if (wm.type === 'text' && wm.text) {
    wmCSS = `.doc-wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(${wm.angle||'-35'}deg);font-size:72pt;font-weight:bold;color:${wm.color||'#2d7d32'};opacity:${wm.opacity||0.10};white-space:nowrap;pointer-events:none;z-index:0;font-family:'Times New Roman',serif;letter-spacing:4px}`;
    wmEl = `<div class="doc-wm">${wm.text}</div>`;
  } else if (wm.type === 'image' && wm.imgSrc) {
    wmCSS = `.doc-wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(${wm.angle||'-35'}deg);max-width:60%;max-height:60%;opacity:${wm.imgOpacity||0.12};pointer-events:none;z-index:0}`;
    wmEl = `<img class="doc-wm" src="${wm.imgSrc}">`;
  }

  const win = window.open('', '_blank');
  win.document.write(`<!DOCTYPE html><html lang="pt-BR"><head>
    <meta charset="UTF-8"><title>SAS — Impressão — Itapajé/CE</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Times New Roman',Times,serif;background:#fff;font-size:11.5pt;color:#000;position:relative}
      ${wmCSS}
      .doc-a4{width:210mm;min-height:297mm;page-break-after:always;margin:0 auto;display:grid;grid-template-rows:auto 1fr auto;background:#fff;position:relative}
      .doc-a4:last-child{page-break-after:avoid}
      .doc-content{padding:6mm 15mm 4mm;position:relative;z-index:1}
      .doc-subject{text-align:center;font-size:12.5pt;font-weight:bold;text-transform:uppercase;border-bottom:2px solid #000;padding-bottom:6px;margin:6px 0 12px;letter-spacing:.5px}
      .doc-section-hd{font-weight:bold;font-size:10.5pt;background:#e8f5e9;padding:4px 9px;margin:8px 0 5px;text-transform:uppercase;border-left:4px solid #2d7d32;letter-spacing:.4px}
      .doc-table{width:100%;border-collapse:collapse;margin-bottom:7px;font-size:10.5pt}
      .doc-table td{padding:4px 8px;border:.5px solid #ccc;vertical-align:top}
      .lbl{font-weight:bold;background:#f5f5f5;width:40%}
      .doc-body{font-size:11pt;line-height:1.95;text-align:justify;text-indent:1.2cm;margin:5px 0}
      .doc-body-ni{font-size:11pt;line-height:1.95;text-align:justify;margin:5px 0}
      .doc-auth-box{text-align:center;margin:10mm 0 6mm;padding:7px 0;border:1.5px solid #2d7d32;font-size:13pt;font-weight:bold;text-transform:uppercase;background:#e8f5e9;letter-spacing:1px}
      .doc-sign-grid{display:grid;gap:36px;margin-top:12mm}
      .doc-sign-blk,.doc-sign-block{text-align:center}
      .doc-sign-ln,.doc-sign-line-top{border-top:1px solid #000;padding-top:5px;font-size:10.5pt;font-weight:bold}
      .doc-sign-sub{font-size:9.5pt;color:#333;line-height:1.5}
      .doc-local-date{text-align:right;font-size:10.5pt;font-style:italic;margin:6px 0 10px}
      .doc-ref-box{background:#e8f5e9;border:1px solid #2d7d32;padding:6px 12px;font-size:10.5pt;margin:8px 0;border-radius:4px}
      .doc-info-box{background:#e8f5e9;border:1.5px solid #2d7d32;padding:7px 13px;font-size:10.5pt;margin:10px 0;text-align:center}
      .doc-capa-title{text-align:center;font-size:13pt;font-weight:bold;text-transform:uppercase;line-height:1.5;margin-bottom:8mm}
      .doc-capa-box{border:2px solid #2d7d32;padding:8mm 14mm;background:#f9fff9;text-align:center;margin:8mm 0}
      .doc-of-badge{display:inline-block;background:#1b5e20;color:#fff;font-size:8.5pt;padding:2px 10px;border-radius:3px;text-transform:uppercase;letter-spacing:1.5px}
      .batch-summary-table{width:100%;border-collapse:collapse;margin:8px 0}
      .batch-summary-table th{background:#2d7d32;color:#fff;padding:5px 8px;font-size:10pt;text-align:left}
      .batch-summary-table td{padding:4px 8px;border-bottom:.5px solid #ccc;font-size:10pt}
      .batch-summary-table tr:nth-child(even) td{background:#f5fff5}
      @media print{@page{size:A4;margin:0}.doc-wm{position:fixed}}
    </style>
  </head><body>${wmEl}${content.innerHTML}</body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 600);
}

/* Override PrintMod.doPrint — usado pelo botão do modal */
window.addEventListener('load', () => {
  if (typeof PrintMod !== 'undefined') {
    PrintMod.doPrint = function() { globalPrint(); };
  }
  // Também garante que o botão do modal funciona
  const btn = document.querySelector('.modal-header .btn-sm[onclick*="doPrint"]');
  if (btn) btn.onclick = globalPrint;
});

/* Garante que Oficios.printPreview cria conteúdo correto no modal */
window.addEventListener('load', () => {
  if (typeof Oficios === 'undefined') return;
  const _origOficiosPrint = Oficios.printPreview?.bind(Oficios);
  Oficios.printPreview = function() {
    // Chama o original que injeta HTML no modal
    const body = document.getElementById('oficio-body')?.value?.trim();
    if (!body) { UI.toast('Preencha ou gere o corpo do ofício primeiro.', 'error'); return; }
    // Chama o override que já existe (do patch_final.js)
    if (_origOficiosPrint) _origOficiosPrint();
    else {
      const lh = DB.getLH(), r = DB.getResp();
      if (typeof OficioABNT !== 'undefined' && typeof ABNT !== 'undefined') {
        const html = ABNT.paginaHTML({ num: document.getElementById('oficio-num')?.value||'', body, dest: document.getElementById('oficio-dest')?.value||'', destCargo: document.getElementById('oficio-dest-cargo')?.value||'', assunto: document.getElementById('oficio-subject')?.value||'', date: document.getElementById('oficio-date')?.value||'', local: document.getElementById('oficio-local')?.value||'', procDate: document.getElementById('oficio-proc-date')?.value||'', procTime: document.getElementById('oficio-proc-time')?.value||'' }, lh, r);
        document.getElementById('print-preview-content').innerHTML = html;
        UI.showModal('modal-print-preview');
      }
    }
  };
});

/* ══════════════════════════════════════════════
   OUVIDORIA DA SAÚDE — módulo completo
══════════════════════════════════════════════ */
const Ouvidoria = {
  _setor: 'Apoio Social',
  _isAdmin: false,
  _OUV_KEY: 'sas_ouvidoria_v1',
  _CFG_KEY: 'sas_ouvidoria_cfg',

  /* ── Banco de dados local ── */
  _getAll() { try { return JSON.parse(localStorage.getItem(this._OUV_KEY)||'[]'); } catch { return []; } },
  _saveAll(d) { localStorage.setItem(this._OUV_KEY, JSON.stringify(d)); },
  _getCfg() { try { return JSON.parse(localStorage.getItem(this._CFG_KEY)||'{}'); } catch { return {}; } },
  _saveCfg(d) { localStorage.setItem(this._CFG_KEY, JSON.stringify(d)); },

  _nextProtocol() {
    const y = new Date().getFullYear();
    const all = this._getAll().filter(x => x.protocolo?.includes('/'+y));
    return `OUV-${String(all.length+1).padStart(4,'0')}/${y}`;
  },

  /* ── Inicializa aba ── */
  init() {
    this._checkAdmin();
    this._loadConfig();
    this.renderList();
    this._updateStats();
    this._updateNavBadge();
    // Escuta mudança de unidade para mostrar campo "outra"
    document.getElementById('ouv-unidade')?.addEventListener('change', function() {
      const grp = document.getElementById('ouv-unidade-outra-group');
      if (grp) grp.style.display = this.value === 'Outra unidade' ? '' : 'none';
    });
  },

  _checkAdmin() {
    const session = (typeof DB !== 'undefined') ? DB.getSession() : null;
    const isAdmin = session && (session.user === 'mailson' || session.user === 'Mailson');
    this._isAdmin = isAdmin;
    const adminPanel  = document.getElementById('ouv-admin-panel');
    const configPanel = document.getElementById('ouv-config-panel');
    const listPanel   = document.getElementById('ouv-list-panel');
    const formSection = document.getElementById('ouv-form-section');
    if (isAdmin) {
      adminPanel?.classList.remove('hidden');
      configPanel?.classList.remove('hidden');
      listPanel?.classList.remove('hidden');
    }
    // Formulário público — sempre visível para todos
    formSection?.classList.remove('hidden');
  },

  _loadConfig() {
    const cfg = this._getCfg();
    const fields = {
      'ouv-group-link'    : cfg.groupLink    || '',
      'ouv-ouvidor-name'  : cfg.ouvidorName  || 'Francisco Maílson de Sousa Moreira',
      'ouv-ouvidor-email' : cfg.ouvidorEmail || 'ouvidoria@itapaje.ce.gov.br',
      'ouv-ouvidor-phone' : cfg.ouvidorPhone || '(85) 9 9126-4880',
    };
    Object.entries(fields).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) el.value = val;
    });
  },

  saveConfig() {
    this._saveCfg({
      groupLink   : document.getElementById('ouv-group-link')?.value    || '',
      ouvidorName : document.getElementById('ouv-ouvidor-name')?.value  || '',
      ouvidorEmail: document.getElementById('ouv-ouvidor-email')?.value || '',
      ouvidorPhone: document.getElementById('ouv-ouvidor-phone')?.value || '',
    });
    UI.toast('Configuração salva!');
  },

  selectSetor(btn) {
    document.querySelectorAll('.ouv-setor-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    this._setor = btn.getAttribute('data-setor') || 'Outro';
  },

  openForm() {
    // Limpa campos
    ['ouv-nome','ouv-funcionario','ouv-func-cargo','ouv-descricao'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    const idad = document.getElementById('ouv-idade'); if (idad) idad.value = '';
    const tel = document.getElementById('ouv-telefone'); if (tel) tel.value = '';
    const unid = document.getElementById('ouv-unidade'); if (unid) unid.value = '';
    const anon = document.getElementById('ouv-anonimo'); if (anon) anon.checked = false;
    document.querySelector('input[name="ouv-tipo"][value="Reclamação"]')?.click();
    document.querySelectorAll('.ouv-setor-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.ouv-setor-btn[data-setor="Apoio Social"]')?.classList.add('active');
    this._setor = 'Apoio Social';
    const succ = document.getElementById('ouv-success-msg'); if (succ) succ.classList.add('hidden');
    document.getElementById('ouv-form-section')?.scrollIntoView({ behavior:'smooth' });
  },

  submit() {
    const nome   = document.getElementById('ouv-nome')?.value?.trim();
    const idade  = document.getElementById('ouv-idade')?.value;
    const tel    = document.getElementById('ouv-telefone')?.value?.trim();
    const desc   = document.getElementById('ouv-descricao')?.value?.trim();
    const tipo   = document.querySelector('input[name="ouv-tipo"]:checked')?.value || 'Reclamação';

    if (!nome)  { UI.toast('Informe seu nome completo.', 'error'); document.getElementById('ouv-nome')?.focus(); return; }
    if (!idade) { UI.toast('Informe sua idade.', 'error'); document.getElementById('ouv-idade')?.focus(); return; }
    if (!tel)   { UI.toast('Informe seu telefone.', 'error'); document.getElementById('ouv-telefone')?.focus(); return; }
    if (!desc)  { UI.toast('Descreva sua manifestação.', 'error'); document.getElementById('ouv-descricao')?.focus(); return; }

    const unidade = document.getElementById('ouv-unidade')?.value;
    const unidadeOutra = document.getElementById('ouv-unidade-outra')?.value?.trim();
    const unidadeFinal = unidade === 'Outra unidade' ? (unidadeOutra || 'Outra') : (unidade || 'Não informada');
    const anonimo = document.getElementById('ouv-anonimo')?.checked || false;
    const func = document.getElementById('ouv-funcionario')?.value?.trim() || '';
    const funcCargo = document.getElementById('ouv-func-cargo')?.value?.trim() || '';

    const protocolo = this._nextProtocol();
    const registro = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2,5),
      protocolo,
      tipo,
      setor: this._setor,
      nome, idade: parseInt(idade), telefone: tel,
      unidade: unidadeFinal,
      funcionario: func, funcCargo,
      descricao: desc,
      anonimo,
      status: 'Pendente',
      criadoEm: Date.now(),
    };

    const all = this._getAll();
    all.unshift(registro);
    this._saveAll(all);

    // Exibe sucesso
    const succ = document.getElementById('ouv-success-msg');
    const protDisp = document.getElementById('ouv-protocolo-display');
    if (succ)    succ.classList.remove('hidden');
    if (protDisp) protDisp.textContent = `Protocolo: ${protocolo}`;
    succ?.scrollIntoView({ behavior: 'smooth' });

    this.renderList();
    this._updateStats();
    this._updateNavBadge();

    // Notifica grupo via WhatsApp se configurado
    this._notifyGroup(registro);
    UI.toast(`Manifestação registrada! Protocolo: ${protocolo}`, 'success');
  },

  _notifyGroup(reg) {
    const cfg = this._getCfg();
    if (!cfg.groupLink || !cfg.groupLink.includes('wa.me') && !cfg.groupLink.includes('t.me')) return;
    // Se for link WhatsApp, monta mensagem
    if (cfg.groupLink.includes('wa.me') || cfg.groupLink.includes('whatsapp')) {
      const msg =
        `📢 *NOVA MANIFESTAÇÃO — OUVIDORIA DA SAÚDE*\n` +
        `*Secretaria Municipal de Saúde — Itapajé/CE*\n\n` +
        `🔢 *Protocolo:* ${reg.protocolo}\n` +
        `📌 *Tipo:* ${reg.tipo}\n` +
        `🏥 *Setor:* ${reg.setor}\n` +
        `📅 *Data:* ${new Date(reg.criadoEm).toLocaleDateString('pt-BR')}\n` +
        (reg.anonimo ? '👤 *Cidadão:* Anônimo\n' : `👤 *Cidadão:* ${reg.nome}, ${reg.idade} anos\n`) +
        `🏨 *Unidade:* ${reg.unidade}\n` +
        (reg.funcionario ? `👔 *Func. citado:* ${reg.funcionario}${reg.funcCargo?' ('+reg.funcCargo+')':''}\n` : '') +
        `\n📝 *Manifestação:*\n${reg.descricao.slice(0,300)}${reg.descricao.length>300?'...':''}\n\n` +
        `_Para responder, acesse o sistema SAS — Itapajé/CE_`;
      // Abre o link sem redirecionar a página
      const phone = cfg.groupLink.replace(/\D/g,'').replace(/^55/,'');
      if (phone && phone.length >= 10) {
        // Link direto para o grupo
        window.open(cfg.groupLink, '_blank');
      }
    }
  },

  renderList() {
    const tb = document.getElementById('ouv-tbody');
    if (!tb) return;
    const filtro = document.getElementById('ouv-filter-tipo')?.value || 'all';
    let data = this._getAll();
    if (filtro !== 'all') data = data.filter(x => x.tipo === filtro);

    if (data.length === 0) {
      tb.innerHTML = '<tr class="empty-row"><td colspan="7">Nenhuma manifestação registrada.</td></tr>';
      return;
    }

    tb.innerHTML = data.map(r => `
      <tr>
        <td><span class="ouv-protocol-badge">${r.protocolo}</span></td>
        <td style="font-size:12px">${new Date(r.criadoEm).toLocaleDateString('pt-BR')}</td>
        <td><span class="ouv-badge-tipo ouv-badge-${r.tipo}">${r.tipo}</span></td>
        <td style="font-size:12px">${r.setor}</td>
        <td style="font-size:12px">${r.anonimo ? '<em>Anônimo</em>' : r.nome}</td>
        <td><span class="ouv-status-badge ouv-st-${r.status.toLowerCase().replace(/ /g,'')}">${r.status}</span></td>
        <td>
          <div class="table-actions">
            <button onclick="Ouvidoria.viewDetail('${r.id}')">Ver</button>
            <button onclick="Ouvidoria.updateStatus('${r.id}','Em andamento')">▶ Andamento</button>
            <button onclick="Ouvidoria.updateStatus('${r.id}','Concluído')">✓ Concluir</button>
            <button onclick="Ouvidoria.notifyWA('${r.id}')">📱 WA</button>
          </div>
        </td>
      </tr>`).join('');
  },

  _updateStats() {
    const all = this._getAll();
    const safe = (id, val) => { const el = document.getElementById(id); if (el) el.querySelector('span').textContent = val; };
    safe('ouv-stat-total', all.length);
    safe('ouv-stat-recl',  all.filter(x => x.tipo === 'Reclamação').length);
    safe('ouv-stat-sug',   all.filter(x => x.tipo === 'Sugestão').length);
    safe('ouv-stat-elog',  all.filter(x => x.tipo === 'Elogio').length);
    safe('ouv-stat-den',   all.filter(x => x.tipo === 'Denúncia').length);
    safe('ouv-stat-pend',  all.filter(x => x.status === 'Pendente').length);
  },

  _updateNavBadge() {
    const pending = this._getAll().filter(x => x.status === 'Pendente').length;
    const badge = document.getElementById('ouvidoria-badge');
    if (!badge) return;
    badge.textContent = pending;
    pending > 0 ? badge.classList.remove('hidden') : badge.classList.add('hidden');
  },

  updateStatus(id, status) {
    const all = this._getAll();
    const idx = all.findIndex(x => x.id === id);
    if (idx < 0) return;
    all[idx].status = status;
    all[idx].atualizadoEm = Date.now();
    this._saveAll(all);
    this.renderList();
    this._updateStats();
    this._updateNavBadge();
    UI.toast(`Status atualizado: ${status}`);
  },

  viewDetail(id) {
    const r = this._getAll().find(x => x.id === id);
    if (!r) return;
    const html = `
      <div style="padding:1.25rem;font-family:var(--font)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
          <span class="ouv-protocol-badge">${r.protocolo}</span>
          <span class="ouv-badge-tipo ouv-badge-${r.tipo}">${r.tipo}</span>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc;width:35%">Setor</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.setor}</td></tr>
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Cidadão</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.anonimo?'<em>Anônimo</em>':r.nome+', '+r.idade+' anos'}</td></tr>
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Telefone</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.anonimo?'—':r.telefone}</td></tr>
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Unidade</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.unidade}</td></tr>
          ${r.funcionario?`<tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Funcionário citado</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.funcionario}${r.funcCargo?' ('+r.funcCargo+')':''}</td></tr>`:''}
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Data</td><td style="padding:5px 8px;border:.5px solid #ccc">${new Date(r.criadoEm).toLocaleString('pt-BR')}</td></tr>
          <tr><td style="font-weight:600;padding:5px 8px;background:#f5f5f5;border:.5px solid #ccc">Status</td><td style="padding:5px 8px;border:.5px solid #ccc">${r.status}</td></tr>
        </table>
        <div style="margin-top:1rem;padding:.875rem;background:#f8faf8;border-radius:8px;border:1px solid #dde5dd">
          <div style="font-size:11.5px;font-weight:600;text-transform:uppercase;color:#2d7d32;margin-bottom:.5rem">Manifestação</div>
          <div style="font-size:13px;line-height:1.7;white-space:pre-wrap">${r.descricao}</div>
        </div>
        <div style="display:flex;gap:8px;margin-top:1rem;flex-wrap:wrap">
          <button class="btn-green" style="flex:1" onclick="Ouvidoria.updateStatus('${r.id}','Concluído');UI.closeModal('modal-ouv-detail')">✓ Marcar Concluído</button>
          ${!r.anonimo?`<button class="btn-whatsapp" style="flex:1" onclick="Ouvidoria.notifyWA('${r.id}')">📱 Responder via WhatsApp</button>`:''}
        </div>
      </div>`;
    document.getElementById('ouv-detail-body').innerHTML = html;
    document.getElementById('ouv-detail-title').textContent = `Manifestação — ${r.protocolo}`;
    UI.showModal('modal-ouv-detail');
  },

  notifyWA(id) {
    const r = this._getAll().find(x => x.id === id);
    if (!r || r.anonimo) { UI.toast('Manifestação anônima.', 'error'); return; }
    const phone = r.telefone.replace(/\D/g,'');
    if (!phone) { UI.toast('Sem telefone.', 'error'); return; }
    const msg =
      `Olá, *${r.nome}*! 👋\n\n` +
      `A *Ouvidoria da Saúde — Itapajé/CE* está respondendo à sua manifestação.\n\n` +
      `🔢 *Protocolo:* ${r.protocolo}\n` +
      `📌 *Tipo:* ${r.tipo}\n` +
      `🏥 *Setor:* ${r.setor}\n\n` +
      `📝 *Status atual:* ${r.status}\n\n` +
      `Em caso de dúvidas, entre em contato conosco:\n` +
      `📞 (85) 9 9126-4880\n` +
      `👤 Gerente de Apoio Social\n` +
      `*Francisco Maílson de Sousa Moreira*\n` +
      `Secretaria Municipal de Saúde — Itapajé/CE\n` +
      `_${new Date().toLocaleDateString('pt-BR')}_`;
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    UI.toast('WhatsApp aberto para ' + r.nome);
  },

  /* QR Code público — para exibir na secretaria */
  showQR() {
    const url = window.location.href.split('?')[0].split('#')[0];
    const container = document.getElementById('ouv-qr-container');
    if (!container) return;
    container.innerHTML = '';
    try {
      new QRCode(container, { text: url + '#ouvidoria', width: 200, height: 200, colorDark: '#1b5e20', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
    } catch {
      container.innerHTML = `<div style="padding:1rem;font-size:12px;text-align:center;word-break:break-all">${url}</div>`;
    }
    document.getElementById('ouv-qr-url').textContent = url + '#ouvidoria';
    UI.showModal('modal-ouv-qr');
  },

  /* Impressão de relatório administrativo */
  printList() {
    const all = this._getAll();
    const cfg = this._getCfg();
    const lh  = (typeof DB !== 'undefined') ? DB.getLH() : {};
    const r   = (typeof DB !== 'undefined') ? DB.getResp() : {};
    const hoje = new Date().toLocaleDateString('pt-BR', { day:'2-digit', month:'long', year:'numeric' });
    if (all.length === 0) { UI.toast('Nenhuma manifestação para imprimir.', 'error'); return; }

    const header = (typeof PrintMod !== 'undefined') ? PrintMod._buildHeader(lh) : '';
    const footer = (typeof PrintMod !== 'undefined') ? PrintMod._buildFooter(lh, r) : '';

    const html = `<div class="doc-a4">${header}
      <div class="doc-content">
        <div class="doc-subject">Relatório de Manifestações — Ouvidoria da Saúde</div>
        <div class="doc-ref-box">Secretaria Municipal de Saúde — Itapajé/CE · Gerado em: ${hoje} · Total: ${all.length} manifestação(ões)</div>
        <div class="doc-section-hd">Resumo por Tipo</div>
        <table class="batch-summary-table">
          <tr><th>Tipo</th><th>Quantidade</th><th>%</th></tr>
          ${['Reclamação','Sugestão','Elogio','Denúncia','Informação','Outro'].map(t=>{const n=all.filter(x=>x.tipo===t).length;return n>0?`<tr><td>${t}</td><td>${n}</td><td>${Math.round(n/all.length*100)}%</td></tr>`:''}).join('')}
          <tr style="font-weight:bold;background:#e8f5e9"><td>TOTAL</td><td>${all.length}</td><td>100%</td></tr>
        </table>
        <div class="doc-section-hd" style="margin-top:10px">Lista de Manifestações</div>
        <table class="batch-summary-table">
          <tr><th style="width:22%">Protocolo</th><th style="width:12%">Data</th><th style="width:12%">Tipo</th><th style="width:20%">Setor</th><th style="width:20%">Cidadão</th><th style="width:14%">Status</th></tr>
          ${all.map(x=>`<tr>
            <td style="font-family:monospace;font-size:9.5pt">${x.protocolo}</td>
            <td style="font-size:9.5pt">${new Date(x.criadoEm).toLocaleDateString('pt-BR')}</td>
            <td style="font-size:9.5pt">${x.tipo}</td>
            <td style="font-size:9.5pt">${x.setor}</td>
            <td style="font-size:9.5pt">${x.anonimo?'Anônimo':x.nome}</td>
            <td style="font-size:9.5pt">${x.status}</td>
          </tr>`).join('')}
        </table>
        <div style="text-align:right;font-size:10.5pt;font-style:italic;margin-top:12mm">Itapajé – CE, ${hoje}.</div>
        <div style="text-align:center;margin-top:12mm"><div style="display:inline-block;min-width:220px;text-align:center">
          <div style="height:36px;border-bottom:1px solid #000;margin-bottom:4px"></div>
          <div style="font-size:11pt;font-weight:bold">${cfg.ouvidorName||'Francisco Maílson de Sousa Moreira'}</div>
          <div style="font-size:9.5pt;color:#333">Gerente de Apoio Social / Ouvidor Municipal</div>
          <div style="font-size:9.5pt">Tel.: (85) 9 9126-4880</div>
        </div></div>
      </div>${footer}</div>`;

    document.getElementById('print-preview-content').innerHTML = html;
    document.getElementById('preview-modal-title').textContent = 'Relatório de Ouvidoria';
    UI.showModal('modal-print-preview');
  },
};

/* ── Adiciona Ouvidoria ao switchTab ── */
window.addEventListener('load', () => {
  if (typeof UI === 'undefined') return;
  const _orig = UI.switchTab.bind(UI);
  UI.switchTab = function(id, btn) {
    _orig(id, btn);
    if (id === 'ouvidoria') Ouvidoria.init();
  };
});

console.log('SAS v4.4 — Print fix · Ouvidoria da Saúde ✓');

function Ouvidoria_printQR() {
  const container = document.getElementById('ouv-qr-container');
  const url = document.getElementById('ouv-qr-url')?.textContent || window.location.href;
  const win = window.open('', '_blank');
  win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>QR — Ouvidoria da Saúde</title>
  <style>body{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;font-family:'Times New Roman',serif;text-align:center;gap:14px;padding:2rem}h2{font-size:20px;color:#1b5e20}h3{font-size:15px;color:#2d7d32}.qrbox{background:#fff;padding:16px;border:2px solid #2d7d32;border-radius:8px;display:inline-block}.footer{font-size:11px;color:#666;max-width:340px;line-height:1.6}code{font-size:11px;background:#f0f0f0;padding:4px 8px;border-radius:4px;display:inline-block;word-break:break-all;max-width:320px}button{margin-top:12px;padding:8px 20px;background:#2d7d32;color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer}@media print{button{display:none}}</style>
  </head><body>
  <h2>Ouvidoria da Saúde</h2>
  <h3>Secretaria Municipal de Saúde — Itapajé/CE</h3>
  <div class="qrbox">${container.innerHTML}</div>
  <p><strong>Registre sua Manifestação</strong></p>
  <p class="footer">Aponte a câmera do celular para o QR Code ou acesse:</p>
  <code>${url}</code>
  <div class="footer">Reclamações · Sugestões · Elogios · Denúncias<br>Seus dados são tratados com sigilo e respeito.<br>Tel.: (85) 9 9126-4880</div>
  <button onclick="window.print()">Imprimir</button>
  </body></html>`);
  win.document.close();
}
